# Copyright Axelera AI, 2025
# A container for images in various forms
from __future__ import annotations

import collections
import ctypes
from contextlib import contextmanager
from itertools import accumulate
from typing import TYPE_CHECKING, Any, Tuple, TypeVar

import numpy as np
import numpy.typing as npt

from .enums import ColorFormat

Gst, GstVideo = None, None


def _import_gst():
    global Gst, GstVideo
    if Gst is None:
        import gi

        gi.require_version("Gst", "1.0")
        gi.require_version("GstVideo", "1.0")
        from gi.repository import Gst as _Gst
        from gi.repository import GstVideo as _GstVideo

        Gst, GstVideo = _Gst, _GstVideo


if TYPE_CHECKING:
    _import_gst()

try:
    from typing import Annotated, Literal

    ImageArray = Annotated[npt.NDArray[np.uint8], Literal["H", "W", 3]]
except ImportError:
    # python 3.8 compatibility
    ImageArray = TypeVar('np.NDArray[np.uint8], Literal["H", "W", 3]')

try:
    import PIL.Image

    PILImage = PIL.Image.Image
except ImportError:
    PILImage = TypeVar("PIL.Image.Image")


_BufferInfo = collections.namedtuple(
    "_BufferInfo",
    [
        "width",
        "height",
        "color_format",
        "pitch",
        "pixel_stride",
        "buffer_size",
        "buffer_offset",
    ],
)


def _get_color_format_from_gst(format_int: int) -> ColorFormat:
    """Get ColorFormat from GStreamer format integer."""
    if Image._GST_FORMAT_MAPPING is None:
        _import_gst()
        Image.get_gst_format(ColorFormat.RGB)
    for color_format, gst_format in Image._GST_FORMAT_MAPPING.items():
        if gst_format == format_int:
            return color_format
    formats = "|".join(f.name for f in Image._GST_FORMAT_MAPPING.keys())
    raise ValueError(f"Unsupported GStreamer format: {format_int}. Must be one of {formats}")


def _buffer_info_from_gst(sample: Gst.Sample) -> Tuple[_BufferInfo, ColorFormat]:
    caps = sample.get_caps()
    vinfo = GstVideo.VideoInfo.new_from_caps(caps)
    pixel_stride = vinfo.finfo.pixel_stride[0]
    format = vinfo.finfo.format
    try:
        color_format = _get_color_format_from_gst(format)
    except ValueError as e:
        raise RuntimeError(str(e)) from None
    pitch = vinfo.stride
    meta = GstVideo.buffer_get_video_meta(sample.get_buffer())
    buffer_size = vinfo.size
    buffer_offset = vinfo.offset
    if meta is not None:
        buffer_offset = meta.offset
        pitch = meta.stride
    return _BufferInfo(
        vinfo.width,
        vinfo.height,
        color_format,
        pitch,
        pixel_stride,
        buffer_size,
        buffer_offset,
    )


def _gst_buffer_to_ndarray(sample: Gst.Sample, binfo: _BufferInfo) -> ImageArray:
    """
    Convert a Gst.Buffer to a numpy array.
    This always performs a converison to BGR as it is typcially used with OpenCV.
    If necessary
    """
    buf = sample.get_buffer()
    caps = sample.get_caps()
    s = caps.get_structure(0)
    w, h = s.get_value("width"), s.get_value("height")
    fmt_str = s.get_value("format")

    v_fmt = GstVideo.video_format_from_string(fmt_str)
    v_info = GstVideo.video_format_get_info(v_fmt)

    meta = GstVideo.buffer_get_video_meta(buf)
    success, info = buf.map(Gst.MapFlags.READ)
    if not success:
        return None
    try:
        raw_bytes = info.data

        # Calculate unpadded width (in bytes) and height (in rows) per plane
        expected_strides = []
        plane_heights = []

        for i in range(v_info.n_planes):
            # i=0 is always the Y or RGB plane
            # v_info.w_sub[i] is the horizontal subsampling (0 or 1 usually)
            # v_info.pixel_stride[i] is bytes-per-pixel for that specific plane
            p_w = w >> v_info.w_sub[i]
            p_h = h >> v_info.h_sub[i]

            expected_strides.append(p_w * v_info.pixel_stride[i])
            plane_heights.append(p_h)

        planes = [
            {
                'w_bytes': (w >> v_info.w_sub[i]) * v_info.pixel_stride[i],
                'h': h >> v_info.h_sub[i],
                'stride': meta.stride[i] if meta else 0,  # Placeholder
                'offset': meta.offset[i] if meta else 0,
            }
            for i in range(v_info.n_planes)
        ]
        needs_flatten = False
        if meta:
            # Check strides
            stride_mismatch = any(
                m_stride != p['w_bytes'] for m_stride, p in zip(meta.stride, planes)
            )
            # Check gaps (using the accumulate pattern)
            expected_offsets = accumulate(
                [0] + [h_ >> v_info.h_sub[i] * meta.stride[i] for i, h_ in enumerate([h] * 3)][:-1]
            )
            gap_found = any(
                m_off != exp_off for m_off, exp_off in zip(meta.offset, expected_offsets)
            )
            needs_flatten = stride_mismatch or gap_found
            # Update planes with meta strides for the copy path
            for i, p in enumerate(planes):
                p['stride'] = meta.stride[i]
        else:
            # If no meta, GStreamer guarantees a contiguous buffer for the given format
            for p in planes:
                p['stride'] = p['w_bytes']

        if not needs_flatten:
            flat_data = np.ndarray((info.size,), buffer=raw_bytes, dtype=np.uint8)
        else:
            # Strip the strides to make the buffer contiguous, how OpenCV likes it
            extracted_planes = []
            for i in range(v_info.n_planes):
                stride = meta.stride[i]
                offset = meta.offset[i]
                row_bytes = expected_strides[i]
                p_h = plane_heights[i]

                for r in range(p_h):
                    start = offset + (r * stride)
                    extracted_planes.append(raw_bytes[start : start + row_bytes])

            flat_data = np.frombuffer(b"".join(extracted_planes), dtype=np.uint8)

        # Map to OpenCV format
        if fmt_str in ["BGR", "RGB", "BGRA", "RGBA"]:
            channels = 4 if "A" in fmt_str else 3
            img = flat_data.reshape((h, w, channels))
            return img

        elif fmt_str in ["I420", "NV12"]:
            yuv = flat_data.reshape((h * 3 // 2, w))
            return yuv

        elif fmt_str == "NV16":
            yuv = flat_data.reshape((h, w * 2))
            return yuv

        elif fmt_str == "YUY2":
            yuv = flat_data.reshape((h, w, 2))
            return yuv

    finally:
        buf.unmap(info)


def _convert_format(
    array: ImageArray, src_format: ColorFormat, dst_format: ColorFormat
) -> ImageArray:
    """Convert image array between different color formats efficiently.
    Tries to use OpenCV first, falls back to NumPy implementation if OpenCV is not available.

    Args:
        array: Input image array with shape (H, W, C), must be uint8
        src_format: Source color format
        dst_format: Target color format

    Returns:
        Converted image array (only copies when necessary)
    """
    if array.ndim == 3 and src_format == ColorFormat.GRAY:
        array = array.squeeze()
    if not array.flags.c_contiguous:
        array = np.ascontiguousarray(array)

    if src_format == dst_format:
        return array

    if array.dtype != np.uint8:
        raise ValueError(f"Input array must be uint8, got {array.dtype}")

    try:
        import cv2
    except ImportError:
        raise ImportError("OpenCV is required for color format conversion")

    try:
        postfixes = ["I420", "NV12", "NV16", "YUY2"]
        src_name = src_format.name
        post = ""
        if src_name in postfixes:
            post = "_" + src_name
            src_name = "YUV"
        cv_code = getattr(cv2, f"COLOR_{src_name}2{dst_format.name}{post}")

    except AttributeError:
        raise ValueError(
            f"Unsupported color format conversion from {src_format.name} to {dst_format.name}"
        ) from None
    result = cv2.cvtColor(array, cv_code)
    if dst_format == ColorFormat.GRAY and result.ndim == 2:
        result = result[..., np.newaxis]
    return result


def _check_gray_format(array: ImageArray | PILImage, color_format: ColorFormat):
    """Check and validate grayscale format compatibility."""
    if isinstance(array, PILImage):
        if color_format == ColorFormat.GRAY:
            if array.mode != "L":
                raise ValueError(
                    f"PIL Image must be in 'L' mode for GRAY format, got {array.mode}"
                )
        else:
            if array.mode == "L":
                raise ValueError(
                    f"PIL Image in 'L' mode can only be used with GRAY format, got {color_format}"
                )
        return array

    # Handle numpy array
    if color_format == ColorFormat.GRAY:
        if array.ndim == 3:
            if array.shape[2] != 1:
                raise ValueError(
                    "GRAY format must have a single channel if 3D array, "
                    f"got {array.shape[2]} channels"
                )
            return array.squeeze()
        elif array.ndim != 2:
            raise ValueError(
                "GRAY format must be 2D array or 3D array with single channel, "
                f"got {array.ndim}D array"
            )
    else:
        if array.ndim == 2:
            raise ValueError(f"2D array can only be used with GRAY format, got {color_format}")
        if array.ndim == 3 and array.shape[2] == 1:
            raise ValueError(
                f"Single channel 3D array can only be used with GRAY format, got {color_format}"
            )
    return array


class Image:
    __slots__ = ("_n", "_p", "_b", "_buffer_info")
    _GST_FORMAT_MAPPING = None

    def __init__(
        self,
        /,
        n: ImageArray | None = None,
        p: PILImage | None = None,
        b: Gst.Sample | None = None,
        color_format: ColorFormat | str = ColorFormat.RGB,
    ):
        """Do not call this directly, use img.fromarray, or img.frompil."""
        if sum(x is not None for x in (n, p, b)) != 1:
            raise ValueError("Exactly one of n, p, or b must be provided")
        color_format = ColorFormat.parse(color_format)

        if n is not None:
            assert isinstance(n, np.ndarray)
            n = _check_gray_format(n, color_format)
            h, w = n.shape[:2] if n.ndim >= 2 else (n.shape[0], 1)
            pixel_stride = n.shape[2] if n.ndim == 3 else 1
            pitch = [w * pixel_stride]
            self._buffer_info = _BufferInfo(
                width=w,
                height=h,
                color_format=color_format,
                pitch=pitch,
                pixel_stride=pixel_stride,
                buffer_size=n.nbytes,
                buffer_offset=[0],
            )
        elif p is not None:
            assert isinstance(p, PILImage)
            p = _check_gray_format(p, color_format)
            w, h = p.size
            if p.mode == "RGB":
                pixel_stride = 3
            elif p.mode == "RGBA":
                pixel_stride = 4
            elif p.mode == "L":
                pixel_stride = 1
            else:
                raise ValueError(f"Unsupported PIL mode: {p.mode}")
            self._buffer_info = _BufferInfo(
                width=w,
                height=h,
                color_format=color_format,
                pitch=[w * pixel_stride],
                pixel_stride=pixel_stride,
                buffer_size=w * h * pixel_stride,
                buffer_offset=[0],
            )
        elif b is not None:
            _import_gst()
            assert isinstance(b, Gst.Sample)
            self._buffer_info = _buffer_info_from_gst(b)

        self._n: ImageArray = n
        self._p: PILImage = p
        self._b: Gst.Sample = b

    def __eq__(self, other):
        if not isinstance(other, Image):
            return NotImplemented

        n_equal = (
            (self._n == other._n).all()
            if self._n is not None and other._n is not None
            else self._n == other._n
        )
        p_equal = (
            (self._p == other._p).all()
            if self._p is not None and other._p is not None
            else self._p == other._p
        )
        b_equal = (
            (self._b == other._b).all()
            if self._b is not None and other._b is not None
            else self._b == other._b
        )

        return n_equal and p_equal and b_equal

    @classmethod
    def fromarray(
        cls,
        nparray: ImageArray,
        color_format: ColorFormat | str = ColorFormat.RGB,
    ):
        """Construct an Image from a numpy array."""
        return cls(n=nparray, color_format=color_format)

    @classmethod
    def frompil(cls, pil: PILImage, color_format: ColorFormat | str = ColorFormat.RGB):
        """Construct an Image from a PIL Image."""
        if (pil.mode == "L") != (color_format == ColorFormat.GRAY):
            desired = "L" if color_format == ColorFormat.GRAY else "RGB"
            pil = pil.convert(desired)
        return cls(p=pil, color_format=color_format)

    @classmethod
    def fromgst(cls, buffer: Gst.Sample):
        """Construct an Image from a GST video buffer.
        The color format will be inferred from the buffer.
        """
        return cls(b=buffer)

    @classmethod
    def fromany(cls, i: Any, color_format: ColorFormat | str = ColorFormat.RGB):
        """Construct an Image from a PIL Image, a numpy array, or an Image.

        Any other type will raise a TypeError.
        """
        if isinstance(i, np.ndarray):
            return cls.fromarray(i, color_format)
        elif isinstance(i, PILImage):
            return cls.frompil(i, color_format)
        elif isinstance(i, Image):
            return i
        else:
            _import_gst()
            if isinstance(i, Gst.Buffer):
                return cls.fromgst(i)
            else:
                raise TypeError(f"Cannot create Image from {type(i)}")

    @property
    def size(self) -> Tuple[int, int]:
        """Size of the image in pixels as (width, height)."""
        return self._buffer_info.width, self._buffer_info.height

    @property
    def width(self) -> int:
        """Width of the image in pixels."""
        return self._buffer_info.width

    @property
    def height(self) -> int:
        """Height of the image in pixels."""
        return self._buffer_info.height

    @property
    def pitch(self) -> int:
        """Stride of the image in bytes."""
        return self.strides[0]

    @property
    def pixel_stride(self) -> int:
        """Pixel stride of the image in bytes."""
        return self._buffer_info.pixel_stride

    @property
    def strides(self) -> Tuple[int, int, int]:
        """Strides of the image array in bytes."""
        return self._buffer_info.pitch

    @property
    def offsets(self) -> Tuple[int, ...]:
        """Offsets of the image buffer in bytes."""
        return self._buffer_info.buffer_offset

    @property
    def color_format(self) -> ColorFormat:
        return self._buffer_info.color_format

    @contextmanager
    def as_c_void_p(self) -> ctypes.c_void_p:
        """Return a pointer to the image data as a ctypes.c_void_p."""
        if self._p is not None or self._n is not None:
            yield self.asarray().ravel().ctypes.data_as(ctypes.c_void_p)
        else:
            buf = self._b.get_buffer()
            try:
                (result, info) = buf.map(Gst.MapFlags.READ)
                # info.data from GStreamer is a ctypes array which is subscriptable
                # Return it directly to maintain subscriptability
                yield info.data
            finally:
                buf.unmap(info)

    def update(
        self,
        /,
        array: ImageArray | None = None,
        pil: PILImage | None = None,
        color_format: ColorFormat | str = ColorFormat.RGB,
    ):
        """Update the image with a new array or PIL image.

        Args:
            array: Optional numpy array to update with
            pil: Optional PIL image to update with
            color_format: Color format of the input image, defaults to RGB
        """
        self._n = array
        self._p = pil
        self._buffer_info = self._buffer_info._replace(
            color_format=ColorFormat.parse(color_format)
        )

    @property
    def has_pil(self) -> bool:
        """True if the image contains a PIL image."""
        return self._p is not None

    @property
    def has_array(self) -> bool:
        """True if the image contains a numpy array."""
        return self._n is not None

    @property
    def has_gst(self) -> bool:
        """True if the image contains a numpy array."""
        return self._b is not None

    def copy(self):
        """Copy the underlying buffer, but do not change the type of the image.

        Note only one buffer will be present after the copy, so if the image
        currently contains both PIL and nparray, then only PIL will be present
        post copy.
        """
        if self._p:
            return self.__class__.frompil(self._p.copy(), self._buffer_info.color_format)
        elif self._n is not None:
            return self.__class__.fromarray(self._n.copy(), self._buffer_info.color_format)
        elif self._b is not None:
            return self.__class__.fromgst(self._b)
        else:
            return self.__class__()

    def asarray(self, format: ColorFormat | str | None = None) -> ImageArray:
        """Return the image as a numpy array with optional format conversion.

        Args:
            format: Optional target format. If None, returns array in original format
        Returns:
            Numpy array in shape (H, W, C) or (H, W) if grayscale
        """
        img_format = self._buffer_info.color_format
        array = self._n
        if array is None:
            if self._p is not None:
                self._n = np.array(self._p)
                array = self._n
            elif self._b is not None:
                # _gst_buffer_to_ndarray always returns BGR
                array = _gst_buffer_to_ndarray(self._b, self._buffer_info)
                img_format = self._buffer_info.color_format

        if format is not None:
            format = ColorFormat.parse(format)
            array = _convert_format(array, img_format, format)
            # Only cache and update state if not requesting a specific format conversion
            # This allows the original buffer to be preserved for future reads
            return array

        # Cache the array and clear the buffer only when no format is specified
        self._n = array
        self._buffer_info = self._buffer_info._replace(color_format=img_format)
        self._b = None
        return array

    def aspil(self) -> PILImage:
        """Return the image as a PIL image."""
        if self._p is None:
            if self._n is not None:
                array = self._n
                if self._buffer_info.color_format == ColorFormat.GRAY and array.ndim == 3:
                    array = array.squeeze()
                self._p = PIL.Image.fromarray(array)
            elif self._b is not None:
                self._p = PIL.Image.fromarray(self.asarray())
        return self._p

    def tobytes(self, color_format: ColorFormat | str | None = None) -> bytes:
        """Return the image data to bytes, optionally in a different color format.

        Args:
            color_format: Optional target format. If None, uses current format
        Returns:
            Raw bytes of the image data in row-major order
        """
        color_format = ColorFormat.parse(color_format)

        if self._p is not None:
            color_format = color_format or self._buffer_info.color_format
            if color_format == self._buffer_info.color_format:
                return self._p.tobytes()
            elif (
                color_format == ColorFormat.RGBA
                and self._buffer_info.color_format == ColorFormat.RGB
            ) or (
                color_format == ColorFormat.BGRA
                and self._buffer_info.color_format == ColorFormat.BGR
            ):
                # just use RGBA to append the alpha channel
                return self._p.convert("RGBA").tobytes()

        return self.asarray(format=color_format).tobytes()

    @classmethod
    def get_gst_format(cls, color_format: ColorFormat) -> int:
        """Get GStreamer format integer for a given ColorFormat."""
        if cls._GST_FORMAT_MAPPING is None:
            _import_gst()
            from gi.repository import GstVideo

            cls._GST_FORMAT_MAPPING = {
                ColorFormat.RGB: int(GstVideo.VideoFormat.RGB),
                ColorFormat.RGBA: int(GstVideo.VideoFormat.RGBA),
                ColorFormat.BGR: int(GstVideo.VideoFormat.BGR),
                ColorFormat.BGRA: int(GstVideo.VideoFormat.BGRA),
                ColorFormat.GRAY: int(GstVideo.VideoFormat.GRAY8),
                ColorFormat.I420: int(GstVideo.VideoFormat.I420),
                ColorFormat.NV12: int(GstVideo.VideoFormat.NV12),
                ColorFormat.NV16: int(GstVideo.VideoFormat.NV16),
                ColorFormat.YUY2: int(GstVideo.VideoFormat.YUY2),
            }
        try:
            return cls._GST_FORMAT_MAPPING[color_format]
        except KeyError:
            raise ValueError(f"Color format {color_format.name} is not supported for types.Image")


fromarray = Image.fromarray
frompil = Image.frompil
fromgst = Image.fromgst
fromany = Image.fromany
