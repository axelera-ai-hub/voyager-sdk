# Copyright Axelera AI, 2025
# Model info for building E2E pipeline
from __future__ import annotations

import enum
import json
from dataclasses import dataclass, field, fields
from typing import TYPE_CHECKING, Any, Dict, List, Sequence

from .enums import ColorFormat, ModelType, TaskCategory, TensorLayout
from .manifest import Manifest

if TYPE_CHECKING:
    import torch


@dataclass
class OutputInfo:
    """Information about a model output tensor."""

    shape: Sequence[int]
    name: str  # index for PyTorch, actual name for ONNX
    dtype: str = "float32"

    def __post_init__(self):
        if self.shape is not None:
            self.shape = tuple(self.shape)  # Ensure immutable

    def to_dict(self) -> Dict[str, Any]:
        """Convert OutputInfo to dictionary for serialization."""
        return {
            "shape": list(self.shape),
            "name": self.name,
            "dtype": self.dtype,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> OutputInfo:
        """Create OutputInfo from dictionary."""
        return cls(**data)


@dataclass
class ModelInfo:
    """General info for building Python & C++ pipeline.

    This class represents the model information as defined in the YAML models section
    """

    name: str
    task_category: TaskCategory
    input_tensor_shape: Sequence[int] | None = None
    input_color_format: ColorFormat = ColorFormat.RGB
    input_tensor_layout: TensorLayout = TensorLayout.NCHW
    num_classes: int = 1
    labels: list[str] = field(default_factory=list)
    label_filter: list[str] = field(default_factory=list)

    output_info: list[OutputInfo] = field(default_factory=list)

    model_type: ModelType = ModelType.DEEP_LEARNING
    weight_path: str = ""
    weight_url: str = ""
    weight_md5: str = ""
    prequantized_path: str = ""
    prequantized_url: str = ""
    prequantized_md5: str = ""
    precompiled_path: str = ""
    precompiled_url: str = ""
    precompiled_md5: str = ""
    dataset: str = ""

    base_dir: str = ""
    class_name: str = ""
    class_path: str = ""
    version: str = ""

    extra_kwargs: dict[str, Any] = field(default_factory=dict)
    """Extra keyword arguments for model construction and init_model_deploy."""

    def __post_init__(self):
        self.task_category = TaskCategory.parse(self.task_category)
        self.model_type = ModelType.parse(self.model_type)
        if self.model_type == ModelType.CLASSICAL_CV:
            if self.input_tensor_shape is not None:
                self.input_tensor_shape = None
            if self.input_tensor_layout is not None:
                self.input_tensor_layout = None
            if self.input_color_format is not None:
                self.input_color_format = None
        else:
            self.input_color_format = ColorFormat.parse(self.input_color_format)
            self.input_tensor_layout = TensorLayout.parse(self.input_tensor_layout)
            if self.input_tensor_shape is None:
                raise ValueError("input_tensor_shape must be provided for deep learning models")
            if len(self.input_tensor_shape) == 3:
                if self.input_tensor_layout == TensorLayout.CHWN:
                    self.input_tensor_shape = list(self.input_tensor_shape) + [1]
                else:
                    self.input_tensor_shape = [1] + list(self.input_tensor_shape)
            elif len(self.input_tensor_shape) != 4:
                raise ValueError(
                    f"Invalid input tensor shape {self.input_tensor_shape}, "
                    "must be 3 or 4 dimensions"
                )

        # Process output_info
        processed_output_info = []
        for output in self.output_info:
            if isinstance(output, dict):
                processed_output_info.append(OutputInfo(**output))
            elif isinstance(output, OutputInfo):
                processed_output_info.append(output)
            else:
                raise ValueError(f"Invalid output_info entry: {output}")
        self.output_info = processed_output_info

        self._manifest = None

    @property
    def input_width(self) -> int:
        return self.input_tensor_shape[self.input_tensor_layout.name.index("W")]

    @property
    def input_height(self) -> int:
        return self.input_tensor_shape[self.input_tensor_layout.name.index("H")]

    @property
    def input_channel(self) -> int:
        return self.input_tensor_shape[self.input_tensor_layout.name.index("C")]

    @property
    def manifest(self) -> Manifest | None:
        return self._manifest

    @manifest.setter
    def manifest(self, manifest: Manifest):
        self._manifest = manifest

    # Convenience methods for working with outputs
    def get_output_by_name(self, name: str) -> OutputInfo | None:
        """Get output info by name (useful for both PyTorch indices and ONNX names)."""
        for output in self.output_info:
            if output.name == name:
                return output
        return None

    def get_output_by_index(self, index: int) -> OutputInfo | None:
        """Get output info by index."""
        if 0 <= index < len(self.output_info):
            return self.output_info[index]
        return None

    @property
    def has_named_outputs(self) -> bool:
        """Check if outputs have semantic names (not just indices)."""
        return all(not output.name.isdigit() for output in self.output_info if output.name)

    # Registration methods
    def register_outputs_from_pytorch(
        self,
        model: "torch.nn.Module",
        device: str = "cpu",
        output_names: List[str] = None,
    ) -> None:
        """Register output info by running PyTorch model inference."""
        import torch

        if self.input_tensor_shape is None:
            raise ValueError(
                "ModelInfo must have input_tensor_shape set for PyTorch model registration"
            )

        model.eval()
        dummy_input = torch.randn(self.input_tensor_shape).to(device)

        with torch.no_grad():
            outputs = model(dummy_input)

        if isinstance(outputs, dict):
            output_infos = []
            for name, output in outputs.items():
                output_infos.append(
                    OutputInfo(
                        shape=list(output.shape),
                        name=name,
                        dtype=str(output.dtype).replace("torch.", ""),
                    )
                )
        else:
            if not isinstance(outputs, (list, tuple)):
                outputs = [outputs]

            output_infos = []
            for i, output in enumerate(outputs):
                name = output_names[i] if output_names and i < len(output_names) else str(i)
                output_infos.append(
                    OutputInfo(
                        shape=list(output.shape),
                        name=name,
                        dtype=str(output.dtype).replace("torch.", ""),
                    )
                )

        self.output_info = output_infos

    def register_outputs_from_onnx(self, model_path: str = None) -> None:
        """Register output info from ONNX model file.

        For dynamic shapes, infers actual output shapes using input_tensor_shape.
        """
        import numpy as np
        import onnxruntime as ort

        if model_path is None:
            model_path = self.weight_path or self.precompiled_path
            if not model_path or not model_path.endswith(".onnx"):
                raise ValueError("No ONNX model path provided and couldn't infer from ModelInfo")

        if self.input_tensor_shape is None:
            raise ValueError(
                "ModelInfo must have input_tensor_shape set for ONNX output shape inference"
            )

        session = ort.InferenceSession(model_path)
        input_meta = session.get_inputs()[0]
        dummy_input = np.random.randn(*self.input_tensor_shape).astype(np.float32)
        outputs = session.run(None, {input_meta.name: dummy_input})
        output_metas = session.get_outputs()

        output_infos = []
        for output, output_meta in zip(outputs, output_metas):
            output_infos.append(
                OutputInfo(
                    shape=list(output.shape),
                    name=output_meta.name,
                    dtype=output_meta.type,
                )
            )

        self.output_info = output_infos

    def to_json(self) -> str:
        """Convert model info to a JSON string."""
        vals = {f.name: getattr(self, f.name) for f in fields(self.__class__)}
        deenumed = {k: v.name if isinstance(v, enum.Enum) else v for k, v in vals.items()}

        if "output_info" in deenumed:
            deenumed["output_info"] = [output.to_dict() for output in self.output_info]

        return json.dumps(deenumed, indent=2)

    @classmethod
    def from_json(cls, src: str) -> ModelInfo:
        """Read model info from JSON string."""
        data = json.loads(src)

        # Handle output_info deserialization using OutputInfo's own method
        if "output_info" in data:
            data["output_info"] = [
                OutputInfo.from_dict(output_data) for output_data in data["output_info"]
            ]

        return cls(**data)
