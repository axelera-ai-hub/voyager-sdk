# Copyright Axelera AI, 2024
from __future__ import annotations

import abc
import inspect
import logging
from typing import TYPE_CHECKING, Any, Callable, Iterable, Protocol, runtime_checkable

from . import helper
from .enums import ColorFormat, DatasetSplit, ImageReader
from .model_info import ModelInfo
from .shared import ParameterSharingMixin

LOG = logging.getLogger(__name__)

if TYPE_CHECKING:
    from pathlib import Path

    import numpy as np
    import PIL.Image
    import torch

    from .evaluator import Evaluator
    from .shared import FrameInput

    PreprocessFn = Callable[[PIL.Image.Image | np.ndarray], torch.Tensor]


@runtime_checkable
class DataLoader(Protocol):
    """
    A generic data loader object that is iterable and has a __len__ method.
    This can be either a PyTorch DataLoader or a TensorFlow Dataset.
    """

    sampler: Any
    """Optional attribute, if present, and it is a torch.utils.data.RandomSampler
    then the framework will assume the dataloader is suitable for calibration."""

    def __len__(self) -> int:
        """Return the number of images in the dataset (or subset)."""

    def __iter__(self) -> Iterable[Any]:
        """Return an iterator over the dataset (or subset).

        The return type of the iterator is currently unspecified, this is because there are a wide
        variety of data loaders which have varying return types. The framework does not yet
        prescribe a fixed format, but in future versions this will be specified in more detail.
        """


@runtime_checkable
class NormalizedDataLoader(Protocol):
    """For axelera use only."""

    def __iter__(self) -> Iterable[Any]:
        """Return an iterator over the dataset."""

    def __len__(self) -> int:
        """size of the dataset."""

    def build_preprocess_ort(self, preprocess_graph):
        """The compiler should call this if/when ONNXGraphCleaner creates a preprocess_graph.
        It arranges for an onnxruntime session to run the given graph on the batch data as part
        of the iteration.
        """


class BaseDataAdapter(abc.ABC):  # noqa: B024
    """Base class for data handling and normalization."""

    def __init__(self):
        self._calibration_normalized_loader = None
        self._measurement_normalized_loader = None
        self._dataset_download_callback = None
        self._use_repr_imgs = None

    def check_calibration_data_loader(self, data_loader: DataLoader) -> bool | None:
        """
        Check if the dataloader is suitable for calibration.

        Args:
            data_loader (DataLoader): Calibration data loader to check.

        Returns:
            bool | None: True if suitable, False if not, None to request framework check.

        Notes:
            "Suitable" means the dataset provides a representative sample of the expected
            input data to allow adequate calibration to be performed.

            This default implementation returns None, which means the framework will check what
            it can, such as, if dataloader.sampler is a torch.utils.data.RandomSampler.

            If the dataset cannot be confirmed as suitable, the framework will generate a
            warning message, but will continue to use the dataloader for calibration.

            If you override this you should return True if the dataloader is
            suitable, and False if it is not.
        """
        return None

    def set_calibration_normalized_loader(self, normalized_loader: NormalizedDataLoader) -> None:
        """Set the calibration normalized loader. For axelera use only."""
        self._calibration_normalized_loader = normalized_loader

    def get_calibration_normalized_loader(self) -> NormalizedDataLoader:
        """Get the calibration normalized loader. For axelera use only.
        This returns a tensor of N image-tensors, where N is the batch_size given
        to create_calibration_data_loader.
        """
        if self._calibration_normalized_loader is None:
            raise RuntimeError(
                "The calibration_normalized_loader has not been set. "
                "Please set it with set_calibration_normalized_loader before accessing."
            )
        return self._calibration_normalized_loader

    def set_measurement_normalized_loader(self, normalized_loader: NormalizedDataLoader) -> None:
        """Set the measurement normalized loader. For axelera use only."""
        self._measurement_normalized_loader = normalized_loader

    def get_measurement_normalized_loader(self) -> NormalizedDataLoader:
        """Get the measurement normalized loader. For axelera use only."""
        if self._measurement_normalized_loader is None:
            raise RuntimeError(
                "The measurement_normalized_loader has not been set. "
                "Please set it with set_measurement_normalized_loader before accessing."
            )
        return self._measurement_normalized_loader

    def check_representative_images(
        self,
        transform: Callable | None,
        batch_size: int,
        imreader_backend: ImageReader = ImageReader.PIL,
        pipeline_input_color_format: ColorFormat = ColorFormat.RGB,
        **kwargs,
    ) -> DataLoader | None:
        """
        A helper function to ensure the presence of representative images and construct
        a calibration dataloader if they are found.

        Args:
            transform (Callable | None): Transformation function to apply to images.
            batch_size (int): Batch size for the dataloader.
            **kwargs: Additional keyword arguments.

        Returns:
            DataLoader | None: A DataLoader if representative images are found, None otherwise.

        Raises:
            RuntimeError: If representative images are missing but repr_imgs_dir_name is set.]
        """
        if not isinstance(imreader_backend, ImageReader):
            raise TypeError("imreader_backend must be an instance of ImageReader")
        if not isinstance(pipeline_input_color_format, ColorFormat):
            raise TypeError("pipeline_input_color_format must be an instance of ColorFormat")
        self._use_repr_imgs = False
        if not (repr_image_dir := kwargs.get("repr_imgs_dir_path", None)):
            return None

        if not repr_image_dir.is_dir():
            repr_image_dir.mkdir(parents=True, exist_ok=True)
            LOG.warning(f"Created directory {repr_image_dir} for representative images.")

        repr_imgs_url = kwargs.get("repr_imgs_url")
        repr_imgs_md5 = kwargs.get("repr_imgs_md5", "")
        generator = kwargs.get("generator", None)

        if not repr_image_dir.is_dir() or not any(repr_image_dir.glob("*")):
            if self._dataset_download_callback and repr_imgs_url:
                if not self._dataset_download_callback(
                    repr_image_dir, repr_imgs_url, repr_imgs_md5
                ):
                    raise RuntimeError(
                        f"Failed to download representative images to {repr_image_dir}."
                    )
            else:
                raise RuntimeError(
                    f"Directory {repr_image_dir} not found or empty. Please create it and populate"
                    f" with 100-400 representative images"
                )
        self._use_repr_imgs = True
        LOG.info(
            f"Using representative images from {repr_image_dir} with backend {imreader_backend},"
            f"pipeline input color format {pipeline_input_color_format}"
        )

        return helper.build_dataloader_from_img_dir(
            image_dir=repr_image_dir,
            transform=transform,
            batch_size=batch_size,
            imreader_backend=imreader_backend,
            color_format=pipeline_input_color_format,
            transform_input_type="axelera",
            generator=generator,
        )

    def set_dataset_download_callback(self, callback: Callable[[Path, str, str], bool]) -> None:
        """
        Set the dataset download callback.

        Args:
            callback (Callable[[Path, str, str], bool]): A function that takes three arguments:
                - repr_imgs_path (Path): The path where representative images should be downloaded.
                - repr_imgs_url (str): The URL from which to download the images.
                - repr_imgs_md5 (str): The MD5 hash for verifying the downloaded content.
                The function should return True if the download was successful, False otherwise.
        """
        if not callable(callback):
            raise TypeError("Callback must be a callable object")
        self._dataset_download_callback = callback

    @property
    def use_repr_imgs(self) -> bool:
        """Whether to use representative images for calibration."""
        return self._use_repr_imgs


def create_data_adapter_meta(bases):  # noqa: C901
    class DataAdapterMeta(type(bases[0])):
        def __new__(mcs, name, bases, attrs):
            if mcs._is_data_adapter_subclass_not_model(bases):
                mcs._check_init_signature(attrs.get("__init__"))
                mcs._check_method_signature(
                    attrs.get("create_calibration_data_loader"),
                    mcs._calibration_loader_signature,
                )
                mcs._check_method_signature(
                    attrs.get("create_validation_data_loader"),
                    mcs._validation_loader_signature,
                )
                mcs._check_method_signature(
                    attrs.get("reformat_for_calibration"),
                    mcs._reformat_calibration_signature,
                )
                mcs._check_method_signature(
                    attrs.get("reformat_for_validation"),
                    mcs._reformat_validation_signature,
                )
                mcs._check_method_signature(attrs.get("evaluator"), mcs._evaluator_signature)

                original_init = attrs.get("__init__")
                if original_init:

                    def wrapped_init(
                        self,
                        dataset_config: dict[str, Any],
                        model_info: ModelInfo,
                        *args,
                        **kwargs,
                    ):
                        BaseDataAdapter.__init__(self)
                        if hasattr(ParameterSharingMixin, "__init__"):
                            ParameterSharingMixin.__init__(self)
                        original_init(self, dataset_config, model_info, *args, **kwargs)

                    attrs["__init__"] = wrapped_init
                else:

                    def default_init(self, dataset_config: dict[str, Any], model_info: ModelInfo):
                        BaseDataAdapter.__init__(self)
                        if hasattr(ParameterSharingMixin, "__init__"):
                            ParameterSharingMixin.__init__(self)

                        for base in bases:
                            if hasattr(base, "__init__") and base.__init__ is not object.__init__:
                                base.__init__(self, dataset_config, model_info)
                                break  # Only call the first non-object parent's __init__

                    attrs["__init__"] = default_init

            return super().__new__(mcs, name, bases, attrs)

        @staticmethod
        def _is_data_adapter_subclass_not_model(bases):
            is_data_adapter_subclass = False
            is_model_subclass = False

            for base in bases:
                if base.__name__ == "DataAdapter" or DataAdapterMeta._is_data_adapter_subclass(
                    base.__bases__
                ):
                    is_data_adapter_subclass = True
                if base.__name__ == "Model" or DataAdapterMeta._is_model_subclass(base.__bases__):
                    is_model_subclass = True

            return is_data_adapter_subclass and not is_model_subclass

        @staticmethod
        def _is_data_adapter_subclass(bases):
            for base in bases:
                if base.__name__ == "DataAdapter":
                    return True
                if DataAdapterMeta._is_data_adapter_subclass(base.__bases__):
                    return True
            return False

        @staticmethod
        def _is_model_subclass(bases):
            for base in bases:
                if base.__name__ == "Model":
                    return True
                if DataAdapterMeta._is_model_subclass(base.__bases__):
                    return True
            return False

        @staticmethod
        def _check_init_signature(init_method):
            if init_method:
                init_signature = inspect.signature(init_method)
                params = list(init_signature.parameters.values())
                if (
                    len(params) != 3
                    or params[1].name != "dataset_config"
                    or params[2].name != "model_info"
                ):
                    raise TypeError(
                        f"__init__ must have the signature (self, dataset_config: dict[str, Any], "
                        f"model_info: ModelInfo), got {init_signature}"
                    )

        @staticmethod
        def _check_method_signature(method, expected_signature):
            if method:
                method_signature = inspect.signature(method)
                expected_signature = inspect.signature(expected_signature)
                if not DataAdapterMeta._signatures_compatible(
                    method_signature, expected_signature
                ):
                    raise TypeError(
                        f"{method.__name__} has an incompatible signature. Expected: "
                        f"{expected_signature}, Got: {method_signature}"
                    )

        @staticmethod
        def _signatures_compatible(actual, expected):
            actual_params = list(actual.parameters.values())
            expected_params = list(expected.parameters.values())

            if len(actual_params) != len(expected_params):
                return False

            for actual_param, expected_param in zip(actual_params, expected_params):
                if actual_param.name != expected_param.name:
                    return False
                if expected_param.kind != actual_param.kind:
                    return False

            return True

        @staticmethod
        def _calibration_loader_signature(
            self, transform: Callable, root: Path, batch_size: int = 1, **kwargs
        ) -> "DataLoader":
            pass

        @staticmethod
        def _validation_loader_signature(
            self, root: Path, target_split: Any = None, **kwargs
        ) -> "DataLoader":
            pass

        @staticmethod
        def _reformat_calibration_signature(self, batched_data: Any) -> Any:
            pass

        @staticmethod
        def _reformat_validation_signature(self, batched_data: Any) -> Any:
            pass

        @staticmethod
        def _evaluator_signature(
            self,
            dataset_root: Path,
            dataset_config: dict[str, Any],
            model_info: ModelInfo,
            custom_config: dict[str, Any] | None = None,
            pair_validation: bool = False,
        ) -> Any:
            pass

    return DataAdapterMeta


class DataAdapter(
    BaseDataAdapter,
    ParameterSharingMixin,
    metaclass=create_data_adapter_meta([BaseDataAdapter, ParameterSharingMixin]),
):
    """User interface for accessing datasets and optional evaluator. A subclass
    must strictly adhere to the signature of the methods defined in this class.
    """

    def __init__(self, dataset_config: dict[str, Any], model_info: ModelInfo):
        super().__init__()

    def create_calibration_data_loader(
        self, transform: PreprocessFn, root: Path, batch_size: int = 1, **kwargs
    ) -> DataLoader:
        """
        Create a calibration data loader.

        Args:
            transform (PreprocessFn): A callable that takes a PIL image and returns a preprocessed
                version. This will be passed using either types.Model.preprocess (if implemented)
                or the preprocessing defined by the YAML pipeline.
            root (Path): Root directory of the dataset.
            batch_size (int, optional): Number of samples per batch to load. Defaults to 1.
            **kwargs: Additional keyword arguments.

        Returns:
            DataLoader: A DataLoader instance for calibration.

        Raises:
            NotImplementedError: If representative images are not available and the method is not
                implemented.

        Notes:
            If a separate calibration dataset is unavailable, utilize the training
            dataset for calibration and ensure randomness is enabled.

        Example:
            dataset = your.existing.dataset(root, transform)
            self.calibration_dataloader = your.existing.dataloader(dataset, split='train')
        """
        if repr_dataloader := self.check_representative_images(
            transform=transform,
            batch_size=batch_size,
            **kwargs,
        ):
            return repr_dataloader

        raise NotImplementedError(
            f"To calibrate the model, either implement create_calibration_data_loader "
            f"or set 'repr_imgs_dir_name' in the dataset configuration to a directory "
            f"under {root} containing representative input images for calibration."
        )

    def create_validation_data_loader(
        self, root: Path, target_split: DatasetSplit | None = None, **kwargs
    ) -> DataLoader:
        """
        Create a validation data loader.

        Args:
            root (Path): Root directory of the dataset.
            target_split (DatasetSplit | None): The split of the dataset specified by the user.
            **kwargs: Additional keyword arguments.

        Returns:
            DataLoader: A DataLoader instance for validation.

        Raises:
            NotImplementedError: If the method is not implemented in the subclass.

        Notes:
            - The batch size is always set to 1.
            - Implementing this function is optional, but strongly recommended to validate
              the quantized model before deployment.
            - For evaluation, use either the validation or test dataset.
            - Ensure that:
                - Ground truth is available
                - Any randomness is DISABLED
                - No transformations or preprocessing are applied

        Example:
            dataset = your.existing.dataset(root)
            return your.existing.dataloader(dataset, batch_size=1, shuffle=False, split='val')
        """
        raise NotImplementedError(
            "create_validation_data_loader must be implemented to validate the model"
        )

    def reformat_for_calibration(self, batched_data: Any) -> torch.Tensor:
        """
        Take a batch-iterated input from your dataloader and produce output
        in the Axelera-expected format for quantization and calibration.

        Args:
            batched_data (Any): A batch of data from the dataloader.

        Returns:
            torch.Tensor: A batch of image tensors in the expected format.

        Notes:
            - The expected format is a batch of image tensors (torch.Tensor only).
            - If you need to use TensorFlow Tensor, please contact Axelera.
            - This function doesn't need to be implemented if 'repr_imgs_dir_name' is set in
              the dataset configuration.
        """
        if self._use_repr_imgs:
            return batched_data
        raise NotImplementedError(
            "reformat_for_calibration must be implemented to calibrate the model"
        )

    def reformat_for_validation(self, batched_data: Any) -> list[FrameInput]:
        """
        Convert a batch of data from the dataloader into the Axelera-expected format
        for accuracy validation.

        This method processes the input data and transforms it into a list of FrameInput
        objects, which are used for end-to-end pipeline accuracy verification.
        which are used for end-to-end pipeline accuracy verification.

        Args:
            batched_data (Any): A batch of data from the dataloader.

        Returns:
            list[FrameInput]: A list of FrameInput objects, each containing:
                - img (PIL.Image.Image | np.ndarray): The input image as a PIL Image
                  or numpy array.
                - groundtruth (BaseEvalSample): The ground truth data for evaluation.
                - img_id (str | None): A unique identifier for the image, if applicable.

        Example:
            return [
                FrameInput(
                    img=process_image(item['image']),
                    groundtruth=create_eval_sample(item['label']),
                    img_id=item.get('id', None)
                )
                for item in batched_data
            ]

        Raises:
            NotImplementedError: If the method is not implemented in the subclass.
        """
        raise NotImplementedError(
            "reformat_for_validation must be implemented to validate the model"
        )

    def evaluator(
        self,
        dataset_root: Path,
        dataset_config: dict[str, Any],
        model_info: ModelInfo,
        custom_config: dict[str, Any] | None = None,
        pair_validation: bool = False,
    ) -> Evaluator:
        """
        Create and return an evaluator for the model.

        This method should implement an appropriate evaluator based on the dataset
        and evaluation requirements. The evaluator is responsible for computing
        metrics and assessing the model's applicable accuracy.

        Args:
            dataset_root (Path): The root directory containing the dataset.
            dataset_config (dict[str, Any]): The YAML dataset configuration.
            custom_config (dict[str, Any], optional): Custom operator settings.
              Comparing to the offline dataset_config, custom_config is generated
              online by the AxOperator during the pipeline deployment.
            pair_validation (bool): If True, the evaluator will handle paired inputs
                for validation. Defaults to False.

        Returns:
            Evaluator: An instance of a custom Evaluator class suitable for the task.

        Example:
            your_existing_evaluator = your.existing.evaluator()
            return CustomTypesEvaluator(your_existing_evaluator)

        Raises:
            NotImplementedError: If the method is not implemented in the subclass.

        Note:
            The returned Evaluator should be compatible with the FrameInput objects
            produced by the reformater_of_validation method.
        """
        raise NotImplementedError("evaluator must be implemented to evaluate the model")
