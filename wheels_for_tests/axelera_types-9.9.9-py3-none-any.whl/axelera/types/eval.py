# Copyright Axelera AI, 2024
# Evaluation Data Classes: These classes are interfaces to transform evaluation
# data from an AxTaskMeta and a ground truth in a custom dataset into a format
# suitable for evaluators. Thus, the design of evaluation data classes is closely
# aligned with both task metadata and evaluator architectures.
from __future__ import annotations

import abc
import sys
from typing import Any, Callable, Iterator, TextIO, Tuple


class BaseEvalSample(abc.ABC):
    """
    Abstract base class representing a sample of evaluation data.

    This class defines the interface for evaluation samples used by evaluators.
    Subclasses must implement the `data` property to provide access to the sample data.

    The `data` property can return either:
    1. A single instance of sample data (e.g., an image, text, or any other data type)
    2. A dictionary mapping strings to sample data
       (e.g., {'image': image_data, 'label': label_data})

    The choice between these two formats depends on the specific requirements of the evaluator
    and the complexity of the evaluation task.
    """

    @property
    @abc.abstractmethod
    def data(self) -> Any | dict[str, Any]:
        """
        Provides access to the evaluation sample data.

        Returns:
            Any | dict[str, Any]: Either a single data instance or a dictionary
            mapping strings to sample data.

        Raises:
            NotImplementedError: If the subclass does not implement this property.
        """
        raise NotImplementedError("Subclasses must implement the 'data' property.")

    def __repr__(self) -> str:
        """
        Returns a string representation of the BaseEvalSample instance.

        This method provides a default implementation that can be overridden by subclasses
        for more specific representations.

        Returns:
            str: A string representation of the BaseEvalSample instance.
        """
        return f"{self.__class__.__name__}(data={self.data})"


class EvalResult:
    """
    A class to encapsulate the result of an evaluation, storing metrics and their aggregated
    values.
    Args:
        metric_names (list[str]): A list of metric names.
        aggregators (dict[str, list[str]] | None): A dictionary where keys are metric names.
            Each key maps to a list of aggregator names. This is optional.
        key_metric (str | None): The name of the key metric.
        key_aggregator (str | None): The name of the aggregator for the key metric.
            This is optional.
    Attributes:
        metrics_result (dict[str, dict[str, float] | float]): A dictionary where keys
            are metric names.
            Each key maps to either a single float (the metric's value) or a dictionary of
            aggregated values. This inner dictionary maps aggregator names to their
            respective values.
    Example usage:
        metrics = ['accuracy', 'loss']
        aggregators = {'loss': ['mean', 'std']}
        key_metric = 'accuracy'
        key_aggregator = None
        result = EvalResult(metrics, aggregators, key_metric, key_aggregator)
        result.set_metric_result('accuracy', 0.95, is_percentage=True)
        result.set_metric_result('loss', 0.1, 'mean')
        result.set_metric_result('loss', 0.01, 'std')
        # Iterating over results to display them
        for metric_name, aggregator_name, value in result:
            print(f"Metric: {metric_name}, Aggregator: {aggregator_name}, Value: {value}")
    """

    def __init__(
        self,
        metric_names: list[str],
        aggregators: dict[str, list[str]] | None = None,
        key_metric: str | None = None,
        key_aggregator: str | None = None,
    ):
        """
        Initializes the EvalResult with metric names and optional aggregators.
        """
        self._custom_print_function = None
        self._percentage_metrics = set()
        self.metrics_result = {}
        for metric in metric_names:
            if aggregators and metric in aggregators:
                self.metrics_result[metric] = dict.fromkeys(aggregators[metric], None)
            else:
                self.metrics_result[metric] = None

        if key_metric:
            if key_metric not in metric_names:
                raise ValueError(
                    f"Key metric '{key_metric}' was not registered during initialization."
                )
            if key_aggregator:
                if key_metric not in self.metrics_result:
                    raise ValueError(f"Metric '{key_metric}' not found in metrics_result.")
                if not isinstance(self.metrics_result[key_metric], dict):
                    raise ValueError(f"Metric '{key_metric}' does not use aggregators.")
                if key_aggregator not in self.metrics_result[key_metric]:
                    raise ValueError(
                        f"Aggregator '{key_aggregator}' for key metric '{key_metric}' "
                        "was not registered during initialization."
                    )
            else:
                if (
                    isinstance(self.metrics_result[key_metric], dict)
                    and len(self.metrics_result[key_metric]) > 1
                ):
                    raise ValueError(
                        f"Aggregator required for metric '{key_metric}' with multiple aggregators."
                    )
            self._key_metric = key_metric
            self._key_aggregator = key_aggregator
        else:
            self._key_metric = None
            self._key_aggregator = None

    @property
    def key_metric(self):
        """Return the value of the key metric, formatted as a percentage if applicable."""
        if self._key_metric:
            value = self.get_metric_result(self._key_metric, self._key_aggregator)
            if (self._key_metric, self._key_aggregator) in self._percentage_metrics:
                return f"{value:.2%}"
            return value
        else:
            return None

    def set_metric_result(
        self,
        metric_name: str,
        value: Any,
        aggregator: str | None = None,
        is_percentage: bool = False,
    ):
        """
        Sets the result for a specific metric, optionally using an aggregator.

        Args:
            metric_name (str): The name of the metric.
            value (Any): The value of the metric. The value of the metric. It can be of any
                         type (int, float, or str).
            aggregator (str | None): The aggregator used for the metric (if applicable).
            is_percentage (bool): Flag indicating if the metric should be treated as a percentage.

        Raises:
            KeyError: If the metric is not registered during initialization.
            ValueError: If the metric requires an aggregator but none is provided, or if a value
                    is marked as a percentage number but is not a valid float.
        """
        if metric_name not in self.metrics_result:
            raise KeyError(f"Metric '{metric_name}' was not registered during initialization.")

        if aggregator:
            if metric_name in self.metrics_result and isinstance(
                self.metrics_result[metric_name], dict
            ):
                self.metrics_result[metric_name][aggregator] = value
            else:
                raise ValueError(f"No aggregators defined for metric '{metric_name}'.")
        else:
            if metric_name in self.metrics_result and isinstance(
                self.metrics_result[metric_name], dict
            ):
                raise ValueError(f"Aggregator required for metric '{metric_name}'.")
            self.metrics_result[metric_name] = value

        if is_percentage:
            if isinstance(value, float) and 0 <= value <= 1:
                self._percentage_metrics.add((metric_name, aggregator))
            else:
                raise ValueError(
                    f"Metric '{metric_name}' is marked as percentage but the value "
                    f"({value}) is not a float between 0 and 1."
                )

    def get_metric_result(self, metric_name: str, aggregator: str | None = None):
        """
        Retrieves the result for a specific metric, optionally using an aggregator.
        """
        if metric_name not in self.metrics_result:
            raise KeyError(f"Metric '{metric_name}' not found.")

        if aggregator:
            if isinstance(self.metrics_result[metric_name], dict):
                if aggregator in self.metrics_result[metric_name]:
                    return self.metrics_result[metric_name][aggregator]
                else:
                    raise KeyError(
                        f"Aggregator '{aggregator}' not found for metric '{metric_name}'."
                    )
            else:
                raise ValueError(f"Metric '{metric_name}' does not use aggregators.")
        else:
            if isinstance(self.metrics_result[metric_name], dict):
                raise ValueError(f"Aggregator required for metric '{metric_name}'.")
            return self.metrics_result[metric_name]

    def __iter__(self) -> Iterator[Tuple[str, str, float]]:
        """
        Iterator that yields tuples of (metric_name, aggregator_name, value).
        Aggregator_name is an empty string if not applicable.
        """
        for metric, value_or_dict in self.metrics_result.items():
            if isinstance(value_or_dict, dict):
                for aggregator, value in value_or_dict.items():
                    formatted_value = (
                        f"{value:.2%}"
                        if (metric, aggregator) in self._percentage_metrics
                        else value
                    )
                    yield (metric, aggregator, formatted_value)
            else:
                formatted_value = (
                    f"{value_or_dict:.2%}"
                    if (metric, None) in self._percentage_metrics
                    else value_or_dict
                )
                yield (metric, "", formatted_value)

    @property
    def custom_print_function(self) -> Callable[[EvalResult, TextIO], None] | None:
        """Get the custom print function."""
        return self._custom_print_function

    @custom_print_function.setter
    def custom_print_function(self, print_function: Callable[[EvalResult, TextIO], None] | None):
        """
        Set the custom print function for the evaluation results.

        Args:
            print_function (Callable[[EvalResult, TextIO], None] | None): A function that takes
                an EvalResult instance and a TextIO stream as arguments and prints the results.

        Raises:
            ValueError: If the provided print_function is not callable.

        Example:
            def my_custom_print(eval_result: EvalResult, stream: TextIO):
                stream.write(f"Key Metric: {eval_result.key_metric}\n")
                for metric_name, aggregator_name, value in eval_result:
                    stream.write(f"{metric_name}: {value} ({aggregator_name})\n")

            result = EvalResult(...)
            result.custom_print_function = my_custom_print

            # Print to stdout
            result.print_results()

            # Print to a file
            with open('results.txt', 'w') as f:
                result.print_results(stream=f)
        """
        if print_function is not None and not callable(print_function):
            raise ValueError("Custom print function must be callable.")
        self._custom_print_function = print_function

    def print_results(self, stream: TextIO = sys.stdout):
        """
        Print the evaluation results using the custom print function if set.

        Args:
            stream (TextIO): The output stream to write to. Defaults to sys.stdout.
        """
        if self._custom_print_function:
            self._custom_print_function(self, stream)
        else:
            raise ValueError(
                "No custom print function set. Use 'custom_print_function' to set one."
            )


class Evaluator(abc.ABC):
    """
    Abstract base class for an evaluator that processes data samples and computes metrics.

    This class provides a unified evaluation approach using the `process_meta` and
    `collect_metrics` methods, which can handle both offline and online evaluation scenarios.

    Online Evaluation:
    - Process samples incrementally as they become available and update the evaluation metrics
      on-the-fly.
    - Implement `process_meta` to incrementally update the evaluation metrics using the
      information from each sample.
    - Implement `collect_metrics` to return the current state of the evaluation metrics.
    - Recommended for efficient, memory-friendly processing, especially for large datasets or
      streaming scenarios.
    - Allows for incremental metric updates without storing all samples in memory.

    Offline Evaluation:
    - Process all samples at once and then compute the evaluation metrics.
    - Implement `process_meta` to collect and store the necessary information from each sample.
    - Implement `collect_metrics` to compute the final evaluation metrics using the collected
      information.
    - Provided primarily to facilitate integration with existing offline evaluators common in
      the ML domain, but it can be memory-intensive and less efficient compared to the online
      evaluation approach.
    """

    @abc.abstractmethod
    def __init__(self, **kwargs):
        """
        Initializes the Evaluator.

        This constructor allows for flexible initialization. Typically, if you have an existing
        evaluator, you can pass it here to wrap it with this interface without reimplementing
        everything. For example:

        Args:
            **kwargs: Arbitrary keyword arguments. Common usage includes:
                existing_evaluator: An instance of an existing evaluator to be wrapped.

        Example:
            # Wrapping an existing evaluator
            my_evaluator = MyExistingEvaluator()
            types_evaluator = Evaluator(existing_evaluator=my_evaluator)

            # Or creating a new evaluator with custom parameters
            types_evaluator = Evaluator(metric_type='mAP', iou_threshold=0.5)
        """
        pass

    @abc.abstractmethod
    def process_meta(self, meta: "AxTaskMeta") -> None:
        """
        Process a single data sample for evaluation.

        This method processes an individual sample containing ground truth and predictions,
        updating internal state, metrics, or collecting necessary information based on the sample.

        Args:
            meta (AxTaskMeta): An instance of AxTaskMeta containing the task metadata
                               for a single sample.

        Note:
            - To access the ground truth, use meta.access_ground_truth()
            - To access the image id, use meta.access_image_id(). This can be useful for
              passing filenames to the evaluator
            - To convert the predictions to evaluation format, use meta.to_evaluation()
        """
        pass

    @abc.abstractmethod
    def collect_metrics(self, key_metric_aggregator: str | None = None) -> EvalResult:
        """
        Aggregate and return the computed metrics for evaluation.

        This method aggregates the metrics or information collected by multiple calls to
        `process_meta` and returns the final evaluation results.

        Args:
            key_metric_aggregator (str | None): Name of the metric aggregator combination
                to be used as the key metric. If None, use the default key metric.

        Returns:
            EvalResult: An object containing the aggregated evaluation results and metrics.
        """
        pass


AxTaskMeta = Any  # AxTaskMeta is defined in axelera.app.meta
