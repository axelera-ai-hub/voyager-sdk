# Copyright Axelera AI, 2024
# Base model class
from __future__ import annotations

import abc
from typing import TYPE_CHECKING, Callable, Sequence

from .shared import ParameterSharingMixin

if TYPE_CHECKING:
    import numpy as np
    import onnx
    import PIL.Image
    import torch

    from axelera import types

    PreprocessFn = Callable[[PIL.Image.Image | np.ndarray], torch.Tensor]


class BaseModel(abc.ABC):
    """Base class with internal helper functions for model implementations."""

    task_category: types.TaskCategory | None = None
    input_tensor_shape: Sequence[int] | None = None
    input_tensor_layout: types.TensorLayout | None = None
    input_color_format: types.ColorFormat | None = None


class Model(BaseModel, ParameterSharingMixin):
    """Base Model class to be implemented when creating a new model."""

    @abc.abstractmethod
    def init_model_deploy(
        self, model_info: types.ModelInfo, dataset_config: dict, **kwargs
    ) -> None:
        """Post construction initialisation.

        For example load model weights, initialize the model, etc.

        Args:
            model_info: model info for the model.
            dataset_config: dataset config as read from the yaml file under datasets section.
            kwargs: extra keyword arguments which can be configured from the key extra_kwargs in
             the yaml file.
        """
        ...

    def to_device(self, device: torch.device) -> None:
        """Optional: implement to move model to the device.

        Args:
            device: A torch.device object to move the model to.
        """

    def override_preprocess(self, img: PIL.Image.Image | np.ndarray) -> torch.Tensor:
        """
        Optional: provide an implementation of the preprocessing pipeline.
        Usually you should not implement anything, in which case the
        application framework will generate the preprocessing transforms
        automatically from a YAML-specified pipeline.

        Note that if you choose to implement this method, the application
        framework will only be able to deploy individual models and not
        end-to-end pipelines, which means you will be required to build
        your own pipeline manually using the deployed models and Gstreamer.

        This method is useful for bringing up your own model that is not
        supported by the SDK. By implementing this method and declaring
        the usage of representative images in the YAML dataset section,
        you are good to deploy your model. You can then use the inference
        APIs to build your own pipeline and verify it independently.
        We encourage users to map this preprocess function as YAML operators
        described in the YAML pipeline section. This enables pipeline
        compilation and validation processes, ensuring the accuracy of
        your application.

        Args:
            img: the image to preprocess. This may be either a PIL image or a
            numpy array depending on the data source (e.g. dataset or video).
            Implementations can choose to avoid conversions if they are not
            necessary (e.g. using cv2.resize vs PIL.Image.resize).

        Returns:
            a torch tensor.

        Raises:
            None
        """


class ONNXModel(Model):
    """This class is used to create a Model instance with onnx_model"""

    def __init__(self):
        self._onnx_model: onnx.ModelProto | None = None

    def init_model_deploy(
        self, model_info: types.ModelInfo, dataset_config: dict, **kwargs
    ) -> None:
        import onnx

        if model_info and model_info.weight_path:
            self._onnx_model = onnx.load(model_info.weight_path)
        else:
            raise ValueError("model_info.weight_path is required")

    @property
    def onnx_model(self) -> onnx.ModelProto | None:
        return getattr(self, "_onnx_model", None)

    @onnx_model.setter
    def onnx_model(self, onnx_model: onnx.ModelProto):
        self._onnx_model = onnx_model
