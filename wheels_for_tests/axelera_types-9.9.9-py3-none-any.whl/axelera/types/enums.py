# Copyright Axelera AI, 2025
# Enums types used by ModelInfo and Manifest

import enum
import functools
import operator
import sys
from typing import Type


def _parse_enum(cls: Type[enum.Enum], x: enum.Enum | str) -> enum.Enum:
    """Flexibly parse an enum.Enum instance from string, or enum.Enum.

    If the input is not convertible then a ValueError is raised. If the input
    is not a supported type then TypeError is raised.

    Strings are matched case-insensitively.
    """
    if isinstance(x, str):
        lower = {k.lower(): v for k, v in cls.__members__.items()}
        try:
            return lower[x.lower().strip()]
        except KeyError:
            ok = " ".join(cls.__members__)
            raise ValueError(f"Unknown {cls.__name__} {x}, valid options are {ok}") from None
    elif not isinstance(x, cls):
        raise TypeError(f"Invalid type for {cls.__name__} `{type(x).__name__}`, use str")
    return x


def _parse_flags(
    cls: Type[enum.Enum], x: enum.Enum | str | list[str] | list[enum.Enum]
) -> enum.Enum:
    """Flexibly parse an enum.Flag instance from string, strings, or enum.Flag.

    For string input, multiple items can be separated with the `|` character.

    If the input is not convertible then a ValueError is raised. If the input
    is not a supported type then TypeError is raised.

    Strings are matched case-insensitively.
    """
    if isinstance(x, list):
        x = functools.reduce(operator.or_, [_parse_enum(cls, t) for t in x])
    elif isinstance(x, str):
        x = functools.reduce(operator.or_, [_parse_enum(cls, t) for t in x.split("|")])
    elif not isinstance(x, cls):
        raise TypeError(
            f"Invalid type for {cls.__name__} `{type(x).__name__}`, use str or list[str]"
        )
    return x


class TaskCategory(enum.Flag):
    # Classification tasks
    Classification = enum.auto()
    ClassificationAttribute = enum.auto()
    ClassificationDomainSpecific = enum.auto()
    ClassificationContentFiltering = enum.auto()

    # Detection tasks
    ObjectDetection = enum.auto()
    ObjectDetectionOpenVocabulary = enum.auto()
    ObjectDetection3D = enum.auto()
    KeypointDetection = enum.auto()

    # Segmentation tasks
    SemanticSegmentation = enum.auto()
    InstanceSegmentation = enum.auto()

    # Image Enhancement tasks
    ImageEnhancementSuperResolution = enum.auto()
    ImageEnhancementLowLightEnhancement = enum.auto()
    ImageEnhancementOther = enum.auto()

    # Recognition tasks
    FaceRecognition = enum.auto()
    LicensePlateRecognition = enum.auto()
    OpticalCharacterRecognition = enum.auto()
    Recognition_Other = enum.auto()

    # Other vision tasks
    ImageTranslation = enum.auto()
    DepthEstimation = enum.auto()
    ReIdentification = enum.auto()
    ObjectTracking = enum.auto()
    ADAS = enum.auto()

    # Models that work across modalities
    Multimodal = enum.auto()  # Base category for multimodal understanding
    PoseSegmentation = enum.auto()  # Combines pose estimation and segmentation
    TextImageRetrieval = enum.auto()  # CLIP, ALIGN, etc.

    # Generative tasks including image and video generation
    VisualQuestionAnswering = enum.auto()  # VQA (Image + Text -> Text)
    ImageCaptioning = enum.auto()  # (Image -> Text)
    GenerativeTextToImage = enum.auto()  # DALL-E, Stable Diffusion, Midjourney
    GenerativeImageToImage = enum.auto()  # Style transfer, inpainting, outpainting
    GenerativeTextToVideo = enum.auto()
    GenerativeImageToVideo = enum.auto()

    # Text Generation
    LanguageModel = enum.auto()  # Instead of Small/Large distinction

    # Please keep this at the end of the enum to preserve the intended order.
    # 'Experimental' indicates tasks that are not officially supported by the SDK;
    # use this category only if none of the above categories match your task.
    Experimental = enum.auto()

    parse = classmethod(_parse_flags)


if sys.version_info < (3, 11):
    TaskCategory.__len__ = lambda self: sum(
        bool(x & self) for x in TaskCategory.__members__.values()
    )
    TaskCategory.__iter__ = lambda self: iter(
        [x for x in TaskCategory.__members__.values() if x & self]
    )


class TensorLayout(enum.Enum):
    NCHW = enum.auto()
    NHWC = enum.auto()
    CHWN = enum.auto()

    parse = classmethod(_parse_enum)


class ColorFormat(enum.Enum):
    RGB = enum.auto()
    BGR = enum.auto()
    RGBA = enum.auto()
    BGRA = enum.auto()
    GRAY = enum.auto()
    I420 = enum.auto()
    NV12 = enum.auto()
    NV16 = enum.auto()
    YUY2 = enum.auto()

    parse = classmethod(_parse_enum)


class DatasetSplit(enum.Enum):
    TRAIN = enum.auto()
    VAL = enum.auto()
    TEST = enum.auto()

    parse = classmethod(_parse_enum)


class ImageReader(enum.Enum):
    PIL = enum.auto()
    OPENCV = enum.auto()

    parse = classmethod(_parse_enum)


class BoxFormat(enum.Enum):
    """
    Box format for object detection.
    XYXY: Represents bounding boxes with (x1, y1, x2, y2) coordinates,
          where (x1, y1) is the top-left corner and (x2, y2) is the bottom-right corner.
    XYWH: Represents bounding boxes with (x, y, w, h) coordinates,
          where (x, y) is the center of the box, w is the width, and h is the height.
          Also known as CXCYWH
    LTWH: Represents bounding boxes with (x, y, w, h) coordinates,
          where (x, y) is the top-left corner, w is the width, and h is the height.
          Also known as LTXYWH
    XYWHR: Represents oriented bounding boxes with (x, y, w, h, r) coordinates,
          where (x, y) is the center of the box, w is the width, h is the height, and r is the rotation angle in radians.
          Also known as CXCYWHR
    XYXYXYXY: Represents any quadrilateral with (x1, y1, x2, y2, x3, y3, x4, y4) coordinates,
          where (x1, y1), (x2, y2), (x3, y3), and (x4, y4) are the four corners of the quadrilateral.
          Specifically, this format can represent oriented rectangles for
          Oriented Bounding Box (OBB) object detection models.
    """

    XYXY = enum.auto()
    XYWH = enum.auto()
    CXCYWH = XYWH
    LTWH = enum.auto()
    LTXYWH = LTWH
    XYWHR = enum.auto()
    CXCYWHR = XYWHR
    XYXYXYXY = enum.auto()

    parse = classmethod(_parse_enum)


class ResizeMode(enum.Enum):
    """
    Resize mode for image resizing, optimized for edge AI applications with fixed output sizes.

    STRETCH: Resizes the image to the target size without preserving aspect ratio.
    LETTERBOX_FIT: Resizes the image to fit the longest edge to the target size,
                   preserving aspect ratio, then adds padding to reach the target size.
    LETTERBOX_CONTAIN: Resizes the image to fit within the target size if larger, preserving
                       aspect ratio, then adds padding to reach the target size. Doesn't scale up
                       smaller images.
    SQUISH: Resizes the image based on the longest edge, preserving aspect ratio. Pads
            the image at the right and bottom to reach the target size. This is expected
            to be the fastest mode, as it reduces the amount of pixel processing at inference
            and potentially eliminates additional rescaling computation at the decoder, as
            video is typically rectangular.
    ORIGINAL: At the original image size without resizing.
    """

    STRETCH = enum.auto()
    LETTERBOX_FIT = enum.auto()
    LETTERBOX_CONTAIN = enum.auto()
    SQUISH = enum.auto()
    ORIGINAL = enum.auto()

    parse = classmethod(_parse_enum)


class ModelType(enum.Enum):
    """
    Model type for model.
    """

    DEEP_LEARNING = enum.auto()
    CLASSICAL_CV = enum.auto()

    parse = classmethod(_parse_enum)
