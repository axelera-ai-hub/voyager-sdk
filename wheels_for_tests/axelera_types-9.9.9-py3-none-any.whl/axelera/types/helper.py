# Copyright Axelera AI, 2024
# Helper functions for the types module
from __future__ import annotations

import logging
from pathlib import Path
from typing import TYPE_CHECKING, Callable

import numpy as np

from . import img
from .enums import ColorFormat, ImageReader

if TYPE_CHECKING:
    import PIL
    import torch

LOG = logging.getLogger(__name__)


def build_dataloader_from_img_dir(
    image_dir: str,
    transform: callable,
    batch_size: int,
    imreader_backend: ImageReader = ImageReader.PIL,
    color_format: ColorFormat = ColorFormat.RGB,
    transform_input_type: str = "PIL",
    generator: torch.Generator | None = None,
):
    repr_dataset = SimpleImageDataset(
        image_dir=image_dir,
        transform=transform,
        imreader_backend=imreader_backend,
        color_format=color_format,
        transform_input_type=transform_input_type,
    )
    from torch.utils.data import DataLoader

    return DataLoader(repr_dataset, batch_size=batch_size, shuffle=True, generator=generator)


class SimpleImageDataset:
    def __init__(
        self,
        image_dir: str | Path,
        transform: Callable | None = None,
        imreader_backend: ImageReader = ImageReader.PIL,
        color_format: ColorFormat = ColorFormat.RGB,
        transform_input_type: str = "PIL",
    ) -> None:
        """Initialize the dataset for loading and transforming images.

        Args:
            image_dir: Directory path containing the image files. Supports common formats
                like jpg, png, bmp, etc.
            transform: Optional callable that takes an image and returns a transformed
                version. Applied after loading.
            imreader_backend: Backend library to use for reading images. Either
                ImageReader.PIL (default) or ImageReader.OPENCV.
            color_format: Target color format for the loaded images. One of:
                - ColorFormat.RGB, ColorFormat.BGR, ColorFormat.GRAY
            transform_input_type: Specifies the type of image object passed to the transform:
                - "PIL": PIL.Image.Image object
                - "numpy": numpy.ndarray array
                - "axelera": axelera.types.Image object
        """
        if color_format not in [ColorFormat.RGB, ColorFormat.BGR, ColorFormat.GRAY]:
            raise ValueError(f"Unsupported color format: {color_format}")
        if transform_input_type not in ["PIL", "numpy", "axelera"]:
            raise ValueError(f"Unsupported transform input type: {transform_input_type}")

        self.color_format = color_format
        self.transform_input_type = transform_input_type
        if imreader_backend == ImageReader.OPENCV:
            import cv2

            self.imread = cv2.imread
        else:
            import PIL

            self.imread = PIL.Image.open

        self.directory = Path(image_dir)
        self.transform = transform

        self.image_paths = []
        img_formats = ["bmp", "jpg", "jpeg", "png", "tif", "tiff", "dng", "webp", "mpo"]
        img_formats += [format.upper() for format in img_formats]
        for ext in img_formats:
            self.image_paths.extend(self.directory.glob(f"*.{ext}"))

        LOG.debug(f"Found {len(self.image_paths)} images in {self.directory}")

    def __len__(self):
        return len(self.image_paths)

    def __getitem__(self, idx: int) -> img.Image:
        """Load and process an image from the dataset.

        Args:
            idx: Index of the image to load

        Returns:
            Processed image in the requested color format
        """
        image_path = self.image_paths[idx]
        image = self.imread(str(image_path))

        if isinstance(image, np.ndarray):
            image = self._process_opencv_image(image)
        else:
            image = self._process_pil_image(image)

        if self.transform:
            if self.transform_input_type == "PIL":
                transform_input = image.aspil()
            elif self.transform_input_type == "numpy":
                transform_input = image.asarray()
            else:
                transform_input = image

            image = self.transform(transform_input)

        return image

    def _process_opencv_image(self, image: np.ndarray) -> img.Image:
        if len(image.shape) == 2 or (len(image.shape) == 3 and image.shape[2] == 1):
            # For grayscale images, ensure it's 3D array
            image = image.squeeze()[..., np.newaxis]
            source_format = ColorFormat.GRAY
        else:
            source_format = ColorFormat.BGR

        axelera_image = img.Image.fromarray(image, source_format)
        if self.color_format != source_format:
            return img.Image.fromarray(
                axelera_image.asarray(format=self.color_format), self.color_format
            )
        return axelera_image

    def _process_pil_image(self, pil_image: PIL.Image.Image) -> img.Image:
        if pil_image.mode == "L":
            # For grayscale images, create Image directly with GRAY format
            axelera_image = img.Image.frompil(pil_image, ColorFormat.GRAY)
            if self.color_format != ColorFormat.GRAY:
                return img.Image.fromarray(
                    axelera_image.asarray(format=self.color_format), self.color_format
                )
            return axelera_image

        # Handle RGB images as before
        axelera_image = img.Image.frompil(pil_image, ColorFormat.RGB)
        if self.color_format != ColorFormat.RGB:
            return img.Image.fromarray(
                axelera_image.asarray(format=self.color_format), self.color_format
            )
        return axelera_image
