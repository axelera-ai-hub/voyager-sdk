# Copyright Axelera AI, 2024
# Shared data structures for pipeline input/output data,
# and mixin for parameter sharing between types.Model and types.Data
from __future__ import annotations

import dataclasses
from typing import TYPE_CHECKING, Any, Tuple, Type

from typing_extensions import Self

from . import enums, eval, img

if TYPE_CHECKING:
    import numpy as np
    import PIL.Image

    from axelera import types


def _ensure_list(value):
    if not isinstance(value, list):
        return [value]
    return value


def _ensure_color_format(
    color_format: enums.ColorFormat | str | None,
) -> enums.ColorFormat:
    if color_format is None:
        raise ValueError("color_format must be provided if img is not types.Image")
    elif isinstance(color_format, str):
        color_format = enums.ColorFormat.parse(color_format)
    return color_format


@dataclasses.dataclass
class FrameInput:
    """
    Parameters:
    img (types.Image | None): Single Axelera Image object in RGB format.
    imgs (Tuple[types.Image, types.Image] | None): Tuple of two Axelera Image objects
        for pair validation.
    img_id (str | int): Unique identifier for the image(s).
    ground_truth (types.BaseEvalSample | None): Ground truth data for the image(s),
        which varies by task.
    stream_id (int): Identifier for the data stream, defaults to 0.

    Note: Exactly one of 'img' or 'imgs' must be provided.

    Usage Examples:
    1. Creating a FrameInput from a single image:
       ```python
       import cv2
       from PIL import Image
       from axelera import types

       # Using OpenCV (BGR by default, but preprocessing converts to RGB)
       cv_image = cv2.imread('image.jpg')
       frame_input = types.FrameInput.from_image(
           cv_image,
           color_format=types.ColorFormat.RGB,
           img_id='image1'
       )

       # Using PIL (RGB by default)
       pil_image = Image.open('image.jpg')
       frame_input = types.FrameInput.from_image(
           pil_image,
           color_format=types.ColorFormat.RGB,
           img_id='image2'
       )

       # Using Axelera Image (color_format already handled when creating ax_image)
       ax_image = img.fromany(cv2.imread('image.jpg'), types.ColorFormat.BGR)
       frame_input = types.FrameInput.from_image(ax_image, img_id='image3')
       ```

    2. Creating a FrameInput from a pair of images:
       ```python
       import cv2
       from axelera import types

       image1 = cv2.imread('image1.jpg')
       image2 = cv2.imread('image2.jpg')
       frame_input = types.FrameInput.from_image_pair(
           image1,
           image2,
           color_format=types.ColorFormat.BGR,
           img_id='pair1'
       )
       ```

    3. Direct instantiation (not recommended for external use):
       ```python
       from axelera import types

       ax_image = img.fromany(cv2.imread('image.jpg'), types.ColorFormat.BGR)
       frame_input = types.FrameInput(img=ax_image, img_id='direct1')
       ```
    """

    img: types.Image | None = None
    imgs: Tuple[types.Image, types.Image] | None = None
    img_id: str | int = dataclasses.field(default="")
    ground_truth: types.BaseEvalSample | None = dataclasses.field(default=None)
    stream_id: int = dataclasses.field(default=0, repr=False)

    def __post_init__(self):
        self._validate_input()
        self._validate_types()

    def _validate_input(self):
        if (self.img is None) == (self.imgs is None):
            raise ValueError("Exactly one of 'img' or 'imgs' must be provided")

    def _validate_types(self):
        if self.img is not None and not isinstance(self.img, img.Image):
            raise TypeError("img must be of type img.Image")
        if self.imgs is not None:
            if (
                not isinstance(self.imgs, tuple)
                or len(self.imgs) != 2
                or not all(isinstance(i, img.Image) for i in self.imgs)
            ):
                raise TypeError("imgs must be a tuple of two img.Image objects")
        if not isinstance(self.img_id, (str, int)):
            raise TypeError("img_id must be of type str or int")
        if self.ground_truth is not None and not isinstance(
            self.ground_truth, eval.BaseEvalSample
        ):
            raise TypeError(
                f"ground_truth must be of type BaseEvalSample, "
                f"got {type(self.ground_truth).__name__}"
            )
        if not isinstance(self.stream_id, int):
            raise TypeError(f"stream_id must be of type int, got {type(self.stream_id).__name__}")

    @classmethod
    def from_image(
        cls,
        img: types.Image | PIL.Image.Image | np.ndarray,
        color_format: types.ColorFormat | str | None = None,
        img_id: str | int = "",
        ground_truth: types.BaseEvalSample | None = None,
        stream_id: int = 0,
    ) -> Self:
        """Create a FrameInput instance from a single image.
        Args:
            img: Image to be converted to Axelera Image.
            color_format: It must be provided if img is not a types.Image
            img_id: Unique identifier for the image. Useful for debugging.
            ground_truth: Ground truth data for the image. Used for accuracy evaluation.
            stream_id: Identifier for the data stream. Used for multi-stream processing.
        """
        from .img import Image, fromany

        if isinstance(img, Image):
            ax_image = img
        else:
            color_format = _ensure_color_format(color_format)
            ax_image = fromany(img, color_format)

        return cls(img=ax_image, img_id=img_id, ground_truth=ground_truth, stream_id=stream_id)

    @classmethod
    def from_image_pair(
        cls,
        img1: types.Image | PIL.Image.Image | np.ndarray,
        img2: types.Image | PIL.Image.Image | np.ndarray,
        color_format: types.ColorFormat | str | None = None,
        img_id: str | int = "",
        ground_truth: types.BaseEvalSample | None = None,
        stream_id: int = 0,
    ) -> Self:
        """Create a FrameInput instance from a pair of images.
        We don't want different types of images in the pair because OpenCV and PIL images
        have different default color formats and we want to avoid confusion. You should ensure
        the images are of the same color format and type before passing them to this method.
        """
        if type(img1) is not type(img2):
            raise TypeError("Both images in the pair must be of the same type")
        if isinstance(img1, img.Image):
            ax_image1 = img1
            ax_image2 = img2
        else:
            color_format = _ensure_color_format(color_format)
            ax_image1 = img.fromany(img1, color_format)
            ax_image2 = img.fromany(img2, color_format)
        return cls(
            imgs=(ax_image1, ax_image2),
            img_id=img_id,
            ground_truth=ground_truth,
            stream_id=stream_id,
        )

    def __repr__(self):
        image_repr = f"img={self.img!r}" if self.img is not None else f"imgs={self.imgs!r}"
        return (
            f"FrameInput({image_repr}, img_id={self.img_id!r}, "
            f"ground_truth={self.ground_truth!r}, stream_id={self.stream_id})"
        )

    def __eq__(self, other):
        if not isinstance(other, FrameInput):
            return NotImplemented
        return (
            self.img == other.img
            and self.imgs == other.imgs
            and self.ground_truth == other.ground_truth
            and self.img_id == other.img_id
            and self.stream_id == other.stream_id
        )


class SharedParameterError(Exception):
    """Exception raised for errors in the shared parameters between Model and DataAdapter."""

    def __init__(self, key: str):
        self.key = key
        self.message = (
            f"Shared parameter '{key}' is required but not set. Ensure it is set "
            f"by the appropriate class that uses this mixin."
        )
        super().__init__(self.message)


class ParameterSharingMixin:
    """
    A mixin class that provides shared parameter functionality for Model and DataAdapter classes.

    This mixin is designed to improve the clarity and maintainability of code that combines
    Model and DataAdapter functionalities. It encourages developers to explicitly declare and
    document the parameters that a DataAdapter expects the Model to set up during initialization.

    Key benefits:
    1. Explicit Interface: Clearly defines the expected shared parameters between Model and
       DataAdapter.
    2. Documentation as Code: The use of shared parameters serves as self-documenting code,
       making it clear what data is passed between Model and DataAdapter.
    3. Flexibility: Allows for easy extension and modification of shared parameters without
       changing method signatures.
    4. Decoupling: Reduces direct dependencies between Model and DataAdapter implementations,
       making the code more modular and easier to maintain.

    Usage:
    1. Inherit from this mixin in both your Model and DataAdapter classes.
    2. In your Model class, use set_shared_param in methods like init_model_deploy
       to set parameters that the DataAdapter might need.
    3. In your DataAdapter class, use get_shared_param to retrieve parameters set by the Model.
    4. When combining Model and DataAdapter into a single class, inherit from both,
       and the combined class will have access to all shared parameters.

    Note:
    - Parameters are shared across all instances of a class and its subclasses.

    Example:
        class MyModel(types.Mode):
            def init_model_deploy(self, model_info, dataset_config, **kwargs):
                self.set_shared_param('cfg', some_config)

        class MyDataAdapter(types.DataAdapter):
            def create_calibration_data_loader(self, transform, root, batch_size, **kwargs):
                cfg = self.get_shared_param('cfg')
                # Use cfg to create data loader
    """

    _shared_params_map: dict[Type, dict[str, Any]] = {}

    @classmethod
    def set_shared_param(cls, key: str, value: Any) -> None:
        cls._get_shared_params()[key] = value

    @classmethod
    def has_shared_param(cls, key: str) -> bool:
        return key in cls._get_shared_params()

    @classmethod
    def get_shared_param(cls, key: str, default: Any = None) -> Any:
        if key not in cls._get_shared_params():
            if default is None:
                raise SharedParameterError(key)
            return default
        return cls._get_shared_params()[key]

    @classmethod
    def _get_shared_params(cls) -> dict[str, Any]:
        if cls not in cls._shared_params_map:
            cls._shared_params_map[cls] = {}
        return cls._shared_params_map[cls]
