# Copyright Axelera AI, 2024

import dataclasses
import json
from typing import Any, Tuple

from .enums import TensorLayout


@dataclasses.dataclass
class Manifest:
    quantized_model_file: str
    """Path to quantized model in torch.jit.ScriptModule format.

    Quantized model is stored in torch.jit.ScriptModule format and is exported to file."""

    input_shapes: Tuple[Tuple[int, ...], ...]
    """A tuple of data shapes of input tensors."""

    input_dtypes: Tuple[str, ...]
    """A tuple of data types of input tensors."""

    output_shapes: Tuple[Tuple[int, ...], ...]
    """A tuple of data shapes of output tensors."""

    output_dtypes: Tuple[str, ...]
    """A tuple of data types from output tensors."""

    input_shapes_original: Tuple[Tuple[int, ...], ...] | None = None
    """Original input tensor shapes of the core model after graph optimization.

    These shapes represent the core model's inputs after ONNXGraphCleaner
    has separated non-AIPU operations into preamble/postamble graphs,
    but before compilation transformations.
    """

    output_shapes_original: Tuple[Tuple[int, ...], ...] | None = None
    """Original output tensor shapes of the core model after graph optimization.

    These shapes represent the core model's outputs after ONNXGraphCleaner
    has separated non-AIPU operations into preamble/postamble graphs,
    but before compilation transformations.
    """

    quantize_params: Tuple[Tuple[float, int], ...] | None = None
    """Quantization parameters for input tensor(s).

     Quantization parameters for each input tensor is represented with a tuple of shape [2] and
     consists of float scale and int offset values. To calculate quantized value the following
     formula has to be applied: quantized_value = real_value / result_scale + zero_point.
     Parameters are stored in the same order as input tensors.

     If model was only quantized (and not lowered) this parameter is set to None."""

    dequantize_params: Tuple[Tuple[float, int], ...] | None = None
    """Dequantization parameters for output tensor(s).

     Dequantization parameters for each output tensor is represented with a tuple of shape [2] and
     consists of float scale and int offset values. To calculate real value the following formula
     has to be applied: real_value = scale * (quantized_value - zero_point).
     Parameters are stored in the same order as output tensors.

     If model was only quantized (and not lowered) this parameter is set to None."""

    input_names: Tuple[str, ...] | None = None
    """A tuple of input tensors names.

    If model was only quantized (and not lowered) this parameter is set to None."""

    model_lib_file: str | None = None
    """Path to model library.

    If model was only quantized (and not lowered) this parameter is set to None."""

    model_params_file: str | None = None
    """Path to model parametrs.

    If model was only quantized (and not lowered) this parameter is set to None."""

    n_padded_ch_inputs: Tuple[Tuple[int, ...], ...] | None = None
    """Number of padded channels in input tensors.

    For each dimension of the input tensor, the number of padded channels is represented by two
    numbers: the number of padded channels before the contents of tensor in that dimension and
    the number of padded channels after. Accordingly, for each input tensor the number of padded
    channels is respresented with a tuple of shape [2*n], where n is the rank of input tensor.

    E.g. for Alpha AIPU all input tensors has to be PWORD-alligned, meaning that the number of
    channels in C dimension has to be a multiple of 64. In the case of naive channel padding
    (no swICR), input tensor with NHWC layout and with shape (1, 224, 224, 3) has to be padded
    by 61 channel in C dimension. Padding has to be done after the contents of the input tensor,
    so n_padded_ch_inputs will be equal to (0, 0, 0, 0, 0, 0, 0, 61) for that input tensor.

    If model was only quantized (and not lowered) this parameter is set to None."""

    n_padded_ch_outputs: Tuple[Tuple[int, ...], ...] | None = None
    """Number of padded channels in output tensors.

    For each dimension of the output tensor, the number of padded channels is represented by two
    numbers: the number of padded channels before the contents of tensor in that dimension and
    the number of padded channels after. Accordingly, for each output tensor the number of padded
    channels is respresented with a tuple of shape [2*n], where n is the rank of output tensor.

    If model was only quantized (and not lowered) this parameter is set to None."""

    input_tensor_layout: TensorLayout | None = None
    """Data layout of input tensor(s).

    If model was only quantized (and not lowered) this parameter is set to None."""

    preprocess_graph: str | None = None
    """Path to ONNX pre-processing subgraph that is supposed to run on the host."""

    postprocess_graph: str | None = None
    """Path to ONNX post-processing subgraph that is supposed to run on the host."""

    model_metadata: dict[str, Any] | None = None
    """Model-specific metadata from external repositories.

    Values must be JSON-serializable (str, int, float, bool, None, list, dict).
    Organized by framework/repository for maintainability.
    Example: {"3rd_party_repository_name": {"task": "pose", "model": "yolov8n"}}

    If model was only quantized (and not lowered) this parameter can still be set."""

    manifest_version: str = "1.1"
    """The version number of the manifest file, this member should always be last."""

    def __post_init__(self):
        """Validate that model_metadata is JSON-serializable."""
        if self.model_metadata is not None:
            try:
                json.dumps(self.model_metadata)
            except (TypeError, ValueError) as e:
                raise TypeError(
                    f"model_metadata must contain only JSON-serializable values "
                    f"(str, int, float, bool, None, list, dict). "
                    f"Found non-serializable data: {e}"
                ) from e

    def to_dict(self) -> dict[str, Any]:
        """Convert manifest to a dictionary."""
        result = {}
        for f in dataclasses.fields(self):
            value = getattr(self, f.name)
            if isinstance(value, TensorLayout):
                value = value.name
            result[f.name] = value
        return result

    def to_json(self) -> str:
        """Convert manifest to a JSON string."""
        return json.dumps(self.to_dict(), default=self._json_default, indent=2)

    @staticmethod
    def _json_default(obj):
        if isinstance(obj, tuple):
            return list(obj)
        raise TypeError(f"Object of type {obj.__class__.__name__} is not JSON serializable")

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "Manifest":
        """Create a Manifest instance from a dictionary."""
        for key, value in data.items():
            if key == "input_tensor_layout" and isinstance(value, str):
                data[key] = TensorLayout[value]
            elif isinstance(value, list):
                data[key] = tuple(
                    tuple(item) if isinstance(item, list) else item for item in value
                )
        return cls(**data)

    @classmethod
    def from_json(cls, src: str) -> "Manifest":
        """Create a Manifest instance from a JSON string."""
        return cls.from_dict(json.loads(src))

    def is_compiled(self) -> bool:
        """Check if manifest represents a compiled model (vs just quantized)."""
        return self.model_lib_file is not None
