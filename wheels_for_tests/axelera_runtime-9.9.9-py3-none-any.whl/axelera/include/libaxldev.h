/*
 * Copyright (c) 2025 Axelera AI. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License version 2.1 as published by the Free Software Foundation
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston MA  02110-1301 USA
 *
 * SPDX-License-Identifier: LGPL-2.1-or-later
 */

#ifndef __LIBAXLDEV_H__
#define __LIBAXLDEV_H__

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <sys/time.h>

#ifdef _WIN32
#include <windows.h>
#else
#include <linux/ioctl.h>
#include <linux/types.h>
#endif

#ifdef __cplusplus
extern "C" {
#endif
#include "sysctl_mem.h"

//=============================================================
// MACROS
//=============================================================

#define AXL_MAX_DEV_NAME 80

#define AXL_MAX_FLASH_VERSION_LEN 128
#define AXL_MAX_SECURE_BOOT_LEN	  16

#define AXL_MAX_BOARD_CTRL_VERSION_LEN 128
#define AXL_MAX_BOARD_CTRL_BOARD_LEN   128
#define AXL_MAX_TEMP_SENSOR_LEN	       20

#define AXL_DMABUF_XFER_FLAG_READ  0x1
#define AXL_DMABUF_XFER_FLAG_WRITE 0x2
#define AXL_DMABUF_XFER_FLAG_SYNC  0x4
#define AXL_DMABUF_XFER_FLAG_ASYNC 0x8

#define DMA_XFER_FLAG_P2P 0x80000000

#define AXL_DMA_MAX_NR_CH 4

// File handle type definition
#ifdef _WIN32
typedef HANDLE axl_file_handle_t;
#define AXL_INVALID_FILE_HANDLE (INVALID_HANDLE_VALUE)
#define PRIfh			"p"
#else
typedef int axl_file_handle_t;
#define AXL_INVALID_FILE_HANDLE (-1)
#define PRIfh			"d"
#endif

// Compatibility macros
#ifdef _WIN32
#define MAP_FAILED	   ((void *)-1) // For mmap()
#define DMA_BUF_SYNC_START (0 << 2)
#define DMA_BUF_SYNC_END   (1 << 2)
#endif

// ============================================================
// TYPES
// ============================================================

typedef enum axl_device_mode {
	AXL_DEVICE_QEMU = 0,
	AXL_DEVICE_SILICON,
	AXL_DEVICE_UNKNOWN,
} axl_device_mode_t;

typedef enum axl_aicore {
	AXL_AICORE_0,
	AXL_AICORE_1,
	AXL_AICORE_2,
	AXL_AICORE_3,
	AXL_AICORE_UNKNOWN_ID,
} axl_aicore_t;

typedef enum axl_msi {
	AXL_MSI_CTX_0 = 0,
	AXL_MSI_CTX_1 = 1,
	AXL_MSI_CTX_2 = 2,
	AXL_MSI_CTX_3 = 3,
	AXL_MSI_RD_CH0 = 4,
	AXL_MSI_RD_CH1 = 5,
	AXL_MSI_RD_CH2 = 6,
	AXL_MSI_RD_CH3 = 7,
	AXL_MSI_WR_CH0 = 8,
	AXL_MSI_WR_CH1 = 9,
	AXL_MSI_WR_CH2 = 10,
	AXL_MSI_WR_CH3 = 11,
	AXL_MSI_MSG = 12,
	AXL_MSI_SYS_TRACE = 13,
	AXL_MSI_SYS_LOG = 14,
	AXL_MSI_TRACE_AI0 = 15,
	AXL_MSI_TRACE_AI1 = 16,
	AXL_MSI_TRACE_AI2 = 17,
	AXL_MSI_TRACE_AI3 = 18,
	AXL_MSI_LOG_AI0 = 20,
	AXL_MSI_LOG_AI1 = 21,
	AXL_MSI_LOG_AI2 = 22,
	AXL_MSI_LOG_AI3 = 23,
	AXL_MSI_DEV_AXE_MSG = 24,
	AXL_MSI_HOST_AXE_MSG = 25,
	AXL_MAX_MSI = 32,
} axl_msi_t;

typedef enum axl_virtual_msi {
	AXL_VMSI_CTRL_CORE_LOG = 30,
	AXL_VMSI_CTRL_CORE_TRACE = 31,
	AXL_VMSI_AICORE0_LOG = 35,
	AXL_VMSI_AICORE0_TRACE = 36,
	AXL_VMSI_AICORE1_LOG = 37,
	AXL_VMSI_AICORE1_TRACE = 38,
	AXL_VMSI_AICORE2_LOG = 39,
	AXL_VMSI_AICORE2_TRACE = 40,
	AXL_VMSI_AICORE3_LOG = 41,
	AXL_VMSI_AICORE3_TRACE = 42,
	AXL_VMSI_AICORE4_LOG = 43,
	AXL_VMSI_AICORE4_TRACE = 44,
	AXL_VMSI_AICORE5_LOG = 45,
	AXL_VMSI_AICORE5_TRACE = 46,
	AXL_VMSI_AICORE6_LOG = 47,
	AXL_VMSI_AICORE6_TRACE = 48,
	AXL_VMSI_AICORE7_LOG = 49,
	AXL_VMSI_AICORE7_TRACE = 50,
	AXL_VMSI_PVE_CORE0_LOG = 81,
	AXL_VMSI_PVE_CORE0_TRACE = 82,
	AXL_VMSI_PVE_CORE1_LOG = 83,
	AXL_VMSI_PVE_CORE1_TRACE = 84,
	AXL_VMSI_PVE_CORE2_LOG = 85,
	AXL_VMSI_PVE_CORE2_TRACE = 86,
	AXL_VMSI_PVE_CORE3_LOG = 87,
	AXL_VMSI_PVE_CORE3_TRACE = 88,
	AXL_VMSI_PVE_CORE4_LOG = 89,
	AXL_VMSI_PVE_CORE4_TRACE = 90,
	AXL_VMSI_PVE_CORE5_LOG = 91,
	AXL_VMSI_PVE_CORE5_TRACE = 92,
	AXL_VMSI_PVE_CORE6_LOG = 93,
	AXL_VMSI_PVE_CORE6_TRACE = 94,
	AXL_VMSI_PVE_CORE7_LOG = 95,
	AXL_VMSI_PVE_CORE7_TRACE = 96,
	AXL_VMSI_PVE_CORE8_LOG = 97,
	AXL_VMSI_PVE_CORE8_TRACE = 98,
	AXL_VMSI_PVE_CORE9_LOG = 99,
	AXL_VMSI_PVE_CORE9_TRACE = 100,
	AXL_VMSI_PVE_CORE10_LOG = 101,
	AXL_VMSI_PVE_CORE10_TRACE = 102,
	AXL_VMSI_PVE_CORE11_LOG = 103,
	AXL_VMSI_PVE_CORE11_TRACE = 104,
	AXL_VMSI_PVE_CORE12_LOG = 105,
	AXL_VMSI_PVE_CORE12_TRACE = 106,
	AXL_VMSI_PVE_CORE13_LOG = 107,
	AXL_VMSI_PVE_CORE13_TRACE = 108,
	AXL_VMSI_PVE_CORE14_LOG = 109,
	AXL_VMSI_PVE_CORE14_TRACE = 110,
	AXL_VMSI_PVE_CORE15_LOG = 111,
	AXL_VMSI_PVE_CORE15_TRACE = 112,
} axl_virtual_msi_t;

typedef enum axl_clock_profile {
	AXL_CLOCK_PROFILE_100MHZ,
	AXL_CLOCK_PROFILE_200MHZ,
	AXL_CLOCK_PROFILE_400MHZ,
	AXL_CLOCK_PROFILE_600MHZ,
	AXL_CLOCK_PROFILE_700MHZ,
	AXL_CLOCK_PROFILE_800MHZ,
	AXL_CLOCK_PROFILE_MAX,
	AXL_CLOCK_PROFILE_UNKNOWN,
} axl_clock_profile_t;

typedef enum axl_lpddr_speed {
	AXL_LPDDR_SPEED_GRADE_INVALID,
	AXL_LPDDR_SPEED_GRADE_4267,
	AXL_LPDDR_SPEED_GRADE_3200,
	AXL_LPDDR_SPEED_GRADE_2400,
	AXL_LPDDR_SPEED_GRADE_1600,
	AXL_LPDDR_SPEED_GRADE_800,
	AXL_LPDDR_SPEED_GRADE_MAX,
} axl_lpddr_speed_t;

typedef enum axl_flash_type {
	AXL_FLASH_TYPE_METIS = 0,
	AXL_FLASH_TYPE_BOARD_CONTROLLER = 1,
	AXL_FLASH_TYPE_MAX,
} axl_flash_type_t;

typedef enum axl_async_xfer_sts {
	AXL_ASYNC_XFER_DONE = 1,
	AXL_ASYNC_XFER_FAIL,
	AXL_ASYNC_XFER_TIMEOUT,
	AXL_ASYNC_XFER_PENDING,
} axl_async_xfer_sts_t;

typedef enum axl_kernel_wait_mode {
	AXL_KERNEL_WAIT_MSI,
	AXL_KERNEL_WAIT_POLL,
	AXL_KERNEL_WAIT_GET,
} axl_kernel_wait_mode_t;

typedef enum axl_transfer_direction {
	AXL_HOST_TO_DEV = 1,
	AXL_DEV_TO_HOST = 2,
} axl_transfer_direction_t;

typedef enum axl_hw_gen {
	AXL_HW_GEN_METIS = 0,
	AXL_HW_GEN_EUROPA = 1,
} axl_hw_gen_t;

typedef enum axl_device_property {
	AXL_PROPERTY_HW_GEN = 0,
	AXL_PROPERTY_AICORE_COUNT = 1,
	AXL_PROPERTY_PVE_CORE_COUNT = 2,
	AXL_PROPERTY_PES_GROUP = 3,
} axl_device_property_t;

typedef struct axl_device_properties {
	uint16_t hw_gen;
	uint16_t aicore_count;
	uint16_t pve_core_count;
	uint16_t pes_group;
} axl_device_properties_t;

typedef struct axl_dmabuf_desc {
	/* --- COMMON --- */
	axl_file_handle_t handle;
	axl_file_handle_t fhi;
	axl_file_handle_t fhi_ext;
	size_t size;

	/* --- SPECIALIZED --- */
#ifdef _WIN32 // Windows
	size_t offset;
	size_t fullsize;
	int is_imported;
	OVERLAPPED overlapped;
#else // Linux
	axl_file_handle_t fhe;
#endif
} axl_dmabuf_desc_t;

typedef struct axl_dev {
	axl_file_handle_t hdev;
	char *name;
	char *devname;
	void *base;
	void *dma;
	void *virt;
	size_t size;
	struct device_ctx ctx;
	struct axl_device_properties properties;
	int dma_ch;
	uint64_t elf_base;
	size_t elf_size;
	uint32_t elf_checksum;
	// Minimal jobmem cache for load optimization
	struct {
		struct axl_dmabuf_desc dmat;
		void *ptr;
		bool valid;
	} jobmem_cache;
} axl_dev_t;

typedef struct axl_dmabuf_xfer {
	uint64_t phy;
	size_t size;
	uint32_t offset;
	axl_file_handle_t handle;
	int flags;
	int channel;
} axl_dmabuf_xfer_t;

typedef struct axl_dma_xfer {
	uint64_t phy;
	uint64_t virt;
	size_t size;
	uint32_t offset;
	int flags;
} axl_dma_xfer_t;

typedef struct axl_dma_p2p_xfer {
	uint64_t axi;
	uint64_t p2pphy;
	size_t size;
	int channel;
	int flags;
} axl_dma_p2p_xfer_t;

typedef struct axl_dev_mem_window {
	uint64_t np_base;
	uint64_t np_size;
	uint64_t p_base;
	uint64_t p_size;
	uint64_t base_res[6];
	uint64_t size_res[6];
} axl_dev_mem_window_t;

typedef struct axl_sensor_data {
	int idx;
	char name[AXL_MAX_TEMP_SENSOR_LEN];
	float temp;
} axl_sensor_data_t;

typedef struct axl_dev_dma_channel_stats {
	int count;
	int num_xfer;
	int num_err;
	uint64_t bytes_xfer;
	int max_sgt;
	uint64_t max_duration_us;
	uint64_t duration_us;
	size_t size;
	uint32_t speed_mbps;
} axl_dev_dma_channel_stats_t;

typedef struct axl_dev_dma_stats {
	struct axl_dev_dma_channel_stats rd_channels[AXL_DMA_MAX_NR_CH];
	struct axl_dev_dma_channel_stats wr_channels[AXL_DMA_MAX_NR_CH];
} axl_dev_dma_stats_t;

#ifdef _WIN32
typedef LARGE_INTEGER axl_timestamp_t;
#else
typedef struct timespec axl_timestamp_t;
#endif

typedef struct axl_perf_timer {
	axl_timestamp_t start;
	axl_timestamp_t end;
} axl_perf_timer_t;

struct axl_poll_ctx;

// ============================================================
// APIs
// ============================================================

/* --- DEVICE --- */

// --- Device management

/// @brief Initialize an Axelera device by name.
/// @return Pointer to initialized device structure or NULL on failure.
struct axl_dev *axl_dev_init(const char *name);

/// @brief Deinitialize and free an Axelera device.
void axl_dev_deinit(struct axl_dev *info);

/// @brief Get device name by device number.
/// @return Device name string or NULL if not found.
char *axl_dev_get_device_name(int number);

/// @brief Get hardware generation string of the device.
/// @return Hardware generation string.
const char *axl_dev_get_hw_gen(struct axl_dev *axldev);

/// @brief Get hardware generation of Axelera PCI device by index (starts at 0)
/// @return Static generation string (no need to free).
const char *axl_dev_get_hw_gen_by_id(size_t index);

/// @brief Get device mode (QEMU, Silicon, or Unknown).
/// @return Device mode enumeration.
enum axl_device_mode axl_dev_get_device_mode(struct axl_dev *axldev);

/// @brief Get total number of available Axelera devices.
/// @return Number of devices.
int axl_dev_get_device_number(void);

/// @brief Enable runtime for the device.
/// @return 0 on success, negative on error.
int axl_dev_enable_runtime(struct axl_dev *axldev);

/// @brief Get flash information string of the device.
/// @return 0 on success, negative on error.
int axl_dev_get_flash_info(struct axl_dev *axldev, char *flash_info);

/// @brief Get secure boot status string of the device.
/// @return 0 on success, negative on error.
int axl_dev_get_secure_boot_status(struct axl_dev *axldev,
				   char *secure_boot_status);

/// @brief Print all available clock names from device.
/// @return 0 on success, negative on error.
int axl_dev_get_clock_names(struct axl_dev *axldev);

/// @brief Get frequency of specified clock.
/// @return Clock frequency or negative on error.
int axl_dev_get_clock_freq(struct axl_dev *axldev, const char *clock_name);

/// @brief Print information about all device clocks (name + freq).
/// @return 0 on success, negative on error.
int axl_dev_get_clock_info(struct axl_dev *axldev);

/// @brief Get all clock information (actual frequencies from hardware).
/// @return 0 on success, negative on error.
int axl_dev_get_clock_info_actual(struct axl_dev *axldev);

/// @brief Set device clock and frequency.
/// @return 0 on success, negative on error.
int axl_dev_set_clock(struct axl_dev *axldev, const char *clock_name,
		      const uint32_t clock_freq);

/// @brief Get current clock profile setting.
/// @return Clock profile enumeration.
enum axl_clock_profile axl_dev_get_clock_profile(struct axl_dev *axldev);

/// @brief Set device clock profile.
/// @return 0 on success, negative on error.
int axl_dev_set_clock_profile(struct axl_dev *axldev,
			      enum axl_clock_profile profile);

/// @brief Enable or disable device monitoring.
/// @return 0 on success, negative on error.
int axl_dev_enable_monitor(struct axl_dev *axldev, uint32_t enable);

/// @brief Set MVM utilization limit for specified core.
/// @return 0 on success, negative on error.
int axl_dev_set_mvm_utilization(struct axl_dev *axldev, int core_id,
				uint64_t limit);

/// @brief Get MVM utilization for specified core.
/// @return Utilization value or negative on error.
int axl_dev_get_mvm_utilization(struct axl_dev *axldev, int core_id);

/// @brief Set PVT warning temperature threshold.
/// @return 0 on success, negative on error.
int axl_dev_set_pvt_warning_threshold(struct axl_dev *axldev, int threshold);

/// @brief Get PVT warning temperature threshold.
/// @return Threshold value or negative on error.
int axl_dev_get_pvt_warning_threshold(struct axl_dev *axldev);

/// @brief Set software throttling parameters.
/// @return 0 on success, negative on error.
int axl_dev_set_sw_throttling(struct axl_dev *axldev, int temp_thresh,
			      uint32_t mvm_limit);

/// @brief Set software throttling hysteresis in degrees.
/// @return 0 on success, negative on error.
int axl_dev_set_sw_throttling_hysteresis(struct axl_dev *axldev,
					 int hysteresis);

/// @brief Get software throttling parameters.
/// @return 0 on success, negative on error.
int axl_dev_get_sw_throttling(struct axl_dev *axldev, int *temp_thresh,
			      int *hysteresis_degrees, uint32_t *mvm_limit);

/// @brief Set hardware throttling temperature threshold.
/// @return 0 on success, negative on error.
int axl_dev_set_hw_throttling(struct axl_dev *axldev, int temp_thresh);

/// @brief Set hardware throttling hysteresis in degrees.
/// @return 0 on success, negative on error.
int axl_dev_set_hw_throttling_hysteresis(struct axl_dev *axldev,
					 int hysteresis);

/// @brief Get hardware throttling parameters.
/// @return 0 on success, negative on error.
int axl_dev_get_hw_throttling(struct axl_dev *axldev, int *temp_thresh,
			      int *hysteresis_degrees);

/// @brief Set frequency downscaling temperature threshold and hysteresis.
/// @return 0 on success, negative on error.
int axl_dev_set_freq_downscaling(struct axl_dev *axldev, int temp_thresh,
				 int hysteresis);

/// @brief Get frequency downscaling parameters.
/// @return 0 on success, negative on error.
int axl_dev_get_freq_downscaling(struct axl_dev *axldev, int *temp_thresh,
				 int *hysteresis_degrees);

// --- Power Control Functions

/// @brief Get power control PID parameters.
/// @return 0 on success, negative on error.
int axl_dev_get_power_pid_params(struct axl_dev *axldev, float *kp, float *ki,
				 float *kd);

/// @brief Set power control PID parameters.
/// @return 0 on success, negative on error.
int axl_dev_set_power_pid_params(struct axl_dev *axldev, int kp, int ki,
				 int kd);

/// @brief Get power control filter parameters.
/// @return 0 on success, negative on error.
int axl_dev_get_power_filter_params(struct axl_dev *axldev,
				    float *integral_clamp, float *alpha);

/// @brief Set power control filter parameters.
/// @return 0 on success, negative on error.
int axl_dev_set_power_filter_params(struct axl_dev *axldev, int integral_clamp,
				    int alpha);

/// @brief Set power control alpha filter parameter.
/// @return 0 on success, negative on error.
int axl_dev_set_power_alpha_filter(struct axl_dev *axldev, int alpha);

/// @brief Start power control thread.
/// @return 0 on success, negative on error.
int axl_dev_power_control_start(struct axl_dev *axldev);

/// @brief Stop power control thread.
/// @return 0 on success, negative on error.
int axl_dev_power_control_stop(struct axl_dev *axldev);

/// @brief Reset power control loop.
/// @return 0 on success, negative on error.
int axl_dev_power_control_reset(struct axl_dev *axldev);

/// @brief Get power MVM utilization parameters.
int axl_dev_get_power_mvm_util_params(struct axl_dev *axldev, int *mvm_util_max,
				      int *mvm_util_min);

/// @brief Set power MVM utilization parameters.
/// @return 0 on success, negative on error.
int axl_dev_set_power_mvm_util_params(struct axl_dev *axldev, int mvm_util_max,
				      int mvm_util_min);

/// @brief Get power limit.
/// @return 0 on success, negative on error.
int axl_dev_get_power_limit(struct axl_dev *axldev, float *power_limit);

/// @brief Set power limit.
/// @return 0 on success, negative on error.
int axl_dev_set_power_limit(struct axl_dev *axldev, int power_limit);

/// @brief Get AIPU board type.
/// @return Board type enumeration.
enum axelera_board_type axl_dev_get_aipu_board_type(struct axl_dev *axldev);

/// @brief Get AIPU board revision number.
/// @return Board revision or negative on error.
int axl_dev_get_aipu_board_revision(struct axl_dev *axldev);

/// @brief Get AIPU board DDR information.
/// @return 0 on success, negative on error.
int axl_dev_get_aipu_board_ddr_info(struct axl_dev *axldev);

/// @brief Get AIPU board DDR size in bytes.
/// @return 0 on success, negative on error.
int axl_dev_get_aipu_board_ddr_size(struct axl_dev *axldev, uint64_t *ddr_size);

/// @brief Get board controller firmware version.
/// @return 0 on success, negative on error.
int axl_dev_get_board_ctrl_version(struct axl_dev *axldev, char *version);

/// @brief Get board controller board type string.
/// @return 0 on success, negative on error.
int axl_dev_get_board_ctrl_board_type(struct axl_dev *axldev, char *board_type);

/// @brief Get board controller board revision string.
/// @return 0 on success, negative on error.
int axl_dev_get_board_ctrl_board_revision(struct axl_dev *axldev,
					  char *board_revision);

/// @brief Get board controller board phase string.
/// @return 0 on success, negative on error.
int axl_dev_get_board_ctrl_board_phase(struct axl_dev *axldev,
				       char *board_phase);

/// @brief Get board controller cold boot status.
/// @return 0 on success, negative on error.
int axl_dev_get_board_ctrl_cold_boot(struct axl_dev *axldev,
				     uint32_t boot_mode);

/// @brief Get temperature from board controller sensor.
/// @return 0 on success, negative on error.
int axl_dev_get_board_ctrl_sensor_temp(struct axl_dev *axldev,
				       struct axl_sensor_data *sensor);

/// @brief Get DMA transfer statistics.
/// @return 0 on success, negative on error.
int axl_get_dma_stats(struct axl_dev *axldev, struct axl_dev_dma_stats *stats);

// --- Context management

/// @brief Allocate device context memory.
/// @return 0 on success, negative on error.
int axl_dev_alloc_ctx(struct axl_dev *axldev, unsigned long size);

/// @brief Free device context memory.
/// @return 0 on success, negative on error.
int axl_dev_free_ctx(struct axl_dev *axldev);

// --- Getters and Setters for device data (from axl_dev struct)

/// @brief Get driver name string.
/// @return Driver name string.
const char *axl_dev_get_drv_name(const struct axl_dev *axldev);

/// @brief Get device name string.
/// @return Device name string.
const char *axl_dev_get_devname(const struct axl_dev *axldev);

/// @brief Get device base address pointer.
/// @return Base address pointer.
void *axl_dev_get_base(struct axl_dev *axldev);

/// @brief Get memory map by index number.
/// @return Memory map pointer or NULL on error.
void *axl_dev_get_mem_map(struct axl_dev *axldev, int map_num);

/// @brief Get memory map index by name.
/// @return Map index or negative on error.
int axl_dev_get_map_index_by_name(struct axl_dev *axldev, const char *name);

/// @brief Get device virtualization structure.
/// @return Virtualization structure pointer.
const struct device_virtualization *axl_dev_get_virt(struct axl_dev *axldev);

/// @brief Get L2 cache base address.
/// @return L2 base address.
uint64_t axl_dev_get_l2_base(struct axl_dev *axldev);

/// @brief Get L2 cache size in bytes.
/// @return L2 size in bytes.
uint64_t axl_dev_get_l2_size(struct axl_dev *axldev);

/// @brief Get DDR memory base address.
/// @return DDR base address.
uint64_t axl_dev_get_ddr_base(struct axl_dev *axldev);

/// @brief Get DDR memory size in bytes.
/// @return DDR size in bytes.
uint64_t axl_dev_get_ddr_size(struct axl_dev *axldev);

/// @brief Get AI core identifier.
/// @return AI core ID value.
uint64_t axl_dev_get_aicore(struct axl_dev *axldev);

/// @brief Get MSI interrupt value.
/// @return MSI value.
uint64_t axl_dev_get_msi(struct axl_dev *axldev);

/// @brief Get device status value.
/// @return Status value.
uint64_t axl_dev_get_sts(struct axl_dev *axldev);

/// @brief Get device argument value.
/// @return Argument value.
uint64_t axl_dev_get_arg(struct axl_dev *axldev);

/// @brief Set L2 cache base address.
/// @return 0 on success, negative on error.
int axl_dev_set_l2_base(struct axl_dev *axldev, uint64_t base);

/// @brief Set L2 cache size in bytes.
/// @return 0 on success, negative on error.
int axl_dev_set_l2_size(struct axl_dev *axldev, uint64_t size);

/// @brief Set DDR memory base address.
/// @return 0 on success, negative on error.
int axl_dev_set_ddr_base(struct axl_dev *axldev, uint64_t base);

/// @brief Set DDR memory size in bytes.
/// @return 0 on success, negative on error.
int axl_dev_set_ddr_size(struct axl_dev *axldev, uint64_t size);

/// @brief Set AI core identifier.
/// @return 0 on success, negative on error.
int axl_dev_set_aicore(struct axl_dev *axldev, uint64_t aicore);

/// @brief Set MSI interrupt value.
/// @return 0 on success, negative on error.
int axl_dev_set_msi(struct axl_dev *axldev, uint64_t msi);

/// @brief Set device argument value.
/// @return 0 on success, negative on error.
int axl_dev_set_arg(struct axl_dev *axldev, uint64_t arg);

// --- Getters and Setters for device context (from mmapped device memory struct)

/// @brief Get kernel status from device context memory.
/// @return Status value.
uint64_t axl_dev_ctx_get_sts(struct axl_dev *axldev);

/// @brief Get job memory base address (physical) from device context.
/// @return Physical base address, or 0 if unavailable.
uint64_t axl_dev_ctx_get_jobmem_base(struct axl_dev *axldev);

/// @brief Get job memory size from device context.
/// @return Size in bytes, or 0 if unavailable.
uint64_t axl_dev_ctx_get_jobmem_size(struct axl_dev *axldev);

/// @brief Set L2 base address in device context.
/// @return 0 on success, negative on error.
int axl_dev_ctx_set_l2_base(struct axl_dev *axldev, uint64_t base);

/// @brief Set L2 size in device context.
/// @return 0 on success, negative on error.
int axl_dev_ctx_set_l2_size(struct axl_dev *axldev, uint64_t size);

/// @brief Set DDR base address in device context.
/// @return 0 on success, negative on error.
int axl_dev_ctx_set_ddr_base(struct axl_dev *axldev, uint64_t base);

/// @brief Set DDR size in device context.
/// @return 0 on success, negative on error.
int axl_dev_ctx_set_ddr_size(struct axl_dev *axldev, uint64_t size);

/// @brief Set ELF base address in device context.
/// @return 0 on success, negative on error.
int axl_dev_ctx_set_elf_base(struct axl_dev *axldev, uint64_t base);

/// @brief Set AI core in device context.
/// @return 0 on success, negative on error.
int axl_dev_ctx_set_aicore(struct axl_dev *axldev, uint64_t aicore);

/// @brief Set MSI in device context.
/// @return 0 on success, negative on error.
int axl_dev_ctx_set_msi(struct axl_dev *axldev, uint64_t msi);

/// @brief Set command in device context.
/// @return 0 on success, negative on error.
int axl_dev_ctx_set_cmd(struct axl_dev *axldev, uint64_t cmd);

/// @brief Set status in device context.
/// @return 0 on success, negative on error.
int axl_dev_ctx_set_sts(struct axl_dev *axldev, uint64_t sts);

/// @brief Set argument in device context.
/// @return 0 on success, negative on error.
int axl_dev_ctx_set_arg(struct axl_dev *axldev, uint64_t arg);

/// @brief Get AI core mask from device context.
/// @return 0 on success, negative on error.
int axl_dev_get_ctx_aicore_mask(struct axl_dev *axldev, uint64_t *aicore_mask);

// --- Driver info

/// @brief Get driver version string.
/// @return Driver version string.
char *axl_dev_get_driver_version(void);

/// @brief Check if kernel driver is loaded.
/// @return 1 if loaded, 0 if not loaded.
int axl_dev_check_driver_loaded(void);

// --- Firmware management

/// @brief Load firmware file to device.
/// @return 0 on success, negative on error.
int axl_dev_load_fw(struct axl_dev *axldev, const char *fw_name);

/// @brief Upload firmware to flash memory.
/// @return 0 on success, negative on error.
int axl_dev_flash_upload_fw(struct axl_dev *axldev, const char *fw_name,
			    enum axl_flash_type type);

/// @brief Activate firmware from flash.
/// @return 0 on success, negative on error.
int axl_dev_flash_activate(struct axl_dev *axldev, enum axl_flash_type type);

/// @brief Force firmware update from flash.
/// @return 0 on success, negative on error.
int axl_dev_flash_force_update(struct axl_dev *axldev,
			       enum axl_flash_type type);

/// @brief Get runtime firmware version string.
/// @return Firmware version string or NULL on error.
char *axl_dev_get_runtime_fw_version(struct axl_dev *axldev);

/// @brief Get flashed firmware version string.
/// @return 0 on success, negative on error.
int axl_dev_get_flashed_fw_version(struct axl_dev *axldev, char *version,
				   enum axl_flash_type type);

// --- MSI management

/// @brief Get MSI number for device name.
/// @return MSI number or negative on error.
int axl_dev_get_msi_number(const char *dname);

/// @brief Clean pending MSI interrupt.
/// @return 0 on success, negative on error.
int axl_dev_clean_msi(struct axl_dev *axldev, int msi, int timeout);

/// @brief Wait for MSI interrupt with timeout.
/// @return 0 on success, negative on error.
int axl_dev_wait_msi(struct axl_dev *axldev, int msi, int timeout);

/* --- KERNEL --- */

/// @brief Load kernel job to device memory.
/// @return 0 on success, negative on error.
int axl_dev_load_kernel_job(struct axl_dev *axdev_msi, const char *f_mem,
			    uint32_t f_size);

/// @brief Wait for kernel completion with specified mode.
/// @return 0 on success, negative on error.
int axl_dev_wait_kernel_mode(struct axl_dev *axldev, const int mode);

/// @brief Start kernel execution.
/// @return 0 on success, negative on error.
int axl_dev_start_kernel(struct axl_dev *axldev);

/// @brief Start kernel execution with argument.
/// @return 0 on success, negative on error.
int axl_dev_start_kernel_with_arg(struct axl_dev *axldev, uint64_t arg);

/// @brief Wait for kernel execution to complete.
/// @return 0 on success, negative on error.
int axl_dev_wait_kernel(struct axl_dev *axdev_msi);

/// @brief Get kernel execution status.
/// @return Kernel status value.
int axl_dev_get_kernel_sts(struct axl_dev *axldev);

/* --- DMA --- */

/// @brief Perform DMA transfer operation.
/// @return 0 on success, negative on error.
int axl_dev_dma_transfer(struct axl_dev *axldev,
			 const struct axl_dma_xfer *xfer);

/* --- DMABuf --- */

/// @brief Initialize DMA buffer descriptor.
/// @return 0 on success, negative on error.
int axl_dev_init_dmabuf(struct axl_dmabuf_desc *dmat);

/// @brief Import external DMA buffer by handle.
/// @return 0 on success, negative on error.
int axl_dev_import_dmabuf(struct axl_dmabuf_desc *dmat,
			  axl_file_handle_t handle, size_t size);

/// @brief Check if DMA buffer is open.
/// @return 1 if open, 0 if closed.
int axl_dev_is_dmabuf_open(const struct axl_dmabuf_desc *dmat);

/// @brief Check if DMA buffer is imported.
/// @return 1 if imported, 0 if not.
int axl_dev_is_dmabuf_imported(const struct axl_dmabuf_desc *dmat);

/// @brief Allocate new DMA buffer.
/// @return 0 on success, negative on error.
int axl_dev_alloc_dmabuf(size_t size, struct axl_dmabuf_desc *dmat);

/// @brief Free allocated DMA buffer.
/// @return 0 on success, negative on error.
int axl_dev_free_dmabuf(struct axl_dmabuf_desc *dmat);

/// @brief Synchronize DMA buffer for CPU or device access.
/// @return 0 on success, negative on error.
int axl_dev_sync_dmabuf(struct axl_dmabuf_desc *dmat, int start_stop);

/// @brief Get pollable file handle for DMA buffer.
/// @return File handle or AXL_INVALID_FILE_HANDLE on error.
axl_file_handle_t axl_dev_get_dmabuf_pollable_fh(struct axl_dmabuf_desc *dmat);

/// @brief Open DMA buffer file handle for device.
/// @return 0 on success, negative on error.
int axl_dev_open_dmabuf_fh(struct axl_dev *axldev,
			   struct axl_dmabuf_desc *dmat);

/// @brief Close DMA buffer file handle.
/// @return 0 on success, negative on error.
int axl_dev_close_dmabuf_fh(struct axl_dmabuf_desc *dmat);

/// @brief Perform DMA buffer transfer operation.
/// @return 0 on success, negative on error.
int axl_dev_dmabuf_transfer(struct axl_dmabuf_desc *dmat,
			    struct axl_dev *axldev,
			    const struct axl_dmabuf_xfer *xfer);

/// @brief Get asynchronous DMA buffer transfer status.
/// @return Transfer status enumeration.
int axl_dev_get_dmabuf_transfer_sts_async(struct axl_dmabuf_desc *dmat,
					  struct axl_dev *axldev,
					  const struct axl_dmabuf_xfer *xfer);

/// @brief Get synchronous DMA buffer transfer status.
/// @return Transfer status enumeration.
int axl_dev_get_dmabuf_transfer_sts_sync(struct axl_dmabuf_desc *dmat,
					 struct axl_dev *axldev,
					 const struct axl_dmabuf_xfer *xfer);

/// @brief Memory map DMA buffer to user space.
/// @return Mapped memory pointer or MAP_FAILED on error.
void *axl_dev_mmap(struct axl_dmabuf_desc *dmat);

/// @brief Unmap previously mapped memory region.
void axl_dev_unmap(void *p, size_t size);

/// @brief Open MSI interrupt file handle.
/// @return File handle or AXL_INVALID_FILE_HANDLE on error.
axl_file_handle_t axl_dev_open_msi_file_handle(struct axl_dev *axldev, int msi);

/// @brief Close MSI interrupt file handle.
/// @return 0 on success, negative on error.
int axl_dev_close_msi_file_handle(struct axl_dev *axldev, axl_file_handle_t fh,
				  int msi);

/// @brief Open device file handle.
/// @return File handle or AXL_INVALID_FILE_HANDLE on error.
axl_file_handle_t axl_dev_open_file_handle(struct axl_dev *axldev);

/// @brief Close device file handle.
/// @return 0 on success, negative on error.
int axl_dev_close_file_handle(axl_file_handle_t fh);

/// @brief Load kernel context to DMA buffer.
/// @return 0 on success, negative on error.
int axl_dev_dmabuf_load_kernel_ctx(struct axl_dev *axldev, uint64_t offset,
				   const char *f_mem, uint32_t f_size);

/// @brief Load kernel context to DDR via DMA buffer.
/// @return 0 on success, negative on error.
int axl_dev_dmabuf_load_kernel_ctx_ddr(struct axl_dev *axldev, uint64_t offset,
				       const char *f_mem, uint32_t f_size);

/* --- SYSMSG */
/// @brief Send command message to device.
int axl_dev_msg(struct axl_dev *axldev, struct cmd *cmd);

/* --- POLL --- */

/// @brief Create new poll context for event monitoring.
/// @return Poll context pointer or NULL on error.
struct axl_poll_ctx *axl_dev_poll_ctx_create(void);

/// @brief Destroy poll context and free resources.
void axl_dev_poll_ctx_destroy(struct axl_poll_ctx *ctx);

/// @brief Add file handle to poll context.
/// @return 0 on success, negative on error.
int axl_dev_poll_ctx_add(struct axl_poll_ctx *ctx, axl_file_handle_t handle);

/// @brief Remove file handle from poll context.
/// @return 0 on success, negative on error.
int axl_dev_poll_ctx_remove(struct axl_poll_ctx *ctx, axl_file_handle_t handle);

/// @brief Wait for events on poll context with timeout.
/// @return Number of events or negative on error.
int axl_dev_poll_ctx_wait(struct axl_poll_ctx *ctx, axl_file_handle_t *events,
			  size_t events_size, int timeout);

/* --- PEER-TO-PEER --- */
/// @brief Perform peer-to-peer DMA transfer operation.
/// @return 0 on success, negative on error.
int axl_dev_dma_transfer_p2p(struct axl_dev *axldev,
			     const struct axl_dma_p2p_xfer *xfer);

/// @brief Get peer-to-peer memory windows.
/// @return 0 on success, negative on error.
int axl_dev_p2p_get_mem_windows(struct axl_dev *axldev,
				const struct axl_dev_mem_window *mem_windows);

/// @brief Configure outbound peer-to-peer memory window.
/// @return 0 on success, negative on error.
int axl_dev_p2p_config_outbound(struct axl_dev *axldev, int id, uint32_t bof,
				uint64_t tgt, uint32_t size);

/* --- UTILITIES --- */

/// @brief Read 32-bit value from memory address.
/// @return 0 on success, negative on error.
int axl_read32(const void *addr, unsigned long offset, uint32_t *val);

/// @brief Write 32-bit value to memory address.
/// @return 0 on success, negative on error.
int axl_write32(void *addr, unsigned long offset, uint32_t val);

/// @brief Read 64-bit value from memory address.
/// @return 0 on success, negative on error.
int axl_read64(const void *addr, unsigned long offset, uint64_t *val);

/// @brief Write 64-bit value to memory address.
/// @return 0 on success, negative on error.
int axl_write64(void *addr, unsigned long offset, uint64_t val);

/// @brief Get current high-resolution timestamp.
void axl_get_timestamp(axl_timestamp_t *ts);

/// @brief Calculate elapsed time between timestamps in nanoseconds.
/// @return Elapsed time in nanoseconds.
uint64_t axl_get_elapsed_nsec(const axl_timestamp_t *start,
			      const axl_timestamp_t *end);

/// @brief Calculate elapsed time between timestamps in milliseconds.
/// @return Elapsed time in milliseconds.
uint64_t axl_get_elapsed_msec(const axl_timestamp_t *start,
			      const axl_timestamp_t *end);

/// @brief Set environment variable.
void axl_setenv(const char *name, const char *value);

/// @brief Unset environment variable.
void axl_unsetenv(const char *name);

/// @brief Check file access permissions.
/// @return 0 if accessible, negative on error.
int axl_access(const char *path, int mode);

/// @brief Get system memory page size.
/// @return Page size in bytes.
size_t axl_getpagesize(void);

/// @brief Check if firmware version is compatible with device.
/// @return true if compatible, false otherwise.
/// @note This variant ignores -stage0 suffix in version comparison.
bool is_fw_version_compatible(struct axl_dev *axldev);

/// @brief  Return the required firmware version
/// @return string representing expected firmware version, user free's it after use
char *get_required_firmware_version();

/// @brief Get datastream area from sysctl.
/// @return Pointer to datastream area.
void *sysctl_get_datastream_area(struct device_sys_ctl *dsctl);

/// @brief Get board information area from sysctl.
/// @return Pointer to board info area.
void *sysctl_get_boardinfo_area(struct device_sys_ctl *dsctl);

/// @brief Get context area from sysctl.
/// @return Pointer to context area.
void *sysctl_get_ctx_area(struct device_sys_ctl *dsctl);

/// @brief Get AXE message area from sysctl.
/// @return Pointer to AXE message area.
const struct device_axemsg *
sysctl_get_axemsg_area(const struct device_sys_ctl *sysctl);

/// @brief Get virtualization area from sysctl.
/// @return Pointer to virtualization area.
void *sysctl_get_virtualization_area(struct device_sys_ctl *dsctl);

/// @brief Get firmware load address from sysctl.
/// @param axldev device handle
/// @return Firmware load address.
uint32_t sysctl_get_fw_load_addr(struct axl_dev *axldev);

/// @brief Get firmware load offset from sysctl.
/// @param axldev device handle
/// @return Firmware load offset.
uint32_t sysctl_get_fw_load_offset(struct axl_dev *axldev);

/// @brief Get the physical base address of the host-device interface memory.
/// @param axldev device handle
/// @return Physical base address of the host-device interface memory or 0 on failure.
uint64_t sysctl_get_hdif_phys_base(struct axl_dev *axldev);

/// @brief Get the host-device interface size.
/// @return HDIF size in bytes.
uint64_t sysctl_get_hdif_size(struct axl_dev *axldev);

/// @brief Convert device pointer to host virtual address.
/// @return Host memory pointer.
void *device_to_host_ptr(void *dev_ptr, void *mmapped_base_ptr,
			 uint16_t memory_type);

#ifdef __cplusplus
} // extern "C"
#endif

#endif /* __LIBAXLDEV_H__ */
