// Copyright (c) 2024 Axelera AI. All rights reserved.
#ifndef __SYSCTL_MEM_H__
#define __SYSCTL_MEM_H__

#include <stdint.h>

#define SYSCTL_RESERVED	      (1024 * 1024)
#define RUN_MEGAKERNEL_OFFSET SYSCTL_RESERVED

#define MAX_MSG		256
#define MAX_MEMORY_AREA 2
#define NUM_CONTEXTS	4 // Number of execution contexts

#define TRACING_BUFFER_SIZE (32 * 1024)
#define LOG_BUFFER_SIZE	    (8 * 1024)
#define AXE_MSG_BUFFER_SIZE (128 * 1024)
#define DMA_SG_DESC_SIZE    (128 * 1024)

/*
 * sysctl substructures magic numbers
 * WARNING: not supposed to be changed - used for sanity check
 */
#define SYSCTL_DATASTREAM_AREA_MAGIC	 (0xF0F0)
#define SYSCTL_BOARDINFO_AREA_MAGIC	 (0xA5A5)
#define SYSCTL_AXE_MSG_AREA_MAGIC	 (0xC3C3)
#define SYSCTL_CTX_AREA_MAGIC		 (0x5A5A)
#define SYSCTL_VIRTUALIZATION_AREA_MAGIC (0xB8B8)
#define SYSCTL_HOST_DRV_AREA_MAGIC	 (0xBAC1)
#define SYSCTL_DMA_SG_DESC_AREA_MAGIC	 (0xD4D4)

/* ------------------ [HOST] ------------------ */
/* Versioning system for the shared memory area
 * (MS 8bit for major, LS 8bit for minor)
 *
 * Note:
 * bump the major version when there is a breaking change in the respective area
 * bump the minor version when there is a non-breaking change in the respective area
 */
#define VERSION(major, minor)  ((((major)&0xFF) << 8) | ((minor)&0xFF))
#define VERSION_MAJOR(version) (((version) >> 8) & 0xFF)
#define VERSION_MINOR(version) ((version)&0xFF)

#define SYSCTL_SHARED_MEM_MASTER_VERSION   VERSION(0, 2)
#define SYSCTL_DATASTREAM_AREA_VERSION	   VERSION(1, 0)
#define SYSCTL_BOARDINFO_AREA_VERSION	   VERSION(0, 2)
#define SYSCTL_AXE_MSG_AREA_VERSION	   VERSION(0, 1)
#define SYSCTL_CTX_AREA_VERSION		   VERSION(0, 1)
#define SYSCTL_VIRTUALIZATION_AREA_VERSION VERSION(0, 1)
#define SYSCTL_HOST_DRV_AREA_VERSION	   VERSION(0, 1)
#define SYSCTL_DMA_SG_DESC_AREA_VERSION	   VERSION(0, 1)
/* -------------------------------------------- */

enum {
	CTX_OP_START = 0xaa,
	CTX_OP_RUN = 0xbb,
};

#include "device_commands.h"

enum axelera_board_type {
	/* From device.zephyr/include/zephyr/arch/riscv/riscv-privilege/axelera/triton/boards.h */
	BOARD_MATTERHORN, // Metis Omega 1-chip PCIe board (https://github.com/axelera-ai/device.zephyr/blob/axelera/main/boards/axelera/matterhorn/doc/index.rst)
	BOARD_ORTLES, // Metis Omega M.2 board (https://github.com/axelera-ai/device.zephyr/blob/axelera/main/boards/axelera/ortles/doc/index.rst)
	BOARD_DEVBOARD, // Metis Omega Devboard (https://github.com/axelera-ai/device.zephyr/blob/axelera/main/boards/axelera/devboard/doc/index.rst)
	BOARD_ANTELAO, // Metis Omega AI SBC (https://github.com/axelera-ai/device.zephyr/blob/axelera/main/boards/axelera/antelao/doc/index.rst)
	BOARD_SCILIAR, // Metis Omega Arduino Portenta X8 carrier board (https://github.com/axelera-ai/device.zephyr/blob/axelera/main/boards/axelera/sciliar/doc/index.rst)
	BOARD_MONVISO, // Metis Omega 4-chip PCIe board
	BOARD_ORTLES_REV2, // Metis Omega M.2 Rev2 board
	BOARD_MATTERHORN_REV2, // Metis Omega 1-chip PCIe Rev2 board
	BOARD_MAX,
};

/* Memory types are kept generic as they could represent different things
 * on different devices */
enum {
	MEMORY_AREA_0 = 0,
	MEMORY_AREA_1 = 1,
};

typedef struct buffer_reference {
	uint64_t addr;
	uint64_t size;
} buffer_reference_t;

typedef struct ring_buffer_ctrl {
	/* From ring_buffer_mem.h (device.firmware) */
	/* Note: Be very careful when changing the data structure layout here, as read_pos and
	* write_pos must reside in separate cache lines to be able to manage coherence in software
	* if the data cache is enabled. */
	volatile uint32_t read_pos;
	uint32_t capacity;
	volatile uint32_t write_pos;
	union {
		struct {
			uint32_t msi : 10;
			uint32_t reserved : 21;
			uint32_t enabled : 1;
		};
		uint32_t reg;
	};
} ring_buffer_ctrl_t;

/* NOTE
 * The following struct is temporarily kept for backward compatibility
 * with older firmware versions which don't use the newer device_ctx_t
 * struct.
 */
typedef struct ctx {
	uint32_t l2_base; /* DEPRECATED */ // L2 context base address
	uint32_t l2_size; /* DEPRECATED */ // L2 context size
	uint32_t aicore; /* DEPRECATED */ // aicores bitmask allocate to context
	uint32_t dma; /* DEPRECATED */ // dma RD/WR channels allocate to context
	uint32_t msi; /* DEPRECATED */ // msi notify allocate to context
	uint32_t cmd; /* DEPRECATED */ // context command operation
	uint32_t sts; /* DEPRECATED */ // context return operation state
	uint32_t arg; /* DEPRECATED */ // context command argument
	uint32_t ddr_base; /* DEPRECATED */ // DDR context base address
	uint32_t ddr_size; /* DEPRECATED */ // DDR context size
	uint32_t elf_base; /* DEPRECATED */ // elf base address
} ctx_t;

typedef struct cmd {
	uint32_t opcode;
	uint32_t size;
	char msg[MAX_MSG];
} cmd_t;

typedef struct version {
	uint8_t major;
	uint8_t minor;
} version_t;

typedef struct memory_reference {
	uint16_t magic; // magic number for sanity check
	struct version version; // version of the area
	uint32_t size; // size of the area
	uint64_t offset; // offset of the area (w.r.t. BAR)
	uint16_t memory_area; // memory where the area is located
	uint16_t reserved[3];
} memory_reference_t;

// Datastream enums and structures
typedef enum {
	STREAM_TYPE_TEXT = 0,
	STREAM_TYPE_BINARY = 1,
} stream_type_t;

typedef enum {
	STREAM_SOURCE_CTRL_CORE_LOG = 0,
	STREAM_SOURCE_CTRL_CORE_TRACE = 1,
	STREAM_SOURCE_AICORE0_LOG = 5,
	STREAM_SOURCE_AICORE0_TRACE = 6,
	STREAM_SOURCE_AICORE1_LOG = 7,
	STREAM_SOURCE_AICORE1_TRACE = 8,
	STREAM_SOURCE_AICORE2_LOG = 9,
	STREAM_SOURCE_AICORE2_TRACE = 10,
	STREAM_SOURCE_AICORE3_LOG = 11,
	STREAM_SOURCE_AICORE3_TRACE = 12,
	STREAM_SOURCE_AICORE4_LOG = 13,
	STREAM_SOURCE_AICORE4_TRACE = 14,
	STREAM_SOURCE_AICORE5_LOG = 15,
	STREAM_SOURCE_AICORE5_TRACE = 16,
	STREAM_SOURCE_AICORE6_LOG = 17,
	STREAM_SOURCE_AICORE6_TRACE = 18,
	STREAM_SOURCE_AICORE7_LOG = 19,
	STREAM_SOURCE_AICORE7_TRACE = 20,
	STREAM_SOURCE_PVE_CORE0_LOG = 51,
	STREAM_SOURCE_PVE_CORE0_TRACE = 52,
	STREAM_SOURCE_PVE_CORE1_LOG = 53,
	STREAM_SOURCE_PVE_CORE1_TRACE = 54,
	STREAM_SOURCE_PVE_CORE2_LOG = 55,
	STREAM_SOURCE_PVE_CORE2_TRACE = 56,
	STREAM_SOURCE_PVE_CORE3_LOG = 57,
	STREAM_SOURCE_PVE_CORE3_TRACE = 58,
	STREAM_SOURCE_PVE_CORE4_LOG = 59,
	STREAM_SOURCE_PVE_CORE4_TRACE = 60,
	STREAM_SOURCE_PVE_CORE5_LOG = 61,
	STREAM_SOURCE_PVE_CORE5_TRACE = 62,
	STREAM_SOURCE_PVE_CORE6_LOG = 63,
	STREAM_SOURCE_PVE_CORE6_TRACE = 64,
	STREAM_SOURCE_PVE_CORE7_LOG = 65,
	STREAM_SOURCE_PVE_CORE7_TRACE = 66,
	STREAM_SOURCE_PVE_CORE8_LOG = 67,
	STREAM_SOURCE_PVE_CORE8_TRACE = 68,
	STREAM_SOURCE_PVE_CORE9_LOG = 69,
	STREAM_SOURCE_PVE_CORE9_TRACE = 70,
	STREAM_SOURCE_PVE_CORE10_LOG = 71,
	STREAM_SOURCE_PVE_CORE10_TRACE = 72,
	STREAM_SOURCE_PVE_CORE11_LOG = 73,
	STREAM_SOURCE_PVE_CORE11_TRACE = 74,
	STREAM_SOURCE_PVE_CORE12_LOG = 75,
	STREAM_SOURCE_PVE_CORE12_TRACE = 76,
	STREAM_SOURCE_PVE_CORE13_LOG = 77,
	STREAM_SOURCE_PVE_CORE13_TRACE = 78,
	STREAM_SOURCE_PVE_CORE14_LOG = 79,
	STREAM_SOURCE_PVE_CORE14_TRACE = 80,
	STREAM_SOURCE_PVE_CORE15_LOG = 81,
	STREAM_SOURCE_PVE_CORE15_TRACE = 82,
	// The following entries are fixed by design - do not change
	STREAM_SOURCE_RESERVED = 255,
	STREAM_SOURCE_MAX = 256,
} stream_source_t;

// Helper macros to compute stream source from core ID and type
#define NUM_STREAMS_PER_CORE 2
#define STREAM_SOURCE_AICORE(id, type)                    \
	((stream_source_t)(STREAM_SOURCE_AICORE0_##type + \
			   ((id)*NUM_STREAMS_PER_CORE)))
#define STREAM_SOURCE_PVE_CORE(id, type)                    \
	((stream_source_t)(STREAM_SOURCE_PVE_CORE0_##type + \
			   ((id)*NUM_STREAMS_PER_CORE)))

#define DATA_STREAM_NOT_SUPPORTED ((uint8_t)(STREAM_SOURCE_RESERVED))

#define DATA_STREAM_NAME_MAX_LEN 32

typedef struct {
	stream_type_t type;
	ring_buffer_ctrl_t ctrl;
	buffer_reference_t buf_ref;
	uint32_t cfg_opcode;
	int8_t cfg_core_id;
	char name[DATA_STREAM_NAME_MAX_LEN];
} data_stream_t;

typedef struct device_datastream {
	uint32_t num_streams;
	uint8_t source_to_index[STREAM_SOURCE_MAX];
	data_stream_t stream[];
} device_datastream_t;

typedef struct device_boardinfo {
	uint8_t clock_profile;
	uint8_t board_type;
	uint8_t board_revision;
	uint8_t __pad[5];
	uint64_t ddr_size;
} device_boardinfo_t;

typedef struct device_axemsg {
	/* --- Device --- */
	struct buffer_reference device_buf_ref;
	uint64_t device_msg_size;
	uint32_t device_msg_crc32;
	uint32_t __pad0;
	/* --- Host --- */
	struct buffer_reference host_buf_ref;
	uint64_t host_msg_size;
	uint32_t host_msg_crc32;
	uint32_t __pad1;
} device_axemsg_t;

typedef struct device_ctx {
	/* --- Context Resources --- */
	uint64_t aicore; // bitmask of aicores allocate to context
	uint64_t l2_base; // L2 context base address
	uint64_t l2_size; // L2 context size
	uint64_t ddr_base; // DDR context base address
	uint64_t ddr_size; // DDR context size
	uint64_t msi; // msi notify allocate to context
	/* --- Kernel Offload Resources --- */
	uint64_t cmd; // context command operation
	uint64_t sts; // context return operation state
	uint64_t arg; // context command argument
	uint64_t elf_base; // elf base address
	uint64_t jobmem_base; // job memory base address (physical)
	uint64_t jobmem_size; // job memory size
} device_ctx_t;

typedef struct device_virtualization {
	uint64_t l2_base_virt;
	uint64_t l2_base_phys;
	uint64_t l2_size;
	uint64_t ddr_base_virt;
	uint64_t ddr0_base_phys;
	uint64_t ddr0_size;
	uint64_t ddr1_base_phys;
	uint64_t ddr1_size;
} device_virtualization_t;

typedef struct device_host_drv {
	uint32_t ctrl;
	uint32_t base;
	uint64_t target;
	uint32_t size;
} device_host_drv_t;

#define MAX_VIRT_MSI	     (1024)
#define HDRV_CTRL_ENABLE     (1)
#define HDRV_CTRL_CONFIGURED (1 << 1)
#define VMSI_IRQ_EN_BIT	     (0)
#define VMSI_IRQ_EN	     (1 << VMSI_IRQ_EN_BIT)

typedef struct device_virt_msi {
	volatile uint32_t msi[MAX_VIRT_MSI];
} device_virt_msi_t;

typedef struct device_dma_sg_desc {
	buffer_reference_t dma_sg_desc_buf_ref;
} device_dma_sg_desc_t;

typedef struct device_sys_ctl {
	/* -------- Static Runtime Area (1KB) --------- */
	uint8_t __pad0[176]; // 0x00
	struct cmd cmd; // 0xb0
	uint8_t __pad1[72];
	struct version master_version; // 0x200
	uint8_t __pad2[6];
	uint64_t memory_map[MAX_MEMORY_AREA]; // memory types to device phys. addr.
	uint8_t __pad3[32];
	uint64_t fw_load_addr;
	struct memory_reference datastream_mem_ref;
	struct memory_reference boardinfo_mem_ref;
	struct memory_reference axemsg_mem_ref;
	struct memory_reference ctx_mem_ref;
	struct memory_reference virt_mem_ref;
	struct memory_reference hdrv_mem_ref;
	struct memory_reference dmasgdesc_mem_ref;
	uint8_t __pad4[280];
	/* ---- Static MCUBoot Reserved Area (1KB) ---- */
	uint8_t mcuboot_shared[1024]; // 0x400
} device_sys_ctl_t;

struct axl_cmd_outb_cfg {
	uint32_t id;
	uint32_t base;
	uint64_t target;
	uint32_t size;
};

struct axl_cmd_dma_xfer {
	uint64_t dev;
	uint64_t pcie;
	uint32_t size;
	uint16_t dir; // 0: AXI->PCIE, 1: PCIE->AXI
	uint16_t channel;
};

#endif
