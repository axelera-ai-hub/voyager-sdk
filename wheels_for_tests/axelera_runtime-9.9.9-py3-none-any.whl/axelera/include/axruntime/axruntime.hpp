// experimental C++ wrapper, should probably go a bit deeper on this, provide
// namespaced versions of the C functions which take the object or ptr<>.
#pragma once
#include "axruntime/axruntime.h"

namespace axr {

template <typename T>
axrObject *to_object(T *obj) {
  static_assert(std::is_same<T, axrObject>::value ||
                    std::is_same<T, axrModel>::value ||
                    std::is_same<T, axrModelInstance>::value ||
                    std::is_same<T, axrObject>::value ||
                    std::is_same<T, axrConnection>::value ||
                    std::is_same<T, axrProperties>::value ||
                    std::is_same<T, axrContext>::value,
                "T must be a subclass of axrObject");
  return reinterpret_cast<axrObject *>(obj);
}
struct object_deleter {
  template <typename T>
  void operator()(T *ptr) const {
    ::axr_destroy(to_object(ptr));
  }
};

template <typename T>
using ptr = std::unique_ptr<T, object_deleter>;

// helper function to create a ptr<>
template <typename T>
ptr<T> to_ptr(T *p) {
  return ptr<T>(p);
}

}  // namespace axr
