// Copyright Axelera AI, 2024
#pragma once
#ifdef __cplusplus
#include <memory>
extern "C" {
#endif

#include <stdbool.h>
#include <stddef.h>
#ifdef _WIN32
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#endif

#ifndef AXR_EXPORT
  #if defined _WIN32 || defined __CYGWIN__
    #ifdef BUILDING_DLL
      #ifdef __GNUC__
        #define AXR_EXPORT __attribute__((dllexport))
      #else
        #define AXR_EXPORT __declspec(dllexport)
      #endif
    #else
      #ifdef __GNUC__
        #define AXR_EXPORT __attribute__((dllimport))
      #else
        #define AXR_EXPORT __declspec(dllimport)
      #endif
    #endif
  #else
    #define AXR_EXPORT __attribute__((visibility ("default")))
  #endif
#endif

/// @brief The static version of the API, this can be used by the client to
/// compare with the runtime version loaded and determine if the version is
/// acceptable.
/// @details The version is a 32 bit integer with the major version in the upper
/// 16 bits and the minor version in the lower 16 bits.
/// @example
/// if (axr_api_version() != AXR_API_VERSION) {
///   fprintf(stderr, "API version mismatch\n");
///   return 1;
/// }
/// @note The major version is incremented when there are breaking changes to
/// the API and the minor version is incremented when there are non-breaking
/// changes.
/// For example new functions will only result in a minor version change.
/// But a change to an enum or a change to the signature of a function will
/// result in a major version change.  Major changes will certainly require a
/// re-compilation and may require changes to the client code.
#define AXR_API_VERSION_MAJOR 0x0003u
#define AXR_API_VERSION_MINOR 0x0001u
#define AXR_API_VERSION ((AXR_API_VERSION_MAJOR << 16) | AXR_API_VERSION_MINOR)

/// @brief Get the version of the API.
/// @return the version of the API
/// This allows a client to check the version of the API at runtime to ensure
/// compatibility.
/// Minor version changes may include additions to the API, while major version
/// changes may include breaking changes.
AXR_EXPORT unsigned int axr_api_version(void);

/// @brief A file handle type that is platform-specific for containing a dma buf.
#ifdef _WIN32
  typedef HANDLE axr_file_handle_t;
#else
  typedef int axr_file_handle_t;
#endif


/// @brief An input or output argument to a model
/// @details The data field is a pointer to the data, which can be in host
/// memory or alternatively it can be a reference to a dmabuf file descriptor
/// and offset within it.
/// Note: only fd or ptr can be valid (nullptr for ptr, 0 or -1 for fd)
/// Note: at present offset is not supported, it must be zero.
/// size is optional. If 0 it will be ignored, if given it will be checked
/// against the expected tensor size.
typedef struct axrArgument {
  void *ptr;
  axr_file_handle_t fd;
  size_t offset;
  size_t size;
} axrArgument;

enum axrResult {
  AXR_SUCCESS,
  AXR_ERROR_RUNTIME_ERROR,
  AXR_ERROR_VALUE_ERROR,
  AXR_ERROR_INVALID_ARGUMENT,
  AXR_ERROR_CONNECTION_ERROR,
  AXR_ERROR_DEVICE_IN_USE,
  AXR_ERROR_INCOMPATIBLE_DEVICE,
  AXR_ERROR_INVALID_CONFIGURATION,
  AXR_ERROR_NOT_IMPLEMENTED,
  AXR_ERROR_INTERNAL_ERROR,
  AXR_ERROR_PENDING_ERROR,
  AXR_ERROR_UNKNOWN_ERROR,
};

enum axrLogLevel {
  AXR_LOG_TRACE,
  AXR_LOG_LOG,
  AXR_LOG_DEBUG,
  AXR_LOG_INFO,
  AXR_LOG_FIXME,
  AXR_LOG_WARNING,
  AXR_LOG_ERROR,
};

#define AXR_MAX_TENSOR_DIMS 8
enum AXR_TENSOR_DATA_TYPE {
  AXR_UNSIGNED = 0,
  AXR_SIGNED = 1,
  AXR_FLOAT = 2,
};

/// @brief Structure used to describe the input and output tensors of a model.
/// @details This structure is used to describe the input and output tensors of
/// a model.
///
/// This is used to indicate the shape. format, padding and quantization
/// information.
///
/// See the python documentation for axelera.runtime.TensorInfo for example
/// numpy code to use the quantisation and padding information.
///
typedef struct axrTensorInfo {
  /// @brief The dimensions of the tensor, dims[0:ndims] can be considered the
  /// shape
  size_t dims[AXR_MAX_TENSOR_DIMS];

  /// @brief The number of dimensions in the tensor
  size_t ndims;

  /// @brief The number of bits per element
  size_t bits;

  /// @brief The format of the tensor, one of AXR_TENSOR_DATA_TYPE
  size_t type;

  /// @brief The name of the tensor referenced in the model
  char name[256];

  /// @brief Amount of padding on the tensor.
  /// As list of [(start0, end0), (start1, end1), ...  (see numpy.pad)
  /// For example for NHWC this is
  /// (Nbefore, Nafter), (Hbefore, Hafter), (Wbefore, Wafter), (Cbefore, Cafter)
  /// = padding[:ndims* 2]
  size_t padding[AXR_MAX_TENSOR_DIMS][2];

  /// @brief scale for quantization/dequantization
  double scale;

  /// @brief zero-point for quantization/dequantization
  int zero_point;
} axrTensorInfo;

/// @brief Get the size of a tensor in bytes
AXR_EXPORT size_t axr_tensor_size(const axrTensorInfo *info);

enum axrBoardType {
  AXR_BOARD_METIS_ALPHA_PCIE,
  AXR_BOARD_METIS_ALPHA_M2,
  AXR_BOARD_METIS_OMEGA_PCIE,
  AXR_BOARD_METIS_OMEGA_M2,
  AXR_BOARD_METIS_OMEGA_DEVBOARD,
  AXR_BOARD_METIS_OMEGA_SBC,
  AXR_BOARD_METIS_MAX = 6,
};

// @brief axrBoardType enum to a string.
// The string is statically allocated and should not be freed.
// Never returns NULL.
AXR_EXPORT const char *axr_board_type_string(axrBoardType result);

typedef struct axrDeviceInfo {
  /// @brief The name of the device, for example "metis-0:3:0"
  char name[256];
  /// @brief The number of subdevices on the device, for metis this is 4
  size_t subdevice_count;
  /// @brief The maximum memory available on the device
  /// @note in the current implementation this field is not populated and will
  /// always be 0.
  size_t max_memory;
  /// @brief The number of subdevices in use
  /// @note in the current implementation this field is not populated and will
  /// always be 0.
  int in_use;
  /// @brief The username and process id of the user(s) using the device, comma
  /// separated
  /// @note in the current implementation this field is not populated and will
  /// always be empty.
  char in_use_by[256];
  /// @brief The board type of the device
  axrBoardType board_type;
  /// @brief The firmware version of the device, for example
  /// v1.1.0-rc5-2-g1234567
  char firmware_version[256];
  /// @brief The board revision of the device
  int board_revision;
  /// @brief The version of the firmware stored in flash memory of the device.
  char flashed_firmware_version[256];
  /// @brief The board controller firmware version on the device.
  char board_controller_firmware_version[256];
  /// @brief The board controller board type.
  char board_controller_board_type[256];
} axrDeviceInfo;

typedef struct axrObject axrObject;
typedef struct axrModel axrModel;
typedef struct axrConnection axrConnection;
typedef struct axrContext axrContext;
typedef struct axrModelInstance axrModelInstance;
typedef struct axrProperties axrProperties;

/// @brief This macro can be used to cast any object to the base object type
/// axrObject
#ifdef __cplusplus
#define AXR_OBJECT(obj) axr::to_object(obj)
#else
#define AXR_OBJECT(obj) ((axrObject *)obj)
#endif

/// --------------------------------------------------------------
/// Object
/// --------------------------------------------------------------

/// @brief Destroy any non-value object created by the library
/// @param obj the object to destroy
/// @details This function is only required to be called on the context object,
/// all other objects will be destroyed when the context is destroyed.
/// However other objects can be destroyed sooner if necessary. For example to
/// load a different model onto the target you should first destory the model
/// instance.
AXR_EXPORT void axr_destroy(const axrObject *obj);

/// @brief convert axrResult enum to a string.
/// The string is statically allocated and should not be freed.
/// Never returns NULL.
AXR_EXPORT const char *axr_error_string(axrResult result);
/// @brief get the last error that occurred on the context.
AXR_EXPORT axrResult axr_last_error(const axrObject *c);
/// @brief get the last error string that occurred on the context.
/// The string is valid until the next call to an axr function in this thread.
AXR_EXPORT const char *axr_last_error_string(const axrObject *c);

/// @brief Get the context that owns the object
/// @param obj the object
/// @return the context that owns the object, or null if the object is null
AXR_EXPORT axrContext *axr_get_context(axrObject *obj);

/// --------------------------------------------------------------
/// Context
/// @brief The context object is the root object for the library.
/// --------------------------------------------------------------

/// @brief Create a new context
/// @return a valid context (never NULL)
/// @details The context is used to create all other objects and it owns all the
/// objects created from it, as well as providing access to some global services
/// like errors and logging.
AXR_EXPORT axrContext *axr_create_context(void);

typedef void (*axr_logger_fn)(void *arg, axrLogLevel level, const char *msg);

/// brief Set a logger and the logging level for the context
/// @param context - the context
/// @param logger - a function that will be called with log messages
/// @param level - the minimum level of log message to forward to the logger
/// @param arg - an argument that will be passed to the logger function
AXR_EXPORT void axr_set_logger(axrContext *context, axrLogLevel level,
                               axr_logger_fn logger, void *arg);

/// @brief Enumerate devices available to the context
/// @param context - the context
/// @param devices - [out] a pointer to receive a an array of axrDeviceInfo
///                  pointers. If NULL then the number of devices is returned.
///                  The returned array is owned by the context and should not
///                  be freed by the caller.
///                  It is valid until the next call to axr_list_devices.
/// @return the number of devices available to the context, or 0 if no devices
///         are available or an error occurred. Check axr_last_error for
///         details.
///
/// Example:
/// ```
///    axrDeviceInfo* devices = nullptr
///    size_t num_devices = axr_list_devices(context, &devices);
///    for (size_t n = 0; n != num_devices; ++n) {
///       printf("Device %s\n", devices[n]->name);
///    }
/// ```
AXR_EXPORT size_t axr_list_devices(axrContext *context,
                                   axrDeviceInfo **devices);

/// @brief Configure a device
/// @param context - the context
/// @param device the device to configure
/// @param properties the options to change. Currently supported options are
///     ======================== ========== =============================================================
///     Property                 Default    Description
///     ======================== ========== =============================================================
///     reboot                            0 If 1, reboot the device before applying the configuration.
///     clock_profile                   800 Device clock profile in MHz
///     clock_profile_core_0-3          800 Per-core clock profile in MHz
///     mvm_utilisation_core_0-3        100 Per-core MVM utilisation as percentage
///     device_firmware                   0 1 to check and reload the firwmare if
///                                         necessary.  'force' to force a reload.
///     power_limit                     0.0 Power limit in watts before throttling is applied, or 0 to disable throttling.
///     ======================== ========== =============================================================
/// @return AXR_SUCCESS if the device was configured successfully.
///         <br>AXR_ERROR_INVALID_CONFIGURATION if a configuration name is
///         invalid. <br>AXR_ERROR_NOT_SUPPORTED if a configuration name is
///         valid but not supported on this hw. AXR_ERROR_VALUE_ERROR if a
///         configuration name is valid but the value is invalid.
///
/// If the change requires time to take effect, AXR_ERROR_PENDING_ERROR is
/// returned. The user should poll the device_ready function to check if the
/// device is ready before any other operations are performed on that device.
///    For example, to configure multiple devices::
///
///          auto *props = axr_create_properties(context, "clock_profile=1000");
///          auto res0 = axr_configure_device(context, device0, props);
///          auto res1 = axr_configure_device(context, device1, props));
///          while (res0 == AXR_ERROR_PENDING_ERROR ||
///                 res1 == AXR_ERROR_PENDING_ERROR) {
///              usleep(50000);
///              res0 = axr_device_ready(context, device0);
///              res1 = axr_device_ready(context, device1);
///          }
AXR_EXPORT axrResult axr_configure_device(axrContext *context,
                                          const axrDeviceInfo *device,
                                          const axrProperties *properties);

/// @brief Check if a device is ready to be connected to after configuration
/// @param context - the context
/// @param device the device to check
/// @return AXR_SUCCESS if the device is ready to be connected to, otherwise an
///         AXR_ERROR_PENDING_ERROR if the device is still configuring.
AXR_EXPORT axrResult axr_device_ready(axrContext *context,
                                      const axrDeviceInfo *device);

/// @brief Read the configuration of a device
/// @param context - the context
/// @param device the device to read the configuration from
/// @return the configuration of the device, or NULL if the device is not valid.
AXR_EXPORT axrProperties *axr_read_device_configuration(
    axrContext *context, const axrDeviceInfo *device);

/// @brief Connect to a device
/// @param context - the context
/// @param device the device to connect to (or NULL to connect to the first
/// available device)
/// @param num_sub_devices number of sub devices to connect to
/// @param properties options to use when connecting to the device
/// @details The device runtime firmware will be checked and updated if
/// necessary. This can be avoided to speed up connection by setting
/// device_firmware_check=0 in the properties.
///
/// Valid properties are :
///
///  ======================== ========== ===========================================
///  Property                 Default    Description
///  ======================== ========== ===========================================
///  device_firmware_check             1 If 1, check the firmware version of the
///                                      device and reload if necessary.
///  ======================== ========== ===========================================
AXR_EXPORT axrConnection *axr_device_connect(axrContext *context,
                                             const axrDeviceInfo *device,
                                             size_t num_sub_devices,
                                             const axrProperties *properties);

/// @brief Set the log configuration for a device log source.
/// @param context - the context
/// @param device - the device for which to set the log level/config
/// @param source - the log source name to configure (e.g. a component/logger)
/// @param config - configuration string
///  TODO add docs here!
/// @return AXR_SUCCESS on success, otherwise an error code indicating failure
AXR_EXPORT axrResult axr_device_set_log_level(axrContext *context,
                                           const axrDeviceInfo *device,
                                           const char *source,
                                           const char *config);

/// @brief Non destructively read the latest available log message from a device source.
/// @param context - the context
/// @param device - the device to read logs from
/// @param source - the log source name to peek
/// @return pointer to a statically managed C string with the latest message,
///         or NULL if none is available; valid until next axr call in thread
AXR_EXPORT const char *axr_device_peek_log(axrContext *context,
                                           const axrDeviceInfo *device,
                                           const char *source);

/// @brief Get statistics about a device log source.
/// @param context - the context
/// @param device - the device to query
/// @param source - the log source name to get stats for
/// @return pointer to a statically managed C string containing stats
///         (format subject to change), never NULL on success
AXR_EXPORT const char *axr_device_get_log_stats(axrContext *context,
                                           const axrDeviceInfo *device,
                                           const char *source);

/// @brief Clear buffered logs for a device source.
/// @param context - the context
/// @param device - the device whose logs to clear
/// @param source - the log source name to clear
/// @return AXR_SUCCESS on success, otherwise an error code
AXR_EXPORT axrResult axr_device_clear_log(axrContext *context,
                                            const axrDeviceInfo *device,
                                            const char *source);

/// @brief Callback signature for device logger streaming.
/// @param arg - user-provided argument passed to the logger
/// @param level - log level of the message
/// @param source - originating log source name
/// @param msg - pointer to the message buffer (not null-terminated)
/// @param msg_size - size of the message buffer in bytes
/// @details The logger callback will be called from a background thread owned
/// (note in the current implementation all messages are AXR_LOG_INFO)
typedef void (*axr_device_logger_fn)(void *arg, axrLogLevel level, const char * source, const char *msg, size_t msg_size);

/// @brief Start streaming logs from one or more device sources.
/// @param context - the context
/// @param device - the device to stream logs from
/// @param sources - comma-separated list of source names to subscribe to
/// @param logger - callback to receive log messages
/// @param arg - user-provided argument to pass to the callback
/// @param clear_existing_logs - if true, clear buffered logs before streaming
/// @details The logger callback will be called from a background thread, this
/// thread is owned by the context and will be stopped when the context is
/// destroyed or when axr_device_stop_logger is called.
/// Note that only one logger can be configured per device.
/// @return AXR_SUCCESS on success, otherwise an error code
AXR_EXPORT axrResult axr_device_start_logger(axrContext *context,
                                              const axrDeviceInfo *device,
                                              const char *sources,
                                              axr_device_logger_fn logger,
                                              void *arg,
                                              bool clear_existing_logs);

/// @brief Stop streaming logs previously started with axr_device_start_logger.
/// @param context - the context
/// @param device - the device to stop streaming from
/// @details This function will block until the background logging thread has
/// exited, if no logging thread is running this will return immediately.
AXR_EXPORT void axr_device_stop_logger(axrContext *context,
                                             const axrDeviceInfo *device);

/// @brief List available text log sources on a device.
/// @param context - the context
/// @param device - the device to query
/// @return pointer to a statically managed C string containing a semi-colon
///         separated list of text sources; valid until next axr call
AXR_EXPORT const char* axr_device_list_log_text_sources(axrContext *context,
                                            const axrDeviceInfo *device);

/// @brief List available binary/data log sources on a device.
/// @param context - the context
/// @param device - the device to query
/// @return pointer to a statically managed C string containing a semi-colon
///         separated list of data sources; valid until next axr call
AXR_EXPORT const char* axr_device_list_log_data_sources(axrContext *context,
                                            const axrDeviceInfo *device);




// --------------------------------------------------------------
// Properties
// --------------------------------------------------------------

/// @brief Create a new properties object
/// @param context - the context
/// @param initial_properties - a string of newline separated key=value pairs.
/// @return a valid properties object (never NULL unless context is NULL)
AXR_EXPORT axrProperties *axr_create_properties(axrContext *context,
                                                const char *initial_properties);

/// @brief Get a list of keys in the properties object
/// @return semi-colon separated list of properties keys on the object
AXR_EXPORT const char *axr_list_properties(axrProperties *properties);

/// @brief Get the value of a property
/// @param properties - the properties object
/// @param key - the key to set
/// @return the value of the property, or NULL if the property does not exist
AXR_EXPORT const char *axr_get_property(axrProperties *properties,
                                        const char *key);

/// @brief Set the value of a property
/// @param properties - the properties object
/// @param key - the key to set
/// @param value - the value to set
AXR_EXPORT void axr_set_property(axrProperties *properties, const char *key,
                                 const char *value);

/// @brief Remove key from properties
AXR_EXPORT void axr_del_property(axrProperties *properties, const char *key);

// --------------------------------------------------------------
// Model
// --------------------------------------------------------------

/// @brief Parse a model from a file
/// @param context - the context
/// @param path the path to the model file
/// return null if the model could not be created
/// if non-null the model creation was successful
AXR_EXPORT
axrModel *axr_load_model(axrContext *context, const char *path);

/// @brief Get the number of inputs to the model
/// @param model the model
AXR_EXPORT size_t axr_num_model_inputs(axrModel *model);

/// @brief Get details of the input tensor n
/// @param model the model
/// @param n the input tensor index, if out of range AXR_ERROR_INVALID_ARGUMENT
/// is set and the return ndims is 0
AXR_EXPORT axrTensorInfo axr_get_model_input(axrModel *model, size_t n);

/// @brief Get the number of outputs to the model
/// @param model the model
AXR_EXPORT size_t axr_num_model_outputs(axrModel *model);

/// @brief Get details of the output tensor n
/// @param model the model
/// @param n the output tensor index, if out of range AXR_ERROR_INVALID_ARGUMENT
/// is set and the return ndims is 0
AXR_EXPORT axrTensorInfo axr_get_model_output(axrModel *model, size_t n);

/// @brief Get further information about the model emitted by the compiler.
/// @param model the model
/// @details This function returns a set of properties that describe the model,
/// The properties available are subject to change. Some keys that might be
/// included are:
///
///  =================== ======================================================
///  Key                 Description
///  =================== ======================================================
///  preamble_graph      Relative path to a preamble ONNX file containing the
///                      initial nodes of the model. These nodes are removed
///                      by the compiler and executed on the host.
///  postamble_graph     Relative path to a postamble ONNX file containing the
///                      final nodes of the model. These nodes are removed
///                      by the compiler and executed on the host.
///  input_tensor_layout Always NHWC in this version.
///  =================== ======================================================
AXR_EXPORT axrProperties *axr_get_model_properties(axrModel *model);

// --------------------------------------------------------------
// Connection
// --------------------------------------------------------------

/// @brief Load a model onto a connected device
/// @param connection the connected device
/// @param model the model to load
/// @param properties the properties to use when loading the model, or NULL to
///        use the default set of properties.
/// @details Valid properties are :
///
/// ================= ======= =================================================================
/// Property          Default Description
/// ================= ======= =================================================================
/// aipu_cores        0       L2 resources to allocate for the model, set to batch size
/// num_sub_devices   0       Number of sub-devices to use, set to batch size of the model
/// input_dmabuf      0       True if the input arguments are dmabuf file descriptors
/// device_profiling  0       True to enable device profiling
/// host_profiling    0       True to enable host profiling
/// output_dmabuf     0       True if the output arguments are dmabuf file descriptors
/// double_buffer     0       True to enable double buffering
/// elf_in_ddr        1       True if the model was compiled with elf_in_ddr as True.
/// ================= ======= =================================================================
///
AXR_EXPORT
axrModelInstance *axr_load_model_instance(axrConnection *connection,
                                          axrModel *model,
                                          axrProperties *properties);

// --------------------------------------------------------------
// ModelInstance
// --------------------------------------------------------------

/// @brief Run one frame the model instance
/// @param instance the model instance
/// @param inputs/num_inputs an array of input arguments
/// @param output/num_outputs an array of output arguments
/// @return AXR_SUCCESS if the model was run successfully, otherwise an error
///         code
AXR_EXPORT
axrResult axr_run_model_instance(axrModelInstance *instance,
                                 axrArgument *inputs, size_t num_inputs,
                                 axrArgument *output, size_t num_outputs);

// --------------------------------------------------------------
// Error reporting
// --------------------------------------------------------------

/// @brief Activate the error reporter.
/// This forks a child process that monitors the parent process.
/// If the parent dies unexpectedly or if the parent calls
/// axr_trigger_error_reporter(), the child process generates a
/// report containing as much information as possible about the host
/// environment and the device state at time of reporting.
AXR_EXPORT bool axr_activate_error_reporter(void);

/// @brief Explicitly trigger the error reporter.
/// This tells the child process to generate a report.  Use this to
/// if the parent process detects an error situation (but didn't crash).
AXR_EXPORT bool axr_trigger_error_reporter(void);

#ifdef __cplusplus
}
#include "axruntime/axruntime.hpp"
#endif
