/* Copyright (c) 2024 Axelera AI. All rights reserved. */
#pragma once

#if defined(_MSVC_LANG)
#define CXX_VERSION _MSVC_LANG
#else
#define CXX_VERSION __cplusplus
#endif

// G++ 10+ supports C++20 features used in this code
#if (defined(__GNUG__) && (__GNUG__ < 10)) || \
	(!defined(__GNUG__) && CXX_VERSION < 202002L)
#error C++20 compiler required
#endif

#include "AxeleraDevice.hpp"

namespace axelera
{
struct TransferResult {
	bool success;
	bool is_async;
};

class DmaBuf {
public:
	static size_t alloc_size(size_t size);

	static DmaBuf alloc(size_t size, bool map = true);
	static DmaBuf import(axl_file_handle_t handle, size_t size,
			     bool map = false);

	DmaBuf() = default;

	DmaBuf(DmaBuf &&other);
	DmaBuf &operator=(DmaBuf &&other);

	~DmaBuf();

	axl_file_handle_t get_dmabuf_handle() const;

	bool is_open() const;
	bool is_imported() const;

	void reset();

	size_t size() const;
	size_t allocated_size() const;

	std::span<std::byte> begin_access();
	void end_access();

	auto access()
	{
		return HostAccess{ *this };
	}

	bool is_attached() const;

	void attach(Device &device);
	void attach(Device &&device);

	void detach();

	bool is_mapped() const;

	void map();
	void unmap();

	bool dma_transfer(TransferDirection direction, uint64_t device_addr,
			  uint32_t offset = 0,
			  size_t size = std::dynamic_extent,
			  bool dma_async = false);

	bool wait_for_dma();

	void mmap_transfer(TransferDirection direction, Device &device,
			   uint64_t device_addr, uint32_t offset = 0,
			   size_t size = std::dynamic_extent);

	TransferResult transfer(TransferDirection direction, Device &device,
				uint64_t device_addr, uint32_t offset = 0,
				size_t size = std::dynamic_extent,
				bool dma_async = false);

	bool write_to_device_dma(uint64_t device_addr, uint32_t offset = 0,
				 size_t size = std::dynamic_extent,
				 bool async = false);

	bool read_from_device_dma(uint64_t device_addr, uint32_t offset = 0,
				  size_t size = std::dynamic_extent,
				  bool async = false);

	void write_to_device_mmap(Device &device, uint64_t device_addr,
				  uint32_t offset = 0,
				  size_t size = std::dynamic_extent);

	void read_from_device_mmap(Device &device, uint64_t device_addr,
				   uint32_t offset = 0,
				   size_t size = std::dynamic_extent);

	TransferResult write_to_device(Device &device, uint64_t device_addr,
				       uint32_t offset = 0,
				       size_t size = std::dynamic_extent,
				       bool dma_async = false);

	TransferResult read_from_device(Device &device, uint64_t device_addr,
					uint32_t offset = 0,
					size_t size = std::dynamic_extent,
					bool dma_async = false);

	size_t get_dma_threshold(TransferDirection direction) const;
	void set_dma_threshold(TransferDirection direction, size_t threshold);

	size_t get_dma_write_threshold() const;
	void set_dma_write_threshold(size_t threshold);

	size_t get_dma_read_threshold() const;
	void set_dma_read_threshold(size_t threshold);

	static constexpr size_t DEFAULT_DMA_WRITE_THRESHOLD = 32;
	static constexpr size_t DEFAULT_DMA_READ_THRESHOLD = 32;

private:
	class HostAccess {
	public:
		HostAccess(DmaBuf &dmabuf);

		HostAccess(const HostAccess &) = delete;

		~HostAccess();

		std::span<std::byte> span() const;
		std::span<const std::byte> cspan() const;

		std::span<std::byte>
		subspan(size_t offset,
			size_t count = std::dynamic_extent) const;
		std::span<const std::byte>
		csubspan(size_t offset,
			 size_t count = std::dynamic_extent) const;

		std::byte *data() const;
		const std::byte *cdata() const;

		size_t size() const;

		auto begin() const
		{
			return span().begin();
		}

		auto end() const
		{
			return span().end();
		}

		std::byte &operator[](size_t idx) const;

	private:
		DmaBuf &m_dmabuf;
	};

	size_t subspan_size(size_t offset,
			    size_t count = std::dynamic_extent) const;

	std::span<std::byte> span();
	std::span<const std::byte> span() const;

	void host_sync_start();
	void host_sync_end();

	struct Internals {
		Internals()
			: axldev(nullptr)
			, host_ptr(nullptr)
			, size(0)
			, host_access_count(0)
			, async_dma_in_progress(false)
			, dma_write_threshold(DEFAULT_DMA_WRITE_THRESHOLD)
			, dma_read_threshold(DEFAULT_DMA_READ_THRESHOLD)
		{
			axl_dev_init_dmabuf(&dmat);
		}
		axl_dmabuf_desc_t dmat;
		axl_dev_t *axldev;
		std::byte *host_ptr;
		size_t size;
		unsigned host_access_count;
		bool async_dma_in_progress;
		size_t dma_write_threshold;
		size_t dma_read_threshold;
	};

	Internals m_internals{};
};
} // namespace axelera
