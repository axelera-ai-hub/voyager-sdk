// Copyright (c) 2024 Axelera AI. All rights reserved.
#pragma once

#if defined(_MSVC_LANG)
#define CXX_VERSION _MSVC_LANG
#else
#define CXX_VERSION __cplusplus
#endif

// G++ 10+ supports C++20 features used in this code
#if (defined(__GNUG__) && (__GNUG__ < 10)) || \
	(!defined(__GNUG__) && CXX_VERSION < 202002L)
#error C++20 compiler required
#endif

#include "libaxldev.h"
#include "sysctl_mem.h"

#include <atomic>
#include <cstddef>
#include <cstdint>
#include <functional>
#include <future>
#include <memory>
#include <optional>
#include <set>
#include <span>
#include <string>
#include <string_view>
#include <vector>

namespace axelera
{
template <typename T>
using UniqueMallocdPtr =
	std::unique_ptr<T, decltype([](T *ptr) { std::free(ptr); })>;

enum class TransferDirection {
	write_to_device,
	read_from_device,
};

constexpr int as_dma_flag(const TransferDirection direction)
{
	return (direction == TransferDirection::read_from_device) ?
		       AXL_DMABUF_XFER_FLAG_READ :
		       AXL_DMABUF_XFER_FLAG_WRITE;
}

using LogSource = stream_source_t;
using LogDataType = stream_type_t;

using LogCallback = std::function<void(LogSource, std::string_view)>;

enum class AxeleraComputeCore {
	AICore,
	PVECore,
};

class Device {
public:
	struct Throttling {
		int temp_threshold;
		int temp_hysteresis;
		int mvm_limit; // Valid for SW, for HW reads as 1 and ignored on write.
	};

	/// @brief Represents a Monviso card with its grouped devices.
	struct MonvisoCard {
		uint16_t pes_group; ///< PES group ID (e.g., 51, 70, 76)
		std::vector<std::string> devices; ///< Device names in this card
	};

	/// @brief Represents the locations of the stage0 and runtime firmware.
	struct FirmwareLocations {
		std::string stage0;
		std::string runtime;
	};

	static Device open(int device_index);
	static Device open(const char *device_name);

	/// @brief Get the required version for this axldev lib (default omega).
	static std::string required_firmware_version();
	static std::string required_firmware_version(std::string generation);

	/// @brief Get a list of all available device names.
	/// @return Vector of device name strings (e.g., ["metis-0:3:0", "europa-1:1:0"]).
	///         Returns empty vector if no devices found or on error.
	static std::vector<std::string> get_device_list();

	/// @brief Get a list of Monviso cards with their grouped devices.
	/// @details Monviso cards have devices grouped together with a PES group ID.
	///          Devices with pes_group != 0xFFFF are considered part of a Monviso card.
	///          Each MonvisoCard contains the PES group ID and vector of device names.
	/// @return Vector of MonvisoCard structs, each representing one Monviso card.
	///         Returns empty vector if no Monviso cards found or on error.
	static std::vector<MonvisoCard> get_monviso_list();

	/// @brief Get the firmware directory. e.g. /opt/axelera/device/omega
	/// this is a best effort guess based on, in order:
	/// AXE_CHROOT - which will be suffixed with /opt/axelera/device/<gen>
	///     This overrides all (for backwards compat)
	/// AXELERA_DEVICE_DIR - which will be NOT suffixed with /<gen>, as it is
	///	 expected to point directly to the device dir
	/// Failing those env var overrides, the firmware directory is inferred from
	/// the location of the current module (libaxldev.so/dll).  Based on one of
	/// known installation layouts.
	///
	///  Runtime dir                     Device dir
	///  /opt/axelera/runtime            /opt/axelera/device/<gen>
	///  /opt/axelera/runtime-vX.Y.Z     /opt/axelera/device-vX.Y.Z/<gen>
	///  /opt/axelera/sdk-vX.Y.Z/runtime /opt/axelera/sdk-vX.Y.Z/<gen>
	///  site-packages/axelera/runtime   site-packages/axelera/<gen>
	///
	/// @param generation Hardware generation, e.g. omega, europa
	/// @return the root of the firmware directory for the requested generation
	/// or empty string if it could not be determined using any of the methods.
	static std::string get_firmware_dir(const std::string &generation);

	/// @brief overload of get_firmware_dir() for unit testing purposes.
	static std::string get_firmware_dir(const std::string &generation,
					    const std::string &lib_path);

	/// @brief Get the stage0 and runtime firmware paths.
	/// @details If AIPU_RUNTIME_STAGE0_<gen> and AIPU_FIRMWARE_<gen> are set use
	/// them. Otherwise obtain the device dir using get_firmware_dir(gen) and
	/// <device_dir_for_gen>/bin/start_axelera_runtime_stage0.bin
	///	<device_dir_for_gen>/bin/start_axelera_runtime.elf
	/// @param generation
	/// @return
	static FirmwareLocations
	get_firmware_locations(const std::string &generation);
	/// @brief overload of get_firmware_locations() for unit testing purposes.
	static FirmwareLocations
	get_firmware_locations(const std::string &generation,
			       const std::string &lib_path);

	Device() = default;

	Device(Device &&other);

	Device &operator=(Device &&other);

	~Device();

	bool is_open() const;

	void close();
	void close_if_open();

	/// @brief Get the name of the device, e.g. metis-0:3:0
	std::string name() const;

	/// @brief Get the hardware generation, e.g. alpha, omega, europa
	std::string hw_generation() const;

	/// @brief Get the current loaded firmware version of the device.
	/// @return the firmware version string stripped of whitespace, or empty string on failure.
	std::string firmware_version();

	/// @brief Get the version of the firmware currently stored in flash memory.
	std::string flashed_firmware_version();

	/// @brief Get the board type of the device.
	axelera_board_type board_type();

	/// @brief Get the board revision of the device.
	int board_revision();

	/// @brief Get the number of AI cores on the device.
	int get_num_aicores();

	/// @brief Get the number of PVE cores on the device.
	int get_num_pve_cores();

	/// @brief Get the LogSource for a specific compute core.
	/// @param core_type The type of compute core (AICore or PVECore).
	/// @param core_id The ID of the core (0-based index).
	/// @param dtype The data type (text for log, binary for trace).
	/// @return LogSource if valid, STREAM_SOURCE_MAX if invalid.
	/// @note Returns STREAM_SOURCE_MAX if core_id is invalid or no cores available.
	LogSource get_compute_core_log_source(AxeleraComputeCore core_type,
					      int core_id,
					      LogDataType dtype) const;

	/// @brief Get the board controller firmware version of the device.
	std::string board_controller_firmware_version();

	/// @brief Get the version of the board controller firmware stored in flash memory.
	std::string flashed_board_controller_firmware_version();

	/// @brief Get the board controller board type.
	std::string board_controller_board_type();

	/// @brief Execute a cold-boot.
	/// @return true on success, false on failure.
	bool cold_boot(uint32_t mode);

	/// @brief Load the stage0 and runtime.
	/// @details See get_firmware_locations() for how the firmware paths are determined.
	/// @return: empty string on success, error message on failure.
	std::string load_firmware();

	/// @brief Get the DDR size of the device.
	/// @return: DDR size in bytes or 0xffff_ffff_ffff_ffff on failure.
	uint64_t get_ddr_size();

	/// @brief Get the given core clock frequency in MHz.
	/// @return -1 on failure, or the clock frequency in MHz.
	int get_core_clock(int core_id);

	/// @brief Set the given core clock to the given value in MHz.
	/// @return true on success, false on failure.
	bool set_core_clock(int core_id, int clock);

	/// @brief Get the clock profile.
	/// @return AXL_CLOCK_PROFILE_UNKNOWN on failure, or the clock profile.
	axl_clock_profile get_clock_profile();

	/// @brief Set the clock profile.
	/// @return true on success, false on failure.
	bool set_clock_profile(axl_clock_profile clock);

	/// @brief Get the MVM utilization limit in percentage.
	/// @return -1 on failure, or the MVM utilisation limit in percentage (0-100)
	int get_mvm_utilization(int core_id);

	/// @brief Set the MVM utilisation limit in percentage.
	/// @return: true on success, false on failure.
	bool set_mvm_utilization(int core_id, int limit);

	/// @brief Get the SW throttling: temperature threshold/hysteresis in celsius,
	///        MVM utilisation in percentage.
	/// @return std::nullopt on failure, or the SW throttling
	std::optional<Throttling> get_sw_throttling();

	/// @brief Set the SW throttling: temperature threshold/hysteresis in celsius,
	///        MVM utilisation in percentage.
	/// @return: true on success, false on failure.
	bool set_sw_throttling(Throttling _throttling);

	/// @brief Get the HW throttling: temperature threshold/hysteresis in celsius,
	///        MVM utilisation is always 1 and not configurable.
	/// @return std::nullopt on failure, or the HW throttling
	std::optional<Throttling> get_hw_throttling();

	/// @brief Set the HW throttling: temperature threshold/hysteresis in celsius,
	///        MVM utilisation is statically 1 and ignored.
	/// @return: true on success, false on failure.
	bool set_hw_throttling(Throttling _throttling);

	/// @brief Get the frequency downscaling temperature threshold/hysteresis in celsius,
	///        MVM utilisation in Throttling is irrelevant and ignored
	/// @return std::nullopt on failure, or the frequency downscaling parameters
	std::optional<Throttling> get_freq_downscaling();

	/// @brief Set the frequency downscaling temperature threshold/hysteresis in celsius,
	///        MVM utilisation in Throttling is irrelevant and ignored
	/// @return: true on success, false on failure.
	bool set_freq_downscaling(Throttling _throttling);

	/// @brief Get the PVT warning threshold.
	/// @return: -1 on failure, or the PVT warning threshold.
	int get_pvt_warning_threshold();

	/// @brief Set the PVT warning threshold.
	/// @return: true on success, false on failure.
	bool set_pvt_warning_threshold(int threshold);

	axl_dev_t *get_axl_dev();

	bool is_in_l2(uint64_t device_addr, size_t size) const;

	std::byte *get_host_ptr(uint64_t device_l2_addr) const;

	device_sys_ctl_t *get_sysctl() const;

	uint64_t get_device_addr(const volatile void *l2_host_ptr) const;

	/// @brief Get the start address of the L2 memory region (virtual).
	uint64_t get_l2_addr_begin() const;
	/// @brief Get the end address of the L2 memory region (virtual).
	uint64_t get_l2_addr_end() const;

	bool dma_transfer(TransferDirection direction,
			  std::span<std::byte> host_buffer,
			  uint64_t device_addr);

	void mmap_transfer(TransferDirection direction,
			   std::span<std::byte> host_buffer,
			   uint64_t device_l2_addr);

	bool transfer(TransferDirection direction,
		      std::span<std::byte> host_buffer, uint64_t device_addr);

	bool write_to_device_dma(std::span<const std::byte> src,
				 uint64_t device_addr);

	bool read_from_device_dma(uint64_t device_addr,
				  std::span<std::byte> dst);

	void write_to_device_mmap(std::span<const std::byte> src,
				  uint64_t device_l2_addr);

	void read_from_device_mmap(uint64_t device_l2_addr,
				   std::span<std::byte> dst);

	bool write_to_device(std::span<const std::byte> src,
			     uint64_t device_addr);

	bool read_from_device(uint64_t device_addr, std::span<std::byte> dst);

	size_t get_dma_threshold(TransferDirection direction) const;
	void set_dma_threshold(TransferDirection direction, size_t threshold);

	size_t get_dma_write_threshold() const;
	void set_dma_write_threshold(size_t threshold);

	size_t get_dma_read_threshold() const;
	void set_dma_read_threshold(size_t threshold);

	bool wait_for_msi(axl_msi msi, int timeout_in_seconds = 0) const;
	bool get_dma_stats(axl_dev_dma_stats_t *stats) const;

	static constexpr size_t DEFAULT_DMA_WRITE_THRESHOLD = 256;
	static constexpr size_t DEFAULT_DMA_READ_THRESHOLD = 256;

	/// @brief Get string name for a log source (reads from firmware metadata).
	/// @param src The log source.
	/// @return Human-readable name of the source, or std::nullopt if not found.
	std::optional<std::string> to_string(LogSource src) const;

	/// @brief Find a log source by its string name (searches firmware metadata).
	/// @param str The name to search for.
	/// @return The LogSource if found, std::nullopt otherwise.
	std::optional<LogSource> to_log_source(const std::string &str) const;

	/// @brief Get the data type for a log source (reads from firmware metadata).
	/// @param src The log source.
	/// @return The data type (text or binary), or std::nullopt if not found.
	std::optional<LogDataType> log_source_data_type(LogSource src) const;

	/// @brief Set log level for specified log source.
	/// @param src The log source to set the log level for.
	/// @param config The log level configuration string. in the form "L[:M]",
	/// where L can be err, wrn, dbg, inf, none.
	/// where M can be megakernel, runtime for ai cores, or
	/// or the name of any registered Zephyr log source for sysctrl.
	///  If not specified, log level is set for both.
	/// @return true on success, false on failure.
	bool set_log_level(LogSource src, const std::string &config);

	/// @brief Read and return, but but do not remove log data from specified log source.
	/// @return on an error, return an empty optional.  An empty string indicates the log was read but is empty.
	std::optional<std::string> peek_log(LogSource src);

	/// @brief Clear log buffer for specified log source.
	/// @return true on success, false on failure.
	bool clear_log(LogSource src);

	/// @brief Get log statistics for specified log source.
	/// @return on an error, return an empty optional.
	/// @details The format of the returned string is subject to change, it is intended to be
	/// human readable and usable only for debugging purposes.
	std::optional<std::string> log_stats(LogSource src);

	/// @brief Get a list of available log sources on the device by type.
	/// @param type The type of log sources to retrieve (text or binary).
	/// @return empty vector on failure, otherwise a vector of log sources matching the type.
	std::vector<LogSource> available_log_sources(LogDataType type);

	/// @brief Get a list of available text log sources on the device.
	/// @return empty vector on failure, otherwise a vector of text log sources.
	std::vector<LogSource> available_log_text_sources();

	/// @brief Get a list of available binary/data log sources on the device.
	/// @return empty vector on failure, otherwise a vector of data log sources.
	std::vector<LogSource> available_log_data_sources();

private:
	struct Internals {
		std::string name;

		axl_dev_t *axldev;

		std::byte *l2_base;

		size_t dma_write_threshold = DEFAULT_DMA_WRITE_THRESHOLD;
		size_t dma_read_threshold = DEFAULT_DMA_READ_THRESHOLD;
	};

	Internals m_internals{};
};

class LogCollector {
public:
	explicit LogCollector(Device &&device);

	/// @brief Start log collector thread for specified log sources, when new data arrives
	/// 	  the callback function is called.
	/// @param callback The function to call when new log data is available.
	/// @param srcs The set of log sources to collect logs from, if empty false is returned.
	/// @param clear_on_start If true, the log buffers are cleared when starting the collector.
	/// @details The thread is owned by the LogCollector object and stopped automatically on destruction or stop_thread.
	/// @return true on success, false on failure.
	bool start_thread(axelera::LogCallback callback,
			  std::set<LogSource> srcs, bool clear_on_start);

	/// @brief Signal to stop the log collector thread and wait for it to finish.
	/// @details This is called automatically on destruction.
	/// @return Returns ownership of the device back to the caller.
	Device stop_thread();

	~LogCollector();

private:
	axelera::Device device;
	std::atomic_bool stop_signal{ false };
	std::future<Device> collector;
};

} // namespace axelera
