// Copyright Axelera AI, 2023
// All Rights Reserved
// *** Axelera AI Confidential ***

#pragma once

#include "axelera_ze_api.hpp"

namespace axelera::ze
{
struct DriverAndDevices
{
    DriverHandle driver;
    std::vector<DeviceHandle> devices;
};

inline Expected<std::vector<DriverAndDevices>>
getAxeleraDriversAndDevices(const std::source_location& location = std::source_location::current())
{
    constexpr uint32_t AXELERA_VENDOR_ID = 0x1F9Du;

    std::vector<DriverAndDevices> axeleraDevices;

    RETURN_IF_ERROR(Init(ZE_INIT_FLAG_GPU_ONLY, location));

    const auto drivers = DriverGet(location);
    RETURN_IF_ERROR(drivers);

    for (const DriverHandle driver : drivers.value()) {

        DriverAndDevices driverAndDevices{
            .driver = driver,
        };

        const auto devices = DeviceGet(*driverAndDevices.driver, location);
        RETURN_IF_ERROR(devices);

        for (const DeviceHandle device : devices.value()) {

            const auto properties = DeviceGetProperties(*device, location);
            RETURN_IF_ERROR(properties);

            if (properties->vendorId == AXELERA_VENDOR_ID) {
                driverAndDevices.devices.emplace_back(device);
            }
        }

        if (!driverAndDevices.devices.empty()) {
            axeleraDevices.emplace_back(std::move(driverAndDevices));
        }
    }

    return axeleraDevices;
}

inline Expected<void>
setKernelArgs(_ze_kernel_handle_t& kernel, const std::span<const KernelArg>& args,
              const std::source_location& location = std::source_location::current())
{
    for (uint32_t i = 0; i < args.size(); ++i) {
        RETURN_IF_ERROR(KernelSetArgumentValue(kernel, i, args[i], location));
    }
    return {};
}

template <uint32_t N>
auto setKernelArgs(_ze_kernel_handle_t& kernel, const KernelArg(& args)[N],
                   const std::source_location& location = std::source_location::current())
{
    return setKernelArgs(kernel, std::span(args), location);
}

} // namespace axelera::ze
