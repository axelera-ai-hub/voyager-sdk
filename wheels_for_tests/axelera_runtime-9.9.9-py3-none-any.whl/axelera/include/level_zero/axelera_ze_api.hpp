// Copyright Axelera AI, 2023
// All Rights Reserved
// *** Axelera AI Confidential ***

#pragma once

#include "ze_api.h"

#include <algorithm>
#include <bit>
#include <concepts>
#include <cstdint>
#include <iomanip>
#include <memory>
#include <optional>
#include <ranges>
#include <source_location>
#include <span>
#include <sstream>
#include <string_view>
#include <string>
#include <variant>
#include <vector>

namespace axelera::ze
{
inline std::string toHexString(const std::integral auto i)
{
    return (std::ostringstream{} << "0x" << std::hex << +i).str();
}

template <typename Enum> requires std::is_enum_v<Enum>
std::string toHexString(const Enum e)
{
    return toHexString(static_cast<std::underlying_type_t<Enum>>(e));
}

inline std::string toString(const ze_result_t result)
{
    switch (result) {
        #define ZE_RESULT_TO_STRING_CASE(x) case x: return #x;
            ZE_RESULT_TO_STRING_CASE(ZE_RESULT_SUCCESS)
            ZE_RESULT_TO_STRING_CASE(ZE_RESULT_NOT_READY)
            ZE_RESULT_TO_STRING_CASE(ZE_RESULT_ERROR_UNINITIALIZED)
            ZE_RESULT_TO_STRING_CASE(ZE_RESULT_ERROR_DEVICE_LOST)
            ZE_RESULT_TO_STRING_CASE(ZE_RESULT_ERROR_INVALID_ARGUMENT)
            ZE_RESULT_TO_STRING_CASE(ZE_RESULT_ERROR_OUT_OF_HOST_MEMORY)
            ZE_RESULT_TO_STRING_CASE(ZE_RESULT_ERROR_OUT_OF_DEVICE_MEMORY)
            ZE_RESULT_TO_STRING_CASE(ZE_RESULT_ERROR_MODULE_BUILD_FAILURE)
            ZE_RESULT_TO_STRING_CASE(ZE_RESULT_ERROR_INSUFFICIENT_PERMISSIONS)
            ZE_RESULT_TO_STRING_CASE(ZE_RESULT_ERROR_NOT_AVAILABLE)
            ZE_RESULT_TO_STRING_CASE(ZE_RESULT_ERROR_UNSUPPORTED_VERSION)
            ZE_RESULT_TO_STRING_CASE(ZE_RESULT_ERROR_UNSUPPORTED_FEATURE)
            ZE_RESULT_TO_STRING_CASE(ZE_RESULT_ERROR_INVALID_NULL_HANDLE)
            ZE_RESULT_TO_STRING_CASE(ZE_RESULT_ERROR_HANDLE_OBJECT_IN_USE)
            ZE_RESULT_TO_STRING_CASE(ZE_RESULT_ERROR_INVALID_NULL_POINTER)
            ZE_RESULT_TO_STRING_CASE(ZE_RESULT_ERROR_INVALID_SIZE)
            ZE_RESULT_TO_STRING_CASE(ZE_RESULT_ERROR_UNSUPPORTED_SIZE)
            ZE_RESULT_TO_STRING_CASE(ZE_RESULT_ERROR_UNSUPPORTED_ALIGNMENT)
            ZE_RESULT_TO_STRING_CASE(ZE_RESULT_ERROR_INVALID_SYNCHRONIZATION_OBJECT)
            ZE_RESULT_TO_STRING_CASE(ZE_RESULT_ERROR_INVALID_ENUMERATION)
            ZE_RESULT_TO_STRING_CASE(ZE_RESULT_ERROR_UNSUPPORTED_ENUMERATION)
            ZE_RESULT_TO_STRING_CASE(ZE_RESULT_ERROR_UNSUPPORTED_IMAGE_FORMAT)
            ZE_RESULT_TO_STRING_CASE(ZE_RESULT_ERROR_INVALID_NATIVE_BINARY)
            ZE_RESULT_TO_STRING_CASE(ZE_RESULT_ERROR_INVALID_GLOBAL_NAME)
            ZE_RESULT_TO_STRING_CASE(ZE_RESULT_ERROR_INVALID_KERNEL_NAME)
            ZE_RESULT_TO_STRING_CASE(ZE_RESULT_ERROR_INVALID_FUNCTION_NAME)
            ZE_RESULT_TO_STRING_CASE(ZE_RESULT_ERROR_INVALID_GROUP_SIZE_DIMENSION)
            ZE_RESULT_TO_STRING_CASE(ZE_RESULT_ERROR_INVALID_GLOBAL_WIDTH_DIMENSION)
            ZE_RESULT_TO_STRING_CASE(ZE_RESULT_ERROR_INVALID_KERNEL_ARGUMENT_INDEX)
            ZE_RESULT_TO_STRING_CASE(ZE_RESULT_ERROR_INVALID_KERNEL_ARGUMENT_SIZE)
            ZE_RESULT_TO_STRING_CASE(ZE_RESULT_ERROR_INVALID_KERNEL_ATTRIBUTE_VALUE)
            ZE_RESULT_TO_STRING_CASE(ZE_RESULT_ERROR_INVALID_COMMAND_LIST_TYPE)
            ZE_RESULT_TO_STRING_CASE(ZE_RESULT_ERROR_OVERLAPPING_REGIONS)
            ZE_RESULT_TO_STRING_CASE(ZE_RESULT_ERROR_UNKNOWN)
        #undef ZE_RESULT_TO_STRING_CASE
        default:
            return toHexString(result);
    }
}

struct Error
{
    std::string makeDecoratedMessage() const
    {
        const auto locationString = std::string(location.file_name()) + ":" + std::to_string(location.line());
        return "ERROR: " + toString(errorCode) + " at: " + locationString + ": " + message;
    }

    ze_result_t errorCode;
    std::string message;
    std::source_location location;
};

struct Exception : Error, std::exception
{
    Exception(Error error)
        : Error(std::move(error))
    {}

    const char* what() const noexcept override
    {
        return decoratedMessage.c_str();
    }

    std::string decoratedMessage = makeDecoratedMessage();
};

template <typename T>
class Expected
{
public:
    Expected(T value)
        : m_variant(std::move(value))
    {}

    Expected(Error error)
        : m_variant(std::move(error))
    {}

    // Conversions must be explicit
    template <typename U>
    explicit Expected(U&& value)
        : m_variant(T(std::forward<U>(value)))
    {}

    explicit operator bool() const
    {
        return has_value();
    }

    operator T() &&
    {
        return std::move(*this).value();
    }

    const T* operator->() const
    {
        return &value();
    }

    bool has_value() const
    {
        return std::holds_alternative<T>(m_variant);
    }

    T value() &&
    {
        if (const auto value = std::get_if<T>(&m_variant)) {
            return std::move(*value);
        }
        throw Exception(std::move(std::get<Error>(m_variant)));
    }

    const T& value() const&
    {
        if (const auto value = std::get_if<T>(&m_variant)) {
            return *value;
        }
        throw Exception(std::get<Error>(m_variant));
    }

    Error error() &&
    {
        return std::get<Error>(std::move(m_variant));
    }

    const Error& error() const&
    {
        return std::get<Error>(m_variant);
    }

private:
    std::variant<T, Error> m_variant;
};

template <>
class Expected<void>
{
public:
    Expected() = default;

    Expected(Error error)
        : m_error(std::move(error))
    {}

    ~Expected() noexcept(false)
    {
        if (m_error && !m_wasChecked) {
            throw Exception(std::move(*m_error));
        }
    }

    explicit operator bool() const
    {
        m_wasChecked = true;
        return has_value();
    }

    bool has_value() const
    {
        m_wasChecked = true;
        return !m_error.has_value();
    }

    Error error() &&
    {
        return std::move(m_error).value();
    }

    const Error& error() const&
    {
        return m_error.value();
    }

private:
    std::optional<Error> m_error;
    mutable bool m_wasChecked = false;
};

inline Expected<void> checkResult(const ze_result_t result, const std::string_view& message, const std::source_location& location)
{
    if (result != ZE_RESULT_SUCCESS) {
        return Error{
            .errorCode = result,
            .message = std::string(message),
            .location = location
        };
    }
    return {};
}

template <auto& fn, typename = decltype(fn)>
struct CheckedHelper;

template <auto& fn, typename... Args>
struct CheckedHelper<fn, ze_result_t(&)(Args...)>
{
    Expected<void> operator()(Args... args, const std::string_view& message, const std::source_location& location) const noexcept
    {
        return checkResult(fn(args...), message, location);
    }
};

template <auto& fn, typename... Args>
Expected<void> checked(Args&&... args)
{
    return CheckedHelper<fn>{}(std::forward<Args>(args)...);
}

#define RETURN_IF_ERROR(expr) \
    if (const auto& expected_value = (expr); !expected_value) { \
        return expected_value.error(); \
    }

template <auto& zeDestroyFn>
struct SimpleDeleter
{
    void operator()(const auto ptr) const noexcept
    {
        zeDestroyFn(ptr);
    }
};

using DriverHandle = ze_driver_handle_t;
using DeviceHandle = ze_device_handle_t;
using ContextHandle = std::unique_ptr<_ze_context_handle_t, SimpleDeleter<zeContextDestroy>>;
using CommandQueueHandle = std::unique_ptr<_ze_command_queue_handle_t, SimpleDeleter<zeCommandQueueDestroy>>;
using CommandListHandle = std::unique_ptr<_ze_command_list_handle_t, SimpleDeleter<zeCommandListDestroy>>;
using EventPoolHandle = std::unique_ptr<_ze_event_pool_handle_t, SimpleDeleter<zeEventPoolDestroy>>;
using EventHandle = std::unique_ptr<_ze_event_handle_t, SimpleDeleter<zeEventDestroy>>;
using ModuleHandle = std::unique_ptr<_ze_module_handle_t, SimpleDeleter<zeModuleDestroy>>;
using ModuleBuildLogHandle = std::unique_ptr<_ze_module_build_log_handle_t, SimpleDeleter<zeModuleBuildLogDestroy>>;
using KernelHandle = std::unique_ptr<_ze_kernel_handle_t, SimpleDeleter<zeKernelDestroy>>;

struct MemHandleDeleter
{
    void operator()(void* const ptr) const noexcept
    {
        zeMemFree(ctx, ptr);
    }

    _ze_context_handle_t* ctx = nullptr;
};

template <typename T = std::byte>
class MemHandle : public std::unique_ptr<T[], MemHandleDeleter>
{
public:
    MemHandle() = default;

    MemHandle(_ze_context_handle_t& ctx, const std::span<T>& span)
        : std::unique_ptr<T[], MemHandleDeleter>(span.data(), { &ctx })
        , m_size{ span.size() }
    {}

    std::span<T> span() const
    {
       return { this->get(), m_size };
    }

    std::span<const T> cspan() const
    {
        return span();
    }

    size_t sizeInBytes() const
    {
       return m_size * sizeof(T);
    }

private:
    // Make it impossible to reset the pointer without also providing context and size.
    using std::unique_ptr<T[], MemHandleDeleter>::reset;

    size_t m_size = 0;
};

template <>
class MemHandle<void> : public std::unique_ptr<void, MemHandleDeleter>
{
public:
    MemHandle() = default;

    MemHandle(_ze_context_handle_t& ctx, void* const ptr, const size_t size)
        : std::unique_ptr<void, MemHandleDeleter>(ptr, { &ctx })
        , m_size{ size }
    {}

    size_t sizeInBytes() const
    {
       return m_size;
    }

private:
    // Make it impossible to reset the pointer without also providing context and size.
    using std::unique_ptr<void, MemHandleDeleter>::reset;

    size_t m_size = 0;
};

template <typename T>
MemHandle(Expected<MemHandle<T>>) -> MemHandle<T>;

template <typename T, uint32_t N>
using SmartInitializerList = const std::reference_wrapper<const T>(&)[N];

inline const EventHandle nullEvent{};

template <typename T, typename Fn>
auto transform(const std::span<T>& span, Fn fn)
{
    using ValueType = std::decay_t<std::invoke_result_t<Fn, T&>>;
    std::vector<ValueType> ret(span.size());
    std::ranges::transform(span, begin(ret), std::move(fn));
    return ret;
}

template <typename T, size_t Extent, typename Fn>
auto transform(const std::span<T, Extent>& span, Fn fn)
{
    using ValueType = std::decay_t<std::invoke_result_t<Fn, T&>>;
    std::array<ValueType, Extent> ret;
    std::ranges::transform(span, begin(ret), std::move(fn));
    return ret;
}

template <typename SmartHandle, size_t Extent>
auto toRawHandles(const std::span<SmartHandle, Extent>& smartHandles)
{
    // Argument smartHandles can be a range of elements of type std::reference_wrapper<Unwrapped>.
    // This infers the Unwrapped type inside there if any.
    using Unwrapped = std::unwrap_ref_decay_t<SmartHandle>;

    return transform(smartHandles, [](const Unwrapped& sh) { return sh.get(); });
}

inline auto toRawHandles(const auto& smartHandles)
{
    return toRawHandles(std::span(smartHandles));
}

inline Expected<void>
Init(ze_init_flags_t flags = 0, const std::source_location& location = std::source_location::current())
{
    return checked<zeInit>(flags, "zeInit", location);
}

inline Expected<std::vector<DriverHandle>>
DriverGet(const std::source_location& location = std::source_location::current())
{
    uint32_t count = 0;
    RETURN_IF_ERROR(checked<zeDriverGet>(&count, nullptr, "zeDriverGet (get count)", location));

    std::vector<DriverHandle> drivers(count);
    RETURN_IF_ERROR(checked<zeDriverGet>(&count, drivers.data(), "zeDriverGet", location));

    return drivers;
}

inline Expected<std::vector<DeviceHandle>>
DeviceGet(_ze_driver_handle_t& driver, const std::source_location& location = std::source_location::current())
{
    uint32_t count = 0;
    RETURN_IF_ERROR(checked<zeDeviceGet>(&driver, &count, nullptr, "zeDeviceGet (get count)", location));

    std::vector<DeviceHandle> devices(count);
    RETURN_IF_ERROR(checked<zeDeviceGet>(&driver, &count, devices.data(), "zeDeviceGet", location));

    return devices;
}

inline Expected<ze_device_properties_t>
DeviceGetProperties(_ze_device_handle_t& device, const std::source_location& location = std::source_location::current())
{
    ze_device_properties_t properties{};
    RETURN_IF_ERROR(checked<zeDeviceGetProperties>(&device, &properties, "zeDeviceGetProperties", location));
    return properties;
}

inline Expected<std::vector<DeviceHandle>>
DeviceGetSubDevices(_ze_device_handle_t& device, const std::source_location& location = std::source_location::current())
{
    uint32_t count = 0;
    RETURN_IF_ERROR(checked<zeDeviceGetSubDevices>(&device, &count, nullptr, "zeDeviceGetSubDevices (get count)", location));

    std::vector<ze_device_handle_t> subDevices(count);
    RETURN_IF_ERROR(checked<zeDeviceGetSubDevices>(&device, &count, subDevices.data(), "zeDeviceGetSubDevices", location));

    return subDevices;
}

inline Expected<std::vector<ze_command_queue_group_properties_t>>
DeviceGetCommandQueueGroupProperties(_ze_device_handle_t& device,
                                     const std::source_location& location = std::source_location::current())
{
    uint32_t count = 0;
    RETURN_IF_ERROR(checked<zeDeviceGetCommandQueueGroupProperties>(
        &device, &count, nullptr, "zeDeviceGetCommandQueueGroupProperties (get count)", location));

    std::vector<ze_command_queue_group_properties_t> ret(count);
    RETURN_IF_ERROR(checked<zeDeviceGetCommandQueueGroupProperties>(
        &device, &count, ret.data(), "zeDeviceGetCommandQueueGroupProperties", location));

    return ret;
}

struct ContextDesc
{
    ze_context_flags_t flags;
    const void* pNext;

    operator ze_context_desc_t() const
    {
        return {
            .stype = ZE_STRUCTURE_TYPE_CONTEXT_DESC,
            .pNext = pNext,
            .flags = flags,
        };
    }
};

inline Expected<ContextHandle>
ContextCreate(_ze_driver_handle_t& driver, const ContextDesc& desc = {}, const std::span<const DeviceHandle>& devices = {},
              const std::source_location& location = std::source_location::current())
{
    ze_context_handle_t context{};
    const ze_context_desc_t taggedDesc = desc;
    const auto numDevices = static_cast<uint32_t>(devices.size());
    const auto deviceHandles = const_cast<ze_device_handle_t*>(devices.data());

    RETURN_IF_ERROR(checked<zeContextCreateEx>(&driver, &taggedDesc, numDevices, deviceHandles, &context, "zeContextCreateEx", location));

    return ContextHandle(context);
}

template <uint32_t N>
auto ContextCreate(_ze_driver_handle_t& driver, const ContextDesc& desc, const DeviceHandle(& devices)[N],
                   const std::source_location& location = std::source_location::current())
{
    return ContextCreate(driver, desc, std::span(devices), location);
}

struct CommandQueueDesc
{
    uint32_t ordinal;
    uint32_t index;
    ze_command_queue_flags_t flags;
    ze_command_queue_mode_t mode;
    ze_command_queue_priority_t priority;
    const void* pNext;

    operator ze_command_queue_desc_t() const
    {
        return {
            .stype = ZE_STRUCTURE_TYPE_COMMAND_QUEUE_DESC,
            .pNext = pNext,
            .ordinal = ordinal,
            .index = index,
            .flags = flags,
            .mode = mode,
            .priority = priority,
        };
    }
};

inline Expected<CommandQueueHandle>
CommandQueueCreate(_ze_context_handle_t& context, _ze_device_handle_t& device, const CommandQueueDesc& desc,
                   const std::source_location& location = std::source_location::current())
{
    ze_command_queue_handle_t commandQueue{};
    const ze_command_queue_desc_t taggedDesc = desc;

    RETURN_IF_ERROR(checked<zeCommandQueueCreate>(&context, &device, &taggedDesc, &commandQueue, "zeCommandQueueCreate", location));

    return CommandQueueHandle(commandQueue);
}

inline Expected<void>
CommandQueueExecuteCommandLists(_ze_command_queue_handle_t& commandQueue, const std::span<const ze_command_list_handle_t>& commandLists,
                                const std::source_location& location = std::source_location::current())
{
    return checked<zeCommandQueueExecuteCommandLists>(
        &commandQueue,
        static_cast<uint32_t>(commandLists.size()),
        const_cast<ze_command_list_handle_t*>(commandLists.data()),
        nullptr,
        "zeCommandQueueExecuteCommandLists",
        location
    );
}

// CommandLists should be a container of CommandListHandle or references to CommandListHandle.
template <typename CommandLists>
requires (!std::convertible_to<CommandLists, std::span<const ze_command_list_handle_t>>)
auto CommandQueueExecuteCommandLists(_ze_command_queue_handle_t& commandQueue, const CommandLists& commandLists,
                                     const std::source_location& location = std::source_location::current())
{
    return CommandQueueExecuteCommandLists(commandQueue, toRawHandles(commandLists), location);
}

template <uint32_t N>
auto CommandQueueExecuteCommandLists(_ze_command_queue_handle_t& commandQueue,
                                     const SmartInitializerList<CommandListHandle, N>& commandLists,
                                     const std::source_location& location = std::source_location::current())
{
    return CommandQueueExecuteCommandLists(commandQueue, toRawHandles(commandLists), location);
}

inline Expected<void>
CommandQueueSynchronize(_ze_command_queue_handle_t& commandQueue, const uint64_t timeout = UINT64_MAX,
                        const std::source_location& location = std::source_location::current())
{
    return checked<zeCommandQueueSynchronize>(&commandQueue, timeout, "zeCommandQueueSynchronize", location);
}

struct CommandListDesc
{
    uint32_t commandQueueGroupOrdinal;
    ze_command_list_flags_t flags;
    const void* pNext;

    operator ze_command_list_desc_t() const
    {
        return {
            .stype = ZE_STRUCTURE_TYPE_COMMAND_LIST_DESC,
            .pNext = pNext,
            .commandQueueGroupOrdinal = commandQueueGroupOrdinal,
            .flags = flags,
        };
    }
};

inline Expected<CommandListHandle>
CommandListCreate(_ze_context_handle_t& context, _ze_device_handle_t& device, const CommandListDesc& desc = {},
                  const std::source_location& location = std::source_location::current())
{
    ze_command_list_handle_t commandList{};
    const ze_command_list_desc_t taggedDesc = desc;

    RETURN_IF_ERROR(checked<zeCommandListCreate>(&context, &device, &taggedDesc, &commandList, "zeCommandListCreate", location));

    return CommandListHandle(commandList);
}

inline Expected<void>
CommandListClose(_ze_command_list_handle_t& commandList,
                 const std::source_location& location = std::source_location::current())
{
    return checked<zeCommandListClose>(&commandList, "zeCommandListClose", location);
}

inline Expected<void>
CommandListReset(_ze_command_list_handle_t& commandList,
                 const std::source_location& location = std::source_location::current())
{
    return checked<zeCommandListReset>(&commandList, "zeCommandListReset", location);
}

struct HostMemAllocDesc
{
    ze_host_mem_alloc_flags_t flags;
    const void* pNext;

    operator ze_host_mem_alloc_desc_t() const
    {
        return {
            .stype = ZE_STRUCTURE_TYPE_HOST_MEM_ALLOC_DESC,
            .pNext = pNext,
            .flags = flags,
        };
    }
};

struct DeviceMemAllocDesc
{
    ze_device_mem_alloc_flags_t flags;
    uint32_t ordinal;
    const void* pNext;

    operator ze_device_mem_alloc_desc_t() const
    {
        return {
            .stype = ZE_STRUCTURE_TYPE_DEVICE_MEM_ALLOC_DESC,
            .pNext = pNext,
            .flags = flags,
            .ordinal = ordinal,
        };
    }
};

template <typename T = std::byte> requires (!std::same_as<T, void>)
Expected<MemHandle<T>>
MemAllocShared(_ze_context_handle_t& context,
               const DeviceMemAllocDesc& deviceDesc,
               const HostMemAllocDesc& hostDesc,
               const size_t size,
               const size_t alignment,
               _ze_device_handle_t& device,
               const std::source_location& location = std::source_location::current())
{
    void* ptr;
    const ze_device_mem_alloc_desc_t taggedDeviceDesc = deviceDesc;
    const ze_host_mem_alloc_desc_t taggedHostDesc = hostDesc;

    RETURN_IF_ERROR(checked<zeMemAllocShared>(
        &context,
        &taggedDeviceDesc,
        &taggedHostDesc,
        size * sizeof(T),
        std::max(alignment, alignof(T)),
        &device,
        &ptr,
        "zeMemAllocShared",
        location
    ));

    return MemHandle<T>{ context, { static_cast<T*>(ptr), size } };
}

template <typename T = std::byte> requires (!std::same_as<T, void>)
Expected<MemHandle<void>>
MemAllocDevice(_ze_context_handle_t& context,
               const DeviceMemAllocDesc& deviceDesc,
               const size_t size,
               const size_t alignment,
               _ze_device_handle_t& device,
               const std::source_location& location = std::source_location::current())
{
    void* ptr;
    const ze_device_mem_alloc_desc_t taggedDeviceDesc = deviceDesc;

    RETURN_IF_ERROR(checked<zeMemAllocDevice>(
        &context,
        &taggedDeviceDesc,
        size * sizeof(T),
        std::max(alignment, alignof(T)),
        &device,
        &ptr,
        "zeMemAllocDevice",
        location
    ));

    return MemHandle<void>{ context, ptr, size * sizeof(T) };
}

template <typename T = std::byte> requires (!std::same_as<T, void>)
Expected<MemHandle<T>>
MemAllocHost(_ze_context_handle_t& context,
             const HostMemAllocDesc& hostDesc,
             const size_t size,
             const size_t alignment,
             const std::source_location& location = std::source_location::current())
{
    void* ptr;
    const ze_host_mem_alloc_desc_t taggedHostDesc = hostDesc;

    RETURN_IF_ERROR(checked<zeMemAllocHost>(
        &context,
        &taggedHostDesc,
        size * sizeof(T),
        std::max(alignment, alignof(T)),
        &ptr,
        "zeMemAllocHost",
        location
    ));

    return MemHandle<T>{ context, { static_cast<T*>(ptr), size } };
}

class BufferSpan
{
public:
    BufferSpan() = default;

    BufferSpan(void* const ptr, const size_t size)
        : m_ptr(ptr)
        , m_size(size)
    {}

    template <typename T>
    BufferSpan(const MemHandle<T>& mem)
        : BufferSpan(mem.get(), mem.sizeInBytes())
    {}

    void* ptr() const { return m_ptr; }
    size_t size() const { return m_size; }

    BufferSpan subspan(const size_t offset, const size_t size = std::dynamic_extent) const
    {
        const size_t validOffset = std::min(offset, m_size);

        return {
            std::bit_cast<void*>(std::bit_cast<uintptr_t>(m_ptr) + validOffset),
            std::min(size, m_size - validOffset),
        };
    }

private:
    void* m_ptr = nullptr;
    size_t m_size = 0;
};

class ConstBufferSpan : BufferSpan
{
public:
    using BufferSpan::BufferSpan;

    ConstBufferSpan(const BufferSpan other)
        : BufferSpan(other)
    {}

    const void* ptr() const { return BufferSpan::ptr(); }
    size_t size() const { return BufferSpan::size(); }

    ConstBufferSpan subspan(const size_t offset, const size_t size = std::dynamic_extent) const
    {
        return BufferSpan::subspan(offset, size);
    }
};

inline Expected<void>
CommandListAppendMemoryCopy(_ze_command_list_handle_t& commandList,
                            const BufferSpan& dst,
                            const ConstBufferSpan& src,
                            const ze_event_handle_t signalEvent = nullptr,
                            const std::span<const ze_event_handle_t>& waitEvents = {},
                            const std::source_location& location = std::source_location::current())
{
    if (dst.size() < src.size()) {
        const auto dstSize = std::to_string(dst.size());
        const auto srcSize = std::to_string(src.size());
        auto exceptionMsg = "dst(" + dstSize + ") must be larger or equal than src(" + srcSize + ") in size";

        return Error{
            .errorCode = ZE_RESULT_ERROR_INVALID_ARGUMENT,
            .message = "dst(" + dstSize + ") must be larger or equal than src(" + srcSize + ") in size",
            .location = location,
        };
    }

    return checked<zeCommandListAppendMemoryCopy>(
        &commandList,
        dst.ptr(),
        src.ptr(),
        src.size(),
        signalEvent,
        static_cast<uint32_t>(waitEvents.size()),
        const_cast<ze_event_handle_t*>(waitEvents.data()),
        "zeCommandListAppendMemoryCopy",
        location
    );
}

// Events should be a container of EventHandle or references to EventHandle.
template <typename Events = std::span<EventHandle, 0>>
requires (!std::convertible_to<Events, std::span<const ze_event_handle_t>>)
auto CommandListAppendMemoryCopy(_ze_command_list_handle_t& commandList,
                                 const BufferSpan& dst,
                                 const ConstBufferSpan& src,
                                 const EventHandle& signalEvent,
                                 const Events& waitEvents = {},
                                 const std::source_location& location = std::source_location::current())
{
    return CommandListAppendMemoryCopy(commandList, dst, src, signalEvent.get(), toRawHandles(waitEvents), location);
}

template <uint32_t N>
auto CommandListAppendMemoryCopy(_ze_command_list_handle_t& commandList,
                                 const BufferSpan& dst,
                                 const ConstBufferSpan& src,
                                 const EventHandle& signalEvent,
                                 const SmartInitializerList<EventHandle, N>& waitEvents,
                                 const std::source_location& location = std::source_location::current())
{
    return CommandListAppendMemoryCopy(commandList, dst, src, signalEvent.get(), toRawHandles(waitEvents), location);
}

struct ModuleDesc
{
    ze_module_format_t format;
    std::span<const char> inputModule;
    const char* pBuildFlags;
    const ze_module_constants_t* pConstants;
    const void* pNext;

    operator ze_module_desc_t() const
    {
        return {
            .stype = ZE_STRUCTURE_TYPE_MODULE_DESC,
            .pNext = pNext,
            .format = format,
            .inputSize = inputModule.size(),
            .pInputModule = static_cast<const uint8_t*>(static_cast<const void*>(inputModule.data())),
            .pBuildFlags = pBuildFlags,
            .pConstants = pConstants,
        };
    }
};

// Used to better inform of the error if a ModuleCreate fails.
inline Expected<std::string>
ModuleBuildLogGetString(_ze_module_build_log_handle_t& moduleBuildLog,
                        const std::source_location& location = std::source_location::current())
{
    size_t size = 0;
    RETURN_IF_ERROR(checked<zeModuleBuildLogGetString>(&moduleBuildLog, &size, nullptr, "zeModuleBuildLogGetString (get size)", location));

    std::string ret(size, '\0');
    RETURN_IF_ERROR(checked<zeModuleBuildLogGetString>(&moduleBuildLog, &size, ret.data(), "zeModuleBuildLogGetString", location));

    return ret;
}

inline Expected<ModuleHandle>
ModuleCreate(_ze_context_handle_t& context, _ze_device_handle_t& device, const ModuleDesc& desc,
             const std::source_location& location = std::source_location::current())
{
    ze_module_handle_t module{};
    ze_module_build_log_handle_t buildLog{};
    const ze_module_desc_t taggedDesc = desc;

    const auto success = CheckedHelper<zeModuleCreate>{}(&context, &device, &taggedDesc, &module, &buildLog, {}, {});

    const ModuleBuildLogHandle buildLogHandle(buildLog);

    if (!success) {
        auto buildLogString = ModuleBuildLogGetString(*buildLog);

        return Error{
            .errorCode = success.error().errorCode,
            .message = "zeModuleCreate failed with build log:\n" + (buildLogString ? buildLogString.value() : std::string{}),
            .location = location,
        };
    }

    return ModuleHandle(module);
}

struct KernelDesc
{
    ze_kernel_flags_t flags;
    const char* pKernelName;
    const void* pNext;

    operator ze_kernel_desc_t() const
    {
        return {
            .stype = ZE_STRUCTURE_TYPE_KERNEL_DESC,
            .pNext = pNext,
            .flags = flags,
            .pKernelName = pKernelName,
        };
    }
};

inline Expected<KernelHandle>
KernelCreate(_ze_module_handle_t& module, const KernelDesc& desc,
             const std::source_location& location = std::source_location::current())
{
    ze_kernel_handle_t kernel{};
    const ze_kernel_desc_t taggedDesc = desc;

    RETURN_IF_ERROR(checked<zeKernelCreate>(&module, &taggedDesc, &kernel, "zeKernelCreate", location));

    return KernelHandle(kernel);
}
class KernelArg
{
public:
    template <typename T> requires (std::is_arithmetic_v<T>)
    KernelArg(const T value)
    {
        static_assert(sizeof(value) <= sizeof(m_bytes));
        std::ranges::copy(as_bytes(std::span(&value, 1)), begin(m_bytes));
    }

    // This should only be used with a BufferSpan created from a device mem handle,
    // which is not enforced at compile time.
    KernelArg(const BufferSpan deviceMem)
        : KernelArg(deviceMem.ptr())
    {}

    KernelArg(const MemHandle<void>& deviceMem)
        : KernelArg(BufferSpan(deviceMem))
    {}

    // Only device memory (MemHandle<void>) is allowed as kernel arg.
    template <typename T>
    KernelArg(const MemHandle<T>& hostMem) = delete;

private:
    KernelArg(void* const value)
        : KernelArg(std::bit_cast<uintptr_t>(value))
    {}

    std::array<std::byte, sizeof(uint64_t)> m_bytes{};
};

inline Expected<void>
KernelSetArgumentValue(_ze_kernel_handle_t& kernel, const uint32_t argIndex, const KernelArg argValue,
                       const std::source_location& location = std::source_location::current())
{
    return checked<zeKernelSetArgumentValue>(&kernel, argIndex, sizeof(argValue), &argValue, "zeKernelSetArgumentValue", location);
}

inline Expected<void>
CommandListAppendLaunchKernel(_ze_command_list_handle_t& commandList,
                              _ze_kernel_handle_t& kernel,
                              const ze_group_count_t& launchFuncArgs = {},
                              const ze_event_handle_t signalEvent = nullptr,
                              const std::span<const ze_event_handle_t>& waitEvents = {},
                              const std::source_location& location = std::source_location::current())
{
    return checked<zeCommandListAppendLaunchKernel>(
        &commandList,
        &kernel,
        &launchFuncArgs,
        signalEvent,
        static_cast<uint32_t>(waitEvents.size()),
        const_cast<ze_event_handle_t*>(waitEvents.data()),
        "zeCommandListAppendLaunchKernel",
        location
    );
}

// Events should be a container of EventHandle or references to EventHandle.
template <typename Events = std::span<EventHandle, 0>>
requires (!std::convertible_to<Events, std::span<const ze_event_handle_t>>)
auto CommandListAppendLaunchKernel(_ze_command_list_handle_t& commandList,
                                   _ze_kernel_handle_t& kernel,
                                   const ze_group_count_t& launchFuncArgs,
                                   const EventHandle& signalEvent,
                                   const Events& waitEvents = {},
                                   const std::source_location& location = std::source_location::current())
{
    return CommandListAppendLaunchKernel(commandList, kernel, launchFuncArgs, signalEvent.get(), toRawHandles(waitEvents), location);
}

template <uint32_t N>
auto CommandListAppendLaunchKernel(_ze_command_list_handle_t& commandList,
                                   _ze_kernel_handle_t& kernel,
                                   const ze_group_count_t& launchFuncArgs,
                                   const EventHandle& signalEvent,
                                   const SmartInitializerList<EventHandle, N>& waitEvents,
                                   const std::source_location& location = std::source_location::current())
{
    return CommandListAppendLaunchKernel(commandList, kernel, launchFuncArgs, signalEvent.get(), toRawHandles(waitEvents), location);
}

struct EventPoolDesc
{
    ze_event_pool_flags_t flags;
    uint32_t count;
    const void* pNext;

    operator ze_event_pool_desc_t() const
    {
        return {
            .stype = ZE_STRUCTURE_TYPE_EVENT_POOL_DESC,
            .pNext = pNext,
            .flags = flags,
            .count = count,
        };
    }
};

inline Expected<EventPoolHandle>
EventPoolCreate(_ze_context_handle_t& context, const EventPoolDesc& desc, const std::span<const DeviceHandle>& devices = {},
                const std::source_location& location = std::source_location::current())
{
    ze_event_pool_handle_t eventPool{};
    const ze_event_pool_desc_t taggedDesc = desc;
    const auto numDevices = static_cast<uint32_t>(devices.size());
    const auto deviceHandles = const_cast<ze_device_handle_t*>(devices.data());

    RETURN_IF_ERROR(checked<zeEventPoolCreate>(
        &context, &taggedDesc, numDevices, deviceHandles, &eventPool, "zeEventPoolCreate", location));

    return EventPoolHandle(eventPool);
}

template <uint32_t N>
auto EventPoolCreate(_ze_context_handle_t& context, const EventPoolDesc& desc, const DeviceHandle(& devices)[N],
                     const std::source_location& location = std::source_location::current())
{
    return EventPoolCreate(context, desc, std::span(devices), location);
}

struct EventDesc
{
    uint32_t index;
    ze_event_scope_flags_t signal;
    ze_event_scope_flags_t wait;
    const void* pNext;

    operator ze_event_desc_t() const
    {
        return {
            .stype = ZE_STRUCTURE_TYPE_EVENT_DESC,
            .pNext = pNext,
            .index = index,
            .signal = signal,
            .wait = wait,
        };
    }
};

inline Expected<EventHandle>
EventCreate(_ze_event_pool_handle_t& eventPool, const EventDesc& desc,
            const std::source_location& location = std::source_location::current())
{
    ze_event_handle_t event{};
    const ze_event_desc_t taggedDesc = desc;

    RETURN_IF_ERROR(checked<zeEventCreate>(&eventPool, &taggedDesc, &event, "zeEventCreate", location));

    return EventHandle(event);
}

inline Expected<void>
CommandListAppendSignalEvent(_ze_command_list_handle_t& commandList, _ze_event_handle_t& event,
                             const std::source_location& location = std::source_location::current())
{
    return checked<zeCommandListAppendSignalEvent>(&commandList, &event, "zeCommandListAppendSignalEvent", location);
}

inline Expected<void>
CommandListAppendEventReset(_ze_command_list_handle_t& commandList, _ze_event_handle_t& event,
                            const std::source_location& location = std::source_location::current())
{
    return checked<zeCommandListAppendEventReset>(&commandList, &event, "zeCommandListAppendEventReset", location);
}

inline Expected<void>
CommandListAppendWaitOnEvents(_ze_command_list_handle_t& commandList, const std::span<const ze_event_handle_t>& waitEvents,
                              const std::source_location& location = std::source_location::current())
{
    return checked<zeCommandListAppendWaitOnEvents>(
        &commandList,
        static_cast<uint32_t>(waitEvents.size()),
        const_cast<ze_event_handle_t*>(waitEvents.data()),
        "zeCommandListAppendWaitOnEvents",
        location
    );
}

// Events should be a container of EventHandle or references to EventHandle.
template <typename Events>
requires (!std::convertible_to<Events, std::span<const ze_event_handle_t>>)
auto CommandListAppendWaitOnEvents(_ze_command_list_handle_t& commandList, const Events& waitEvents,
                                   const std::source_location& location = std::source_location::current())
{
    return CommandListAppendWaitOnEvents(commandList, toRawHandles(waitEvents), location);
}

template <uint32_t N>
auto CommandListAppendWaitOnEvents(_ze_command_list_handle_t& commandList, const SmartInitializerList<EventHandle, N>& waitEvents,
                                   const std::source_location& location = std::source_location::current())
{
    return CommandListAppendWaitOnEvents(commandList, toRawHandles(waitEvents), location);
}

} // namespace axelera::ze
