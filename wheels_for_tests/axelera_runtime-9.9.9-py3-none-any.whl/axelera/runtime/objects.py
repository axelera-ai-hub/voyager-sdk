# Copyright Axelera AI, 2024
from __future__ import annotations

import builtins
import contextlib
import ctypes as _c
import dataclasses
import enum
import logging
import typing
import weakref
from pathlib import Path

import numpy as np

from . import axruntime as axr

TRACE = 5
_axr_to_logging = {
    axr.LogLevel.TRACE: logging.INFO,  # TRACE,
    axr.LogLevel.TRACE: logging.INFO,  # TRACE,
    axr.LogLevel.DEBUG: logging.DEBUG,
    axr.LogLevel.INFO: logging.INFO,
    axr.LogLevel.FIXME: logging.WARNING,
    axr.LogLevel.WARNING: logging.WARNING,
    axr.LogLevel.ERROR: logging.ERROR,
}


class _LogWithTrace(logging.Logger):
    def trace(self, msg, *args, **kwargs):
        if self.isEnabledFor(TRACE):
            self._log(TRACE, msg, args, **kwargs)


Error = Exception
# For backwards compatability


def _getLogger(name):
    oldClass = logging.getLoggerClass()
    # redefine LogWithTrace but with the current logger class as base
    cls = type("LogWithTrace", (oldClass,), dict(_LogWithTrace.__dict__))
    logging.addLevelName(TRACE, "TRACE")
    try:
        logging.setLoggerClass(cls)
        return logging.getLogger(name)
    finally:
        logging.setLoggerClass(oldClass)


LOG = _getLogger("axelera.runtime")

_exceptions = {}


def _create_exceptions():
    for name in dir(axr.Result):
        if name.isupper() and name != "SUCCESS":
            val = getattr(axr.Result, name)
            camel = name.replace("_", " ").title().replace(" ", "")
            if camel == 'NotImplemented':
                camel = 'NotImplementedError'
            try:
                # Use pythons builtin exceptions like ValueError or RuntimeError if they exist
                exc = getattr(builtins, camel)
                assert type(exc) is type, f"{camel} clashes with a non-type"
                assert issubclass(exc, Exception), f"{camel} clashes with a non-exception-type"
            except AttributeError:
                exc = type(camel, (RuntimeError,), {})
            globals()[camel] = _exceptions[val] = exc


_create_exceptions()


def _raise_error(ctx: Context, err_no=None):
    pctx = _c.cast(ctx._obj, axr.pObject)
    err_no = axr.last_error(pctx).value if err_no is None else err_no
    err = axr.error_string(err_no).decode("utf-8")
    msg = axr.last_error_string(pctx).decode("utf-8")
    exc = _exceptions.get(err_no, _exceptions[axr.Result.UNKNOWN_ERROR])
    raise exc(f"{err}: {msg}")


def _maybe_raise_error(ctx: Context, err_no: int | None = None):
    if err_no is None:
        pctx = _c.cast(ctx._obj, axr.pObject)
        err_no = axr.last_error(pctx).value
    if err_no != axr.Result.SUCCESS:
        _raise_error(ctx, err_no)


if typing.TYPE_CHECKING:
    pAnyObject = typing.Union[
        axr.pObject,
        _c._Pointer[axr.Context],
        _c._Pointer[axr.Connection],
        _c._Pointer[axr.Model],
        _c._Pointer[axr.ModelInstance],
        _c._Pointer[axr.Properties],
    ]


@axr.logger_fn
def _log(obj: axr.pObject, level, msg):
    logging_level = _axr_to_logging.get(level.value, logging.INFO)
    LOG.log(logging_level, "%s", msg.decode("utf-8", errors="backslashreplace"))


class Object:
    '''Abstract base class for all objects in the runtime.

    All objects created by the runtime are owned by the `Context` that created
    them.  When the Context is released, all objects created by it are also
    released.

    '''

    def __init__(self, obj: pAnyObject, context: Context):
        ''':meta private:'''
        self._obj = obj
        LOG.debug(f"Created {self!r}")
        if self is not context:
            context._children.add(self)
        self.context = context
        '''Reference to the :class:`Context` that owns this object.'''

    def __repr__(self):
        return f"{self.__class__.__name__}(0x{_c.addressof(self._obj.contents):x})"

    def release(self):
        if getattr(self, '_obj', None):
            LOG.debug(f"Releasing {self!r}")
            axr.destroy(_c.cast(self._obj, axr.pObject))
            self._obj = None

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.release()


class BoardType(enum.Enum):
    alpha_pcie = 0
    alpha_m2 = 1
    pcie = 2
    m2 = 3
    devboard = 4
    sbc = 5
    unknown = 6


class DeviceInfo:
    def __init__(self, info: axr.DeviceInfo):
        self._info = info

    def __repr__(self):
        return (
            f"DeviceInfo(name={self.name}, subdevice_count={self.subdevice_count}, "
            f"max_memory={self.max_memory}, in_use={self.in_use}, in_use_by={self.in_use_by}, "
            f"board_type={self.board_type}, firmware_version={self.firmware_version}, "
            f"board_revision={self.board_revision},)"
            f"flashed_firmware_version={self.flashed_firmware_version},"
            f"board_controller_firmware_version={self.board_controller_firmware_version},"
            f"board_controller_board_type={self.board_controller_board_type})"
        )

    @property
    def name(self) -> str:
        '''The name of the device.

        For example 'metis-0:3:0'.
        '''
        return self._info.name.decode("utf-8")

    @property
    def subdevice_count(self) -> int:
        '''The number of subdevices on the device, for metis this is 4.'''
        return self._info.subdevice_count

    @property
    def max_memory(self) -> int:
        '''The maximum memory available on the device.

        Note in the current implementation this field is not populated and will always be 0.
        '''
        return self._info.max_memory

    @property
    def in_use(self) -> bool:
        '''The number of subdevices in use.

        Note in the current implementation this field is not populated and will always be 0.
        '''
        return self._info.in_use != 0

    @property
    def in_use_by(self) -> str:
        '''The username and process id of the user(s) using the device, comma separated.

        Note in the current implementation this field is not populated and will always be 0.
        '''
        return self._info.in_use_by.decode("utf-8")

    @property
    def board_type(self) -> BoardType:
        '''The board type of the device.'''
        return BoardType(self._info.board_type)

    @property
    def firmware_version(self) -> str:
        '''The firmware version of the device, for example v1.1.0-rc5-2-g1234567.'''
        return self._info.firmware_version.decode("utf-8")

    @property
    def board_revision(self) -> int:
        '''The board revision of the device.'''
        return self._info.board_revision

    @property
    def flashed_firmware_version(self) -> str:
        '''The version of the firmware stored in flash memory of the device.'''
        return self._info.flashed_firmware_version.decode('utf-8')

    @property
    def board_controller_firmware_version(self) -> str:
        '''The board controller firmware version on the device.'''
        return self._info.board_controller_firmware_version.decode('utf-8')

    @property
    def board_controller_board_type(self) -> str:
        '''The board controller board type.'''
        return self._info.board_controller_board_type.decode('utf-8')


class Context(Object):
    '''The Context object is the root object of the runtime.

    A Context is used to create and manage all other objects in the runtime.
    Normally you would create it in a with statement, like this ::

        with axr.Context() as context:
            devices = context.list_devices()

    Alternatively, you can call `release()` to release the context and all its
    children.
    '''

    def __init__(self):
        super().__init__(axr.create_context(), self)
        self._children = weakref.WeakSet()
        for axr_level, log_level in _axr_to_logging.items():
            if LOG.isEnabledFor(log_level):
                axr.set_logger(self._obj, axr_level, _log, None)
                break

    def release(self):
        '''Release the context and all its children.

        This function is called automatically when Context is used as a context
        manager.
        '''
        if getattr(self, '_obj', None):
            # release all children first
            for child in list(self._children):
                if child:
                    child.release()
            super().release()

    def list_devices(self) -> list[DeviceInfo]:
        '''List all devices on the system.'''
        devices = _c.POINTER(axr.DeviceInfo)()
        num = axr.list_devices(self._obj, _c.byref(devices))
        if num == 0:
            _maybe_raise_error(self)
        return [DeviceInfo(axr.DeviceInfo.from_buffer_copy(devices[i])) for i in range(num)]

    def device_connect(
        self, device: axr.DeviceInfo | None = None, num_sub_devices: int = 1, **kwargs
    ) -> Connection:
        '''Connect to one or more sub-devices.

        This reserves the sub-devices so that other processes cannot use them.

        The returned Connection object is used to load models and run them on the
        sub-devices.


        ======================== ========== ===========================================
        Property                 Default    Description
        ======================== ========== ===========================================
        device_firmware_check             1 If 1, check the firmware version of the
                                            device and reload if necessary.
        ======================== ========== ===========================================

        '''
        with _kwargs(self, **kwargs) as props:
            d = device and _c.byref(device._info)
            conn = axr.device_connect(self._obj, d, num_sub_devices, props)
        if not conn:
            _raise_error(self)
        return Connection(conn, self)

    def load_model(self, path: str | Path) -> Model:
        '''Load a model from a file.

        The returned model can be loaded onto multiple Connection objects using
        `Connection.load_model_instance()`.
        '''
        model = axr.load_model(self._obj, str(path).encode("utf-8"))
        if not model:
            _raise_error(self)
        return Model(model, self)

    def __del__(self):
        self.release()

    def _pending_as_bool(self, res):
        if res.value != axr.Result.SUCCESS and res.value != axr.Result.PENDING:
            _raise_error(self, res.value)
        return res.value != axr.Result.PENDING

    def configure_device(self, device: DeviceInfo, **kwargs) -> bool:
        '''Returns True if the configuration setting is complete, False if it is pending.

        For example to change a configuration on two devices::

            res0 = context.configure_device(device0, clock_profile=1000)
            res1 = context.configure_device(device1, clock_profile=1000)
            while not res0 or not res1:
                time.sleep(0.05)
                res0 = context.device_ready(device0)
                res1 = context.device_ready(device1)

        Valid properties are :

        ======================== ========== =============================================================
        Property                 Default    Description
        ======================== ========== =============================================================
        reboot                            0 If 1, reboot the device before applying the configuration.
        clock_profile                   800 Device clock profile in MHz
        clock_profile_core_0-3          800 Per-core clock profile in MHz
        mvm_utilisation_core_0-3        100 Per-core MVM utilisation as percentage
        device_firmware                   0 1 to check and reload the firwmare if
                                            necessary.  'force' to force a reload.
        power_limit                     0.0 Power limit in watts before throttling is applied, or 0 to disable throttling.
        ======================== ========== =============================================================
        '''
        with _kwargs(self, **kwargs) as props:
            res = axr.configure_device(self._obj, _c.byref(device._info), props)
        return self._pending_as_bool(res)

    def device_ready(self, device: DeviceInfo) -> bool:
        '''Returns True if the configuration setting is complete, False if is pending.'''
        res = axr.device_ready(self._obj, _c.byref(device._info))
        if res.value != axr.Result.SUCCESS and res.value != axr.Result.PENDING:
            _raise_error(self, res.value)
        return res.value != axr.Result.PENDING

    def read_device_configuration(self, device: DeviceInfo) -> dict[str, str]:
        '''Read all available configiration properties of the device.'''
        props = axr.read_device_configuration(self._obj, _c.byref(device._info))
        if not props:
            _raise_error(self)
        res = {}
        for name in axr.list_properties(props).decode("utf-8").split(';'):
            res[name] = axr.get_property(props, name.encode('utf8')).decode("utf-8")
        return res

    def device_set_log_level(self, device: DeviceInfo, source: str, config: str) -> None:
        '''Set device log level for a given source.

        Parameters:
        - device: target device info
        - source: log source identifier (e.g., module name)
        - config: log level configuration string
        '''
        res = axr.device_set_log_level(
            self._obj,
            _c.byref(device._info),
            source.encode('utf-8'),
            config.encode('utf-8'),
        )
        if res.value != axr.Result.SUCCESS:
            _raise_error(self, res.value)

    def device_peek_log(self, device: DeviceInfo, source: str) -> str | None:
        '''Return the latest device log message for a source.

        Parameters:
        - device: target device info
        - source: log source identifier

            Returns the log text. Raises on error.
        '''
        s = axr.device_peek_log(self._obj, _c.byref(device._info), source.encode('utf-8'))
        if s is None:
            _raise_error(self)
        return s.decode('utf-8')

    def device_get_log_stats(self, device: DeviceInfo, source: str) -> str | None:
        '''Return device log stats (hexdump/text) for a source.

        Parameters:
        - device: target device info
        - source: log source identifier

        Returns the stats text. Raises on error.
        '''
        s = axr.device_get_log_stats(self._obj, _c.byref(device._info), source.encode('utf-8'))
        if s is None:
            _raise_error(self)
        return s.decode('utf-8')

    def device_clear_log(self, device: DeviceInfo, source: str) -> bool:
        '''Clear device logs for a given source.

        Parameters:
        - device: target device info
        - source: log source identifier
        '''
        res = axr.device_clear_log(self._obj, _c.byref(device._info), source.encode('utf-8'))
        if res.value != axr.Result.SUCCESS:
            _raise_error(self, res.value)

    def device_start_logger(
        self,
        device: DeviceInfo,
        sources: typing.Iterable[str],
        logger: typing.Callable[[int, str, str], None],
        clear_existing_logs: bool = False,
    ) -> None:
        '''Start device logging and register a Python callback.

        The device logger is stopped when the Context is released, or when
        `device_stop_logger()` is called.

        Parameters:
        - device: target device info
        - sources: iterable of log source identifiers
        - logger: callback receiving (level:int, source:str, msg:str|bytes)
        - clear_existing_logs: whether to clear existing logs before starting

        The msg is str if it is a text log source, bytes if it is a binary/data
        log source.
        '''
        if not hasattr(self, '_logger_callbacks'):
            self._logger_callbacks = []
            self._text_sources = self.device_list_log_text_sources(device)

        def _cb(c_arg, level, source, msg, msg_size):
            try:
                src = source.decode('utf-8') if source else ''
                buf = _c.string_at(msg, msg_size) if msg and msg_size else b''
                if src in self._text_sources:
                    buf = buf.decode('utf-8', errors='replace')
                logger(level.value, src, buf)
            except Exception as e:
                LOG.exception(f"device logger callback raised: {e!r}")

        cfunc = axr.device_logger_fn(_cb)
        self._logger_callbacks.append(cfunc)
        ssources = ','.join(sources)
        res = axr.device_start_logger(
            self._obj,
            _c.byref(device._info),
            ssources.encode('utf-8'),
            cfunc,
            None,
            bool(clear_existing_logs),
        )
        if res.value != axr.Result.SUCCESS:
            _raise_error(self, res.value)

    def device_stop_logger(self, device: DeviceInfo) -> None:
        '''Stop device logging for the given device.'''
        axr.device_stop_logger(self._obj, _c.byref(device._info))

    def device_list_log_text_sources(self, device: DeviceInfo) -> list[str]:
        '''List available text log sources on the device.'''
        sources = axr.device_list_log_text_sources(self._obj, _c.byref(device._info))
        if not sources:
            _raise_error(self)
        return [s for s in sources.decode('utf-8').split(';')]

    def device_list_log_data_sources(self, device: DeviceInfo) -> list[str]:
        '''List available data log sources on the device.'''
        sources = axr.device_list_log_data_sources(self._obj, _c.byref(device._info))
        if not sources:
            _raise_error(self)
        return [s for s in sources.decode('utf-8').split(';')]


@dataclasses.dataclass
class TensorInfo:
    '''Information about a tensor input/output.

    This includes quantization and padding information if manifest.json was found
    in the model.

    For example to quantize and pad a tensor:

    >>> input = TensorInfo((1, 230, 240, 3), padding=[(0, 0), (3, 3), (3, 13), (0, 1)])
    >>> src = np.zeros(input.unpadded_shape, dtype=np.float32)
    >>> quant = np.round((src / input.scale) + input.zero_point).clip(-128, 127).astype(np.int8)
    >>> padded = np.pad(quant, input.padding, constant_values=input.zero_point)

    To depad and dequantize a tensor:

    >>> output = TensorInfo((1, 1, 1, 1024), padding=[(0, 0), (0, 0), (0, 0), (0, 24)])
    >>> out = np.zeros(output.shape, dtype=np.int8)
    >>> depadded = out[tuple(slice(b, -e if e else None) for b, e in output.padding)]
    >>> dequant = (depadded.astype(np.float32) - output.zero_point) * output.scale
    '''

    shape: tuple[int, ...]
    '''The shape of the tensor.'''

    dtype: np.dtype
    '''The data type of the tensor.'''

    name: str = ''
    '''The name of the tensor.'''

    padding: list[tuple[int, int]] = dataclasses.field(default_factory=list)
    """Amount of padding on the tensor.

    As list of [(start0, end0), (start1, end1), ...  (see numpy.pad)
    """

    scale: float = 1.0
    """scale for quantization/dequantization."""

    zero_point: int = 0
    """zero-point for quantization/dequantization."""

    @staticmethod
    def _reconstruct_dtype(context: Context, info: axr.TensorInfo) -> np.dtype:
        """Reconstruct the numpy dtype from the axr.TensorInfo."""
        if info.type == axr.TensorDataType.AXR_SIGNED:
            if info.bits == 8:
                return np.int8
            elif info.bits == 16:
                return np.int16
            elif info.bits == 32:
                return np.int32
            elif info.bits == 64:
                return np.int64
        elif info.type == axr.TensorDataType.AXR_UNSIGNED:
            if info.bits == 8:
                return np.uint8
            elif info.bits == 16:
                return np.uint16
            elif info.bits == 32:
                return np.uint32
            elif info.bits == 64:
                return np.uint64
        elif info.type == axr.TensorDataType.AXR_FLOAT:
            if info.bits == 16:
                return np.float16
            elif info.bits == 32:
                return np.float32
            elif info.bits == 64:
                return np.float64
        raise ValueError(f"Unknown dtype for tensor {info.name.decode('utf-8')}: {info.bits} bits")

    @classmethod
    def from_ctypes(cls, context: Context, info: axr.TensorInfo):
        return cls(
            shape=tuple(info.dims[: info.ndims]),
            dtype=TensorInfo._reconstruct_dtype(context, info),
            name=info.name.decode("utf-8"),
            padding=[tuple(x) for x in info.padding[: info.ndims]],
            scale=info.scale,
            zero_point=info.zero_point,
        )

    @property
    def size(self) -> int:
        '''The size of the tensor in bytes.'''
        return np.prod(self.shape) * self.dtype().itemsize

    @property
    def unpadded_shape(self) -> tuple[int, ...]:
        '''The shape of the tensor without padding.'''
        return tuple(dim - sum(pads) for dim, pads in zip(self.shape, self.padding))


class Model(Object):
    '''A model object that can be loaded onto a Connection object.'''

    def __init__(self, obj: pAnyObject, context: Context):
        super().__init__(obj, context)
        props = axr.get_model_properties(self._obj)
        if props:
            for name in axr.list_properties(props).decode("utf-8").split(';'):
                setattr(self, name, axr.get_property(props, name.encode('utf8')).decode("utf-8"))

    def inputs(self) -> list[TensorInfo]:
        '''Return information about the input tensors to the model.'''
        return [
            TensorInfo.from_ctypes(self.context, axr.get_model_input(self._obj, i))
            for i in range(axr.num_model_inputs(self._obj))
        ]

    def outputs(self) -> list[TensorInfo]:
        '''Return information about the output tensors of the model.'''
        return [
            TensorInfo.from_ctypes(self.context, axr.get_model_output(self._obj, i))
            for i in range(axr.num_model_outputs(self._obj))
        ]


@contextlib.contextmanager
def _kwargs(obj, **kwargs):
    kwargs = {k: int(v) if isinstance(v, bool) else v for k, v in kwargs.items()}
    s = "\n".join([f"{k}={v}" for k, v in kwargs.items()])
    props = axr.create_properties(obj.context._obj, s.encode("utf-8"))
    try:
        yield props
    finally:
        axr.destroy(_c.cast(props, axr.pObject))


class Connection(Object):
    '''A connection to one or more sub-devices.'''

    def load_model_instance(self, model: Model, **kwargs) -> ModelInstance:
        '''Load a model onto the sub-devices.

        Valid kwargs are :

        ================= ======= =================================================================
        Property          Default Description
        ================= ======= =================================================================
        aipu_cores        0       L2 resources to allocate for the model, set to batch size
        num_sub_devices   0       Number of sub-devices to use, set to batch size of the model
        input_dmabuf      0       True if the input arguments are dmabuf file descriptors
        device_profiling  0       True to enable device profiling
        host_profiling    0       True to enable host profiling
        output_dmabuf     0       True if the output arguments are dmabuf file descriptors
        double_buffer     0       True to enable double buffering
        elf_in_ddr        1       True if the model was compiled with elf_in_ddr as True.
        ================= ======= =================================================================
        '''
        with _kwargs(self, **kwargs) as props:
            instance = axr.load_model_instance(self._obj, model._obj, props)
        if not instance:
            _raise_error(self.context)
        return ModelInstance(instance, self.context)


def _as_arg(arg: Argument) -> axr.Argument:
    ptr, fd, size = (
        (arg.ctypes.data, 0, arg.nbytes) if isinstance(arg, np.ndarray) else (0, arg, 0)
    )
    return axr.Argument(ptr=ptr, fd=fd, offset=0, size=size)


if typing.TYPE_CHECKING:
    Argument = np.ndarray | int


class ModelInstance(Object):
    '''A model instance that has been loaded onto a Connection object.'''

    def run(self, inputs: typing.Sequence[Argument], outputs: typing.Sequence[Argument]) -> None:
        '''Run the model instance.

        If the model instance was created with `input_dmabuf=True` then inputs
        must be a list of file descriptors.  Otherwise it should be a list of
        numpy arrays.

        If the model instance was created with `output_dmabuf=True` then outputs
        must be a list of file descriptors.  Otherwise it should be a list of
        numpy arrays.

        On failure, an exception is raised.
        '''
        ins = (axr.Argument * len(inputs))(*[_as_arg(x) for x in inputs])
        outs = (axr.Argument * len(outputs))(*[_as_arg(x) for x in outputs])
        res = axr.run_model_instance(self._obj, ins, len(inputs), outs, len(outputs))
        if res.value != axr.Result.SUCCESS:
            _raise_error(self.context, res.value)

    def _run_graph(
        self,
        graph: str,
        inputs: typing.Sequence[Argument],
        outputs: typing.Sequence[Argument],
    ) -> None:
        ins = (axr.Argument * len(inputs))(*[_as_arg(x) for x in inputs])
        outs = (axr.Argument * len(outputs))(*[_as_arg(x) for x in outputs])
        res = axr.run_graph_model_instance(
            self._obj, graph.encode("utf-8"), ins, len(inputs), outs, len(outputs)
        )
        if res.value != axr.Result.SUCCESS:
            _raise_error(self.context, res.value)


def _device_index(devices: list[DeviceInfo], selector: str) -> int:
    try:
        index = int(selector)
    except ValueError:
        pass
    else:
        if index < 0 or index >= len(devices):
            raise ValueError(f"Device selector {selector} out of range")
        return index
    matching = [idx for idx, d in enumerate(devices) if d.name == selector]
    if not matching:
        raise ValueError(f"No device found matching {selector}")
    return matching[0]


def select_devices(available: list[DeviceInfo], selector: str) -> list[DeviceInfo]:
    '''Filter devices using a selector string.

    Comma separated list of devices to run on. Identifiers can be zero-based
    index, e.g. '0,1' or by name, e.g. 'metis-0:1:0,metis-0:2:0'.

    This is suitable for use in a command line application.  For example
    axrunmodel and axdevice both use this method to parse the `-d/--devices`
    option.
    '''
    if selector:
        indexes = [_device_index(available, s) for s in selector.split(',')]
        devices = [available[i] for i in indexes]
        if not devices:
            raise RuntimeError(f"No devices found matching {selector}")
    else:
        devices = available
    verb = 'Selected' if selector else 'Using'
    names = ', '.join(d.name for d in devices)
    devices_s = 's' if len(devices) > 1 else ''
    deselected = len(available) - len(devices)
    deselected_s = '' if deselected == 1 else 's'
    deselected = f" (deselected {deselected} other device{deselected_s})" if deselected else ''
    LOG.info(f"{verb} device{devices_s} {names}{deselected}")
    return devices
