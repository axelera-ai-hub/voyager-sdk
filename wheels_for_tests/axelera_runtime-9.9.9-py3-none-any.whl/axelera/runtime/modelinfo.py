#!/usr/bin/env python3
# Copyright Axelera AI, 2024
"""
Script to sum up memory pool sizes from model.json files.
This helps analyze the memory requirements of Axelera AI models.
"""
from __future__ import annotations

import argparse
import collections
import json
import os
import sys
import zipfile
from dataclasses import dataclass

from .objects import Context, Model, _getLogger  # noqa

LOG = _getLogger(__name__)

parser = argparse.ArgumentParser(description='Sum up memory pool sizes from model.json file')
parser.add_argument(
    'model',
    nargs='?',
    default='model.json',
    help='Path to model.json file or model.axm (default: ./model.json)',
)
parser.add_argument(
    "-q",
    "--quiet",
    default=0,
    action="count",
    help="be less verbose; use repeatedly for less info",
)
parser.add_argument(
    "-v",
    "--verbose",
    default=0,
    action="count",
    help="be more verbose; use repeatedly for more info",
)


def _format_size(size_bytes, include_bytes=True) -> str:
    """Format bytes to human-readable format"""
    if size_bytes == 0:
        return "0B"

    _size_bytes = size_bytes
    size_names = ("B", "KB", "MB", "GB", "TB")
    i = 0
    while size_bytes >= 1024 and i < len(size_names) - 1:
        size_bytes /= 1024
        i += 1
    if include_bytes:
        return f"{size_bytes:.2f}{size_names[i]} ({_size_bytes:,d})"
    else:
        return f"{size_bytes:.2f}{size_names[i]}"


def _format_table(titles: list[str], values: list[list[str]]) -> str:
    """Return a nicely formatted table string."""
    if not titles:
        return ""

    # Ensure all cells are strings and compute column widths
    cols = len(titles)
    str_titles = [str(t) for t in titles]
    rows: list[list[str]] = []
    widths = [len(t) for t in str_titles]

    for row in values:
        # Pad/truncate row to match number of columns
        r = [str(c) for c in row[:cols]] + [""] * max(0, cols - len(row))
        rows.append(r)
        for i, cell in enumerate(r):
            widths[i] = max(len(cell), widths[i])

    def fmt_row(r: list[str]) -> str:
        return " ".join(cell.ljust(widths[i]) for i, cell in enumerate(r))

    header = fmt_row(str_titles)
    sep = "-" * (sum(widths) + (cols - 1))
    body = "\n".join(fmt_row(r) for r in rows)
    return f"{sep}\n{header}\n{sep}\n{body}\n{sep}"


@dataclass
class PoolInfo:
    name: str
    memory: str  # L2 or DDR
    size: int
    depth: int
    effective_size: int
    has_init: bool


@dataclass
class MemoryInfo:
    L2: int
    DDR: int
    pools: list[PoolInfo]


def read_memory_info(json_file: str) -> MemoryInfo:
    """Calculate memory pool sizes from model.json file"""
    if json_file.endswith('.axm'):
        with zipfile.ZipFile(json_file, 'r') as zf:
            with zf.open('model.json') as f:
                model_data = json.load(f)
    else:
        with open(json_file, 'r') as f:
            model_data = json.load(f)

    if 'memory_pools' not in model_data:
        raise RuntimeError(f"No memory_pools found in {json_file}")

    by_type = collections.defaultdict(int)
    pools = []
    for p in model_data['memory_pools']:
        mtype, size, depth = p['memory'].upper(), p['size'], p.get('depth', 1)
        effective_size = size * depth
        by_type[mtype] += effective_size
        pools.append(PoolInfo(p['name'], mtype, size, depth, effective_size, 'blob_file' in p))
    return MemoryInfo(by_type['L2'], by_type['DDR'], pools)


def _quiet_print(minfo: MemoryInfo):
    print(f"{minfo.DDR + minfo.L2:d}")


def _normal_print(minfo: MemoryInfo):
    print(f"L2: {_format_size(minfo.L2, False)} DDR: {_format_size(minfo.DDR, False)}")


def _verbose_print(minfo: MemoryInfo):
    rows = [
        [
            p.name,
            p.memory,
            _format_size(p.effective_size),
            str(p.depth),
            ("Yes" if p.has_init else "No"),
        ]
        for p in minfo.pools
    ]
    print(_format_table(["Pool Name", "Type", "Size", "Depth", "Has Init"], rows))
    print("\nSummary:")
    print("-" * 45)
    print(f"L2    : {_format_size(minfo.L2):<27}")
    print(f"DDR   : {_format_size(minfo.DDR):<27}")
    print("-" * 45)
    print(f"TOTAL : {_format_size(minfo.L2 + minfo.DDR):<27}")
    print("-" * 45)


def _show_tensor_info(model: Model):
    """Show tensor information from model.json file"""
    rows = []
    tensors = [('<', t) for t in model.inputs()] + [('>', t) for t in model.outputs()]
    for direction, t in tensors:
        shape_str = ','.join(str(d) for d in t.unpadded_shape)
        name = t.name or '<unnamed>'
        quant = f"{t.scale:.6f}/{t.zero_point}"
        pads = ','.join(f"{b}:{e}" for b, e in t.padding)
        rows.append([direction, name, shape_str, pads, quant, _format_size(t.size)])
    total = sum(t.size for _, t in tensors)
    rows.append(['', 'TOTAL', '', '', '', _format_size(total)])
    print(
        _format_table(
            [' ', 'Tensor Name', 'Unpadded Shape', 'Padding', 'Quant Scale/Zp', 'Size'],
            rows,
        )
    )


_QUIET, _NORMAL, _VERBOSE = 0, 1, 2


def _verbosity(args) -> int:
    return max(0, min(2, args.verbose - args.quiet + 1))


def main(args):
    if os.path.isdir(args.model) and os.path.isfile(os.path.join(args.model, 'model.json')):
        args.model = os.path.join(args.model, 'model.json')
    minfo = read_memory_info(args.model)
    printer = [_quiet_print, _normal_print, _verbose_print][_verbosity(args)]
    printer(minfo)
    if _verbosity(args) > _QUIET:
        print()
        with Context() as ctx:
            _show_tensor_info(ctx.load_model(args.model))


def entrypoint_main():
    args = parser.parse_args()
    try:
        main(args)
    except Exception as e:
        if args.verbose:
            raise
        sys.exit(f'Error: {e}')


if __name__ == "__main__":
    entrypoint_main()
