#!/usr/bin/env python3
# Copyright Axelera AI, 2025
from __future__ import annotations

import argparse
import difflib
import hashlib
import importlib.metadata
import io
import json
import os
import pathlib
import re
import shutil
import sys
import tempfile
import urllib.request
from urllib.error import HTTPError, URLError
from zipfile import ZipFile

from alive_progress import alive_bar, alive_it

MODELS_FILE = 'models.json'
_DOWNLOAD_BASE = 'https://media.axelera.ai/artifacts'
_DOWNLOADMODEL_TEMPLATE = '{download_base}/prebuilt/voyager-sdk-v{sdk_version}'

parser = argparse.ArgumentParser(description='Download models from Axelera cloud service.')
parser.add_argument(
    'models',
    nargs='*',
    help="Model name(s) to download, e.g. yolov5s-v7-coco",
)
parser.add_argument('-v', '--verbose', action='store_true', help='Print stack trace on error')
parser.add_argument(
    '-f', '--force', action='store_true', help='Overwrite model if it already exists'
)
parser.add_argument('--version', default='', help='Override version of SDK, e.g. 1.2.0-rc3')
parser.add_argument('--show-version', action='store_true', help='Print version of SDK and exit')
parser.add_argument(
    '--ignore-checksum', action='store_true', help='Skip checksum validation of downloaded files'
)
parser.add_argument(
    '--verify-checksum-only',
    action='store_true',
    help='Just verify checksum after download, do not unpack',
)
parser.add_argument(
    '--list', action='store_true', help='List all available models for the current version'
)
parser.add_argument(
    '--all', action='store_true', help='Download all available models for the current version'
)
parser.add_argument(
    "--axm",
    action="store_true",
    help="Download and create <model>.axm file in pwd",
)


def get_download_url(sdk_version: str) -> str:
    base_url = os.environ.get('AXELERA_DOWNLOAD_BASE', _DOWNLOAD_BASE)
    template = os.environ.get('AXELERA_DOWNLOADMODEL_TEMPLATE', _DOWNLOADMODEL_TEMPLATE)
    return template.format(download_base=base_url, sdk_version=sdk_version)


def get_version():
    def with_rc(v, rc):
        return f'{v}-{rc}' if rc else v

    please = '\nPlease specify version with --version'
    try:
        v = importlib.metadata.version('axelera-runtime')
    except importlib.metadata.PackageNotFoundError as e:
        err = f"Failed to find python package axelera-runtime: {e}.{please}"
        raise RuntimeError(err)
    m = re.match(r'^(\d+\.\d+\.\d+)-?(rc\d+)?', v)
    if not m:
        err = f"Failed to parse version ({v}) of python package axelera-runtime.{please}"
        raise RuntimeError(err)

    return with_rc(m.group(1), m.group(2))


def _s3_object(url: str) -> object | None:
    if not url.lower().startswith('s3://'):
        return None
    url = url.removeprefix('s3://')
    import boto3

    if '/' not in url:
        raise ValueError("Invalid S3 path format. Path should have a bucket and a key.")
    bucket, key = url.split('/', 1)
    return boto3.resource("s3").Object(bucket, key)


def get_models(version: str) -> dict[str, str]:
    url = f"{get_download_url(version)}/{MODELS_FILE}"
    if s3 := _s3_object(url):
        data = io.BytesIO()
        s3.download_fileobj(data)
        return json.loads(data.getvalue().decode('utf-8'))
    try:
        with urllib.request.urlopen(url, timeout=10) as resp:
            encoding = resp.headers.get_content_charset() or "utf-8"
            return json.loads(resp.read().decode(encoding))

    except HTTPError as e:
        if e.code == 403:
            raise RuntimeError(
                f"Pre-built models are not available for version {version!r}. "
                "Try another version with --version, but be aware of compatibility."
            ) from e
        raise

    except URLError as e:
        raise RuntimeError(f"Failed to reach {url}: {e.reason}") from e


def generate_md5(path: str) -> str:
    hash_md5 = hashlib.md5()
    nbytes = path.stat().st_size
    chunk_size = 4096
    total_chunks = int(nbytes / chunk_size) + (1 if nbytes % chunk_size else 0)
    with (
        open(path, 'br') as f,
        alive_bar(
            total_chunks,
            title=f"Authenticate {path}",
            force_tty=True,
            disable=(nbytes < 1000000000),
        ) as bar,
    ):
        while True:
            chunk = f.read(chunk_size)
            if not chunk:
                break
            hash_md5.update(chunk)
            bar()
    return hash_md5.hexdigest()


def md5_validates(path, md5):
    if not md5:
        return False
    return generate_md5(path) == md5


def download_url(url: str, path: pathlib.Path):
    """Download file from URL/S3 to path with progress bar."""
    path.parent.mkdir(parents=True, exist_ok=True)
    if s3 := _s3_object(url):
        with alive_bar(receipt=False, stats=False, monitor='', elapsed='{elapsed}') as sp:
            sp.title(f"Downloading {url}")
            s3.download_file(str(path))

    else:
        with urllib.request.urlopen(url) as response:
            total = int(response.getheader('Content-Length', 0))
            chunk_size = 8192

            with open(path, 'wb') as f:
                with alive_bar(total, receipt=False, unit='B', scale='SI') as sp:
                    sp.title(f"Downloading {url}")
                    while True:
                        chunk = response.read(chunk_size)
                        if not chunk:
                            break
                        f.write(chunk)
                        sp(len(chunk))


def _exists_legacy(args, mname) -> bool:
    if not args.verify_checksum_only and os.path.exists(f'build/{mname}'):
        if args.force:
            print(f'Overwriting existing model {mname} because --force is set')
            shutil.rmtree(f'build/{mname}')
        else:
            print(f'{mname} already exists, overwrite with --force')
            return True
    return False


def _exists_axm(args, mname) -> bool:
    axm = f"{mname}.axm"
    if not args.verify_checksum_only and os.path.exists(axm):
        if args.force:
            print(f"Overwriting existing model {axm} because --force is set")
            os.remove(axm)
        else:
            print(f"{axm} already exists, overwrite with --force")
            return True
    return False


def download(args):
    '''Download prebuilt models from the cloud.'''

    version = args.version or get_version()
    version = version.lstrip('v')  # remove leading 'v' if present - a common mistake
    if args.show_version:
        print(version)
        return

    models = get_models(version)
    if args.list:
        indent = ''
        if sys.stdout.isatty():
            print(f'Available models: (version {version})')
            indent = '  '
        for model in models:
            print(f'{indent}{model.removesuffix(".zip")}')
        return

    if args.all:
        to_download = models.keys()
    elif not args.models:
        raise ValueError('Please specify a model to download, or --all or --list')
    else:
        to_download = [m.removeprefix('mc-') for m in args.models]

    if args.axm:
        # Remove cascade demos, as they need handling differently
        for m in ["fruit-demo", "yolov5m-v7-coco-tracker"]:
            if m in to_download:
                to_download.remove(m)
                print(f"The '{m}' model is not available as an .axm file and has been skipped.")

    to_download = [m.removesuffix(".zip") for m in to_download]
    for mname in to_download:
        exists = _exists_axm if args.axm else _exists_legacy
        if exists(args, mname):
            continue
        f = f"{mname}.zip"
        if not (checksum := models.get(f)):
            names = [x.removesuffix('.zip') for x in models.keys()]
            if maybe := difflib.get_close_matches(mname, names, n=3):
                one_of = 'one of: ' if len(maybe) > 1 else ''
                dym = f"Did you mean {one_of}{', '.join(maybe)}?"
            else:
                dym = 'No close matches found, use --list to see available models.'
            raise ValueError(f'Prebuilt model not available for {mname} in v{version}\n{dym}')

        with tempfile.TemporaryDirectory() as unpack_dir:
            url = f"{get_download_url(version)}/{f}"
            zip_path = pathlib.Path(f"{unpack_dir}/{f}")
            download_url(url, zip_path)
            checksum_ok = True
            if checksum and not args.ignore_checksum and not md5_validates(zip_path, checksum):
                checksum_ok = False
                msg = f"Downloaded file {zip_path} failed checksum validation (exp: {checksum} got: {generate_md5(zip_path)})"
                if args.verify_checksum_only:
                    print(f'FAIL: {msg}')
                elif args.ignore_checksum:
                    print(f'WARNING: {msg}, but continuing because --ignore-checksum is set')
                else:
                    raise RuntimeError(msg)

            if (checksum_ok or args.ignore_checksum) and not args.verify_checksum_only:
                unpacker = _unpack_axm if args.axm else _unpack_legacy
                unpacker(mname, zip_path)

            zip_path.unlink()


def _unpack_legacy(mname, zip_path):
    with ZipFile(zip_path, 'r') as zf:
        zf.extractall(pathlib.Path.cwd())
    print(f'Downloaded and unpacked \033[92m{mname}\033[0m')


def _unpack_axm(mname, zip_path):
    axm = f"{mname}.axm"
    with ZipFile(zip_path, "r") as zf, ZipFile(axm, "w") as axf:
        for n in alive_it(zf.namelist(), title=f"Creating {axm}", receipt=False):
            m = re.match(r"^build/[^/]+/[^/]+/([^/]+/)?(.*)", n)
            if not (m and m.group(1) in (None, "1/")):
                continue
            outn = m.group(2)
            axf.writestr(outn, zf.read(n))
    print(f"Downloaded and created \033[92m{axm}\033[0m")


def entrypoint_main():
    args = parser.parse_args()
    try:
        download(args)
    except Exception as e:
        if args.verbose:
            raise
        print(f'Error: {e}', file=sys.stderr)
        sys.exit(1)


if __name__ == '__main__':
    entrypoint_main()
