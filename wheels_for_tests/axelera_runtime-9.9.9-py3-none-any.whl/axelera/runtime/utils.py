# Copyright (c) 2025 Axelera AI. All rights reserved.
import collections
import itertools
import logging
import os
import re
import tempfile
import threading
import time
import typing
from pathlib import Path
from typing import DefaultDict

import numpy as np

from .objects import TRACE, _getLogger  # noqa

LOG = _getLogger(__name__)


def _read_frequency(ctx, devices):
    """Read AICORE clock frequency."""
    cfg = ctx.read_device_configuration(devices[0])
    # FIXME: change back to clock_profile_core_0 when SDK-8937 is fixed
    return int(cfg.get('clock_profile', '800')) * 1_000_000


def is_running_inside_qemu():
    """
    Detect if running in QEMU environment.
    """
    try:
        with open('/proc/cpuinfo', 'r') as f:
            cpuinfo = f.read()
            if 'QEMU' in cpuinfo:
                LOG.info("Running inside QEMU detected in /proc/cpuinfo")
                return True
    except Exception as e:
        LOG.info(f"Failed to read /proc/cpuinfo: {e}")

    return False


class ThreadedTracerAdapter:
    '''Adapts a tracer to run in a separate thread on a period basis.

    The metrics returned are cached, and returned on request.
    '''

    def __init__(self, adaptee, period=1.0):
        self._condition = threading.Condition()
        self._period = period
        self._thread = threading.Thread(target=self._monitor, daemon=True)
        self._last_metrics = []
        self._tracer = adaptee
        self._tracer.start_monitoring()
        self._running = True
        self._thread.start()

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        with self._condition:
            self._running = False
            self._condition.notify()
        self._thread.join()
        self._tracer.stop_monitoring()

    def _monitor(self):
        while 1:
            self._tracer.monitor()
            with self._condition:
                if self._condition.wait_for(lambda: not self._running, self._period):
                    break

    @property
    def value(self):
        return self._tracer.value


def _count_as_bar(value, width=20, max=100):
    blocks = ' \u258f\u258e\u258d\u258c\u258b\u258a\u2589'
    whole = int(width * value / max)
    remainder = int(((width * value / max) - whole) * 8)
    return ('\u2588' * whole + blocks[remainder]).ljust(width)


def _figure(labels, values, width):
    max_label = max(len(label) for label in labels)
    max_height = max(values)
    for label, value in zip(labels, values, strict=True):
        bar = _count_as_bar(value, width, max_height)
        print(f"{label.ljust(max_label)} | {bar}")


def _bar_chart(data, rows=40, width=120):
    per_bin = len(data) // rows
    to_pad = per_bin - len(data) % per_bin
    data = np.pad(data, (0, to_pad))
    data = data.reshape(-1, per_bin).mean(axis=1)
    labels = [str(i) for i in range(len(data))]
    _figure(labels, data, width)


def _draw_histogram(data, bins=40, width=120):
    hist, bin_edges = np.histogram(data, bins=bins)
    labels = [f"{a:.2f} - {b:.2f}" for a, b in itertools.pairwise(bin_edges)]
    _figure(labels, hist, width)


def _samples_as_fps(
    sample_chunks: list[np.ndarray],
    convert_to_s: float,
    fps_multiplier: int,
    name: str,
    show_chart='',
):
    if not sample_chunks:
        return 0.0
    samples = np.concatenate(sample_chunks)
    count = int(len(samples) * 0.80)
    samples = samples[-count:] * convert_to_s
    v = np.mean(samples)
    if show_chart:
        print(f"{show_chart} in fps of {name} : ")
        if show_chart == 'bar chart':
            _bar_chart(1 / samples * fps_multiplier)
        else:
            _draw_histogram(1 / samples * fps_multiplier)
    as_ms = 1e3
    median = np.median(samples)
    minl = np.min(samples) * as_ms
    mean = np.mean(samples) * as_ms
    maxl = np.max(samples) * as_ms
    LOG.info(
        f"{name} latency(ms): {median:1f} nsamples={len(samples)} "
        f"min={minl:.1f} max={maxl:.1f} mean_l={mean:.1f}"
    )
    return (1 / v if v > 0 else 0) * fps_multiplier


class AipuTracer:
    '''A class to monitor AIPU inference server using axtrace.'''

    _PATTERN = re.compile(r"Megakernel  ?took (\d+) cycles")
    _TEMP = re.compile(r"collector: core_temps=\[(\d+(?:,\d+)*)\]")

    def __init__(self, ctx, devices, aipu_cores: int, show_chart: str):
        super().__init__()
        self._requested_cores = list(range(aipu_cores))
        self._frequency = _read_frequency(ctx, devices)
        self._fps_multiplier = aipu_cores
        self._all_chunks: list[np.ndarray] = []
        self._show_chart = show_chart
        self._ctx = ctx
        self._devices = devices
        self._max_core_temp = None

    def __enter__(self):
        for d in self._devices:
            sources = ['sysctrl'] + [f"aicore{n}" for n in self._requested_cores]
            for s in sources:
                self._ctx.device_set_log_level(d, s, "wrn")
            self._ctx.device_set_log_level(d, "sysctrl", "err")
            self._ctx.device_set_log_level(d, "sysctrl", "inf:collector")
            self._ctx.device_start_logger(d, sources, self._cb, clear_existing_logs=True)
        return self

    def _cb(self, level, src, msg):
        if src.startswith('aicore'):
            if matches := self._PATTERN.findall(msg):
                cycles = np.array([int(m) for m in matches], dtype=np.int32)
                self._all_chunks.append(cycles)
        elif src == 'sysctrl':
            if matches := self._TEMP.findall(msg):
                temp = [[int(x) for x in m.split(',')] for m in matches]
                values = np.array(temp)
                self._max_core_temp = max(np.max(values), self._max_core_temp or 0.0)

    @property
    def value(self):
        return _samples_as_fps(
            self._all_chunks, 1 / self._frequency, self._fps_multiplier, "device", self._show_chart
        )

    @property
    def core_temp(self):
        return self._max_core_temp

    def __exit__(self, *exc):
        for d in self._devices:
            self._ctx.device_stop_logger(d)
            sources = [f"aicore{n}" for n in self._requested_cores]
            for s in sources:
                self._ctx.device_set_log_level(d, s, "err")
            self._ctx.device_set_log_level(d, "sysctrl", "err")


_axr_mappings = {
    'inp': 'Memcpy-in',
    'krn': 'Kernel',
    'out': 'Memcpy-out',
    'tot': 'Host',
    'pat': 'Patch Parameters',
}
_axr_entry = re.compile(r"\b(\w+):([\da-f]+)\b")


def _parse_axr_stats(logs: str) -> dict[str, np.ndarray]:
    stats = collections.defaultdict(list)
    for line in logs.splitlines():
        for key, value in _axr_entry.findall(line):
            if key not in ('idx', 'beg'):
                stats[key].append(int(value, 16) / 1e9)
    return {_axr_mappings.get(k, k): np.array(v) for k, v in stats.items()}


def _add_to_environ(environ, key, value):
    existing = environ.get(key, '')
    values = existing.split(',') if existing else []
    values.append(value)
    environ[key] = ','.join(values)


class HostTracer:
    '''A class to monitor host timing using timings at level zero execute level.'''

    _TRACE_DEBOUNCER_THRESHOLD = 3  # number of attemps before declaring host tracing disabled

    def __init__(self, aipu_cores: int, show_chart: str):
        super().__init__()
        self._temp_file = tempfile.NamedTemporaryFile(delete=True)
        self._file_path = Path(self._temp_file.name)
        self._temp_file.close()
        self._log_debouncer = 0
        self._all_chunks: DefaultDict[str, list[np.ndarray]] = collections.defaultdict(list)
        self._last_read_position = 0
        self._requested_cores = aipu_cores
        self._fps_multiplier = aipu_cores
        self._running = False
        self._max_age = 5
        self._next_drop = time.time() + 5.0
        self._show_chart = show_chart
        os.environ['AXE_LZ_PERF_LOG_PATH'] = str(self._file_path)
        _add_to_environ(os.environ, 'AXE_PROFILING_CONFIG', 'HOST_TEMPLATE')

    def start_monitoring(self):
        self._running = True

    def stop_monitoring(self):
        self.monitor()
        # Clean up the temporary file
        try:
            if self._file_path.exists():
                self._file_path.unlink()
        except Exception as e:
            LOG.warning(f"Failed to delete temporary file {self._file_path}: {e}")
        # Clear the environment variable
        if 'AXE_LZ_PERF_LOG_PATH' in os.environ:
            del os.environ['AXE_LZ_PERF_LOG_PATH']

    def _read_logs(self):
        if not self._running:
            return ''

        if not self._file_path.exists():
            self._log_debouncer += 1
            if self._log_debouncer == self._TRACE_DEBOUNCER_THRESHOLD:
                LOG.warning(f"{self._file_path} not found, host profiling disabled")
                self._running = False
            return ''

        with self._file_path.open('r+') as f:
            f.seek(self._last_read_position)
            logs = f.read()
            self._last_read_position = f.tell()
            MAX_LOG_SIZE = 1e6
            if f.tell() > MAX_LOG_SIZE:
                f.seek(0)
                f.truncate(0)  # Empty the original log file
                self._last_read_position = 0  # Reset reading position
        return logs

    def _process_logs(self, logs):
        # TODO we ought to know if using tvm or axruntime but for now try both
        now = time.time()
        stats = _parse_axr_stats(logs)
        for s, v in stats.items():
            self._all_chunks[s].append((now, v))

    def monitor(self):
        self._process_logs(self._read_logs())

    @property
    def value(self):
        chunks = [chunk for _, chunk in self._all_chunks['Host']]
        return _samples_as_fps(chunks, 1.0, self._fps_multiplier, "host", self._show_chart)


T = typing.TypeVar('T')
Validator = typing.Callable[[str], T]


def _parse_core_indexes(
    s: str, max_cores: int, extra: str = '', extra_hr: str = ''
) -> list[tuple[typing.Any, ...]]:
    result = []
    LAST_CORE = max_cores - 1
    for part in s.split(','):
        m = re.match(rf'(\d+)(?:-(\d+))?{extra}$', part)
        if not m:
            raise ValueError(f"Format is [first_core_index[-last_core_index]{extra_hr}")
        first = int(m.group(1))
        last = int(m.group(2)) if m.group(2) else first
        first, last = sorted([first, last])
        if first > LAST_CORE or last > LAST_CORE:
            if first == last:
                which, is_, es = str(first), 'is', ''
            elif first > LAST_CORE:
                which, is_, es = f"{first} and {last}", "are", 'es'
            else:
                which, is_, es = f"{last}", 'is', ''
            raise ValueError(f"Core index{es} {which} {is_} out of range")
        result.append((first, last, *m.groups()[2:]))
    return result


def core_specifier(s: str, max_cores: int) -> list[int]:
    '''Parse a string of the form "N[-M](,N[-M])+" into a list of core indexes.

    >>> core_specifier('0-2,3', 4)
    [0, 1, 2, 3]
    >>> core_specifier('1,3', 4)
    [1, 3]
    >>> core_specifier('', 5)
    [0, 1, 2, 3, 4]
    '''
    values: list[int] = []
    if s == '':
        return list(range(0, max_cores))
    for first, last in _parse_core_indexes(s, max_cores):
        values.extend(range(first, last + 1))
    return values


def core_value_pairs(s: str, validator: Validator, max_cores: int) -> list[tuple[int, T]]:
    '''Parse a string of the form "N[-M]:X(,N[-M]:X)+" into a list of (core_index, value) pairs.

    >>> core_value_pairs('0-1:50,2:100,3:400', int, 4)
    [(0, 50), (1, 50), (2, 100), (3, 400)]
    >>> core_value_pairs('0-3:400', int, 4)
    [(0, 400), (1, 400), (2, 400), (3, 400)]
    >>> core_value_pairs('500', str, 4)
    [(0, '500'), (1, '500'), (2, '500'), (3, '500')]
    >>> core_value_pairs('500', str, 5)
    [(0, '500'), (1, '500'), (2, '500'), (3, '500'), (4, '500')]

    '''
    values: list[tuple[int, int]] = []
    if re.match(r'\d+$', s):
        s = f"0-{max_cores - 1}:{s}"
    for first, last, value in _parse_core_indexes(s, max_cores, r":(.*)", ":value"):
        try:
            values.extend((core, validator(value)) for core in range(first, last + 1))
        except Exception as e:
            raise ValueError(f"Invalid value: {value}") from e
    return values


def configure_logging(verbosity: int):
    COLORS = {
        'WARNING': '\033[33m',  # Yellow
        'ERROR': '\033[31m',  # Red
        'CRITICAL': '\033[31m;1m',  # Bold Red
    }
    RESET = '\033[0m'

    class _ColorFormatter(logging.Formatter):
        def format(self, record):
            levelname = record.levelname
            if levelname in COLORS:
                record.levelname = f"{COLORS[levelname]}{levelname}{RESET}"
            return super().format(record)

    levels = {0: logging.WARNING, 1: logging.INFO, 2: logging.DEBUG}
    logformat = '%(levelname)s: %(message)s'
    logging.basicConfig(level=levels.get(verbosity, TRACE), format=logformat)

    for handler in logging.root.handlers:
        if isinstance(handler, logging.StreamHandler) and handler.stream.isatty():
            handler.setFormatter(_ColorFormatter(logformat))
