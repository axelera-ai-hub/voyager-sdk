#
# Copyright (c) 2023 Axelera AI. All rights reserved.
#
"""TVM axelera.compiler.build_module compatilibity layer."""
import logging
import os
from typing import Any, Dict

import numpy as np

from .objects import Context, Model, ModelInstance


class Output:
    def __init__(self, x):
        self.x = x

    def numpy(self):
        # Clone the data to avoid memory corruption on multiple iterations
        return self.x.copy()

    asnumpy = numpy


class GraphExecutor:
    def __init__(self, ctx: Context, model: Model, instance: ModelInstance):
        self._ctx = ctx
        self._instance = instance
        self._input_infos = model.inputs()
        self._output_infos = model.outputs()
        self._inputs: list[np.ndarray | int] = [
            np.zeros(t.shape, t.dtype) for t in self._input_infos
        ]
        self._outputs: list[np.ndarray | int] = [
            np.zeros(t.shape, t.dtype) for t in self._output_infos
        ]

    def get_input_info(self) -> list[dict[int, tuple[int, ...]]]:
        return [{n: i.shape for n, i in enumerate(self._input_infos)}]

    def get_output_info(self) -> list[dict[int, tuple[int, ...]]]:
        return [{n: i.shape for n, i in enumerate(self._output_infos)}]

    def get_num_inputs(self) -> int:
        return len(self._input_infos)

    def get_num_outputs(self) -> int:
        return len(self._output_infos)

    def set_input(self, name_or_index: str | int, data: np.ndarray) -> None:
        if isinstance(name_or_index, str):
            assert len(self._input_infos) == 1, "Only one input is supported"
            name_or_index = 0  # we don't have access to names yet

        assert data.dtype == self._input_infos[name_or_index].dtype, (
            f"Expected input dtype to be {self._input_infos[name_or_index].dtype}, "
            f"but got {data.dtype}"
        )
        assert data.shape == self._input_infos[name_or_index].shape, (
            f"Expected input shape to be {self._input_infos[name_or_index].shape}, "
            f"but got {data.shape}"
        )
        if not data.flags["C_CONTIGUOUS"]:
            data = np.ascontiguousarray(data)
        self._inputs[name_or_index] = data

    def set_input_fd(self, index: int, fd: int) -> None:
        self._inputs[index] = fd

    def set_output_fd(self, index: int, fd: int) -> None:
        self._outputs[index] = fd

    def run(self) -> None:
        self._instance.run(self._inputs, self._outputs)

    def get_output(self, idx: int) -> Output:
        return Output(self._outputs[idx])

    def release(self):
        self._ctx.release()


def graph_exec_load_model(
    dir: str, lib_filename: str, runtime_params: Dict[str, Any] | None = None
) -> GraphExecutor:
    log_level = os.getenv("AX_LOGLEVEL")
    if log_level is not None:
        root_logger = logging.getLogger()
        if root_logger.hasHandlers():
            root_logger.handlers.clear()
        logging.basicConfig(level=getattr(logging, log_level, logging.INFO))

    if runtime_params is None:
        runtime_params = {}
    target = runtime_params.pop("target", "silicon")

    ctx = Context()
    model = ctx.load_model(f"{dir}/{lib_filename}")
    conn = ctx.device_connect(
        num_sub_devices=runtime_params.get("num_sub_devices", 1), target=target
    )
    instance = conn.load_model_instance(model, **runtime_params)
    return GraphExecutor(ctx, model, instance)


# alias for backward compatibility
axelera_load_model = graph_exec_load_model
