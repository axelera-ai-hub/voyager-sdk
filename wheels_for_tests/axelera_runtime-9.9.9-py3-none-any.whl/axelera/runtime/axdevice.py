# Copyright Axelera AI, 2026
"""Enumerate and configure Axelera devices.

If no arguments are given the script will list all devices found.

For help with enumeration issues try enabling verbose output with -v.
"""
from __future__ import annotations

import argparse
import itertools
import logging
import os
import platform
import shutil
import subprocess
import sys
import tempfile
import time
from datetime import datetime
from pathlib import Path
from typing import NamedTuple

import alive_progress

from . import BoardType, DeviceInfo, objects, select_devices, utils
from .pci_scanner import get_pci_scanner

LOG = logging.getLogger(__name__)

parser = argparse.ArgumentParser(
    description=__doc__, formatter_class=argparse.RawTextHelpFormatter
)


def _core_clock_pairs(s: str, max_cores: int) -> list[tuple[int, int]]:
    try:
        values = utils.core_value_pairs(s, int, max_cores)
        if invalid := [v for c, v in values if v not in _valid_core_clocks]:
            invalid = list(set(invalid))
            invs = ','.join(str(x) for x in invalid)
            are = "is not a" if len(invalid) == 1 else "are not"
            s = "" if len(invalid) == 1 else "s"
            valids = ','.join(str(x) for x in _valid_core_clocks)
            raise ValueError(f"{invs} {are} valid core clock value{s}, valid values are {valids}")
        return values
    except ValueError as e:
        raise ValueError(f"--set-core-clock: {e}") from None


def _clock_freq(s: str) -> int:
    v = int(s)  # Allow ValueError to propagate
    if v not in _valid_clocks:
        valids = ','.join(str(x) for x in _valid_clocks)
        raise argparse.ArgumentTypeError(
            f"{s} is not a valid clock value, valid values are {valids}"
        )
    return v


def _core_mvm_pairs(s: str, max_cores: int) -> list[tuple[int, int]]:
    try:
        values = utils.core_value_pairs(s, int, max_cores)
        if invalid := [v for _, v in values if not 1 <= v <= 100]:
            invs = sorted(set(invalid))
            is_ = 'is' if len(invs) == 1 else 'are'
            invs = ', '.join(str(x) for x in invs)
            raise ValueError(f"{invs} {is_} not valid. Valid values are in range [1, 100]")
        return values
    except ValueError as e:
        raise ValueError(f"--set-mvm-limitation: {e}") from None


_valid_clocks = [100, 200, 400, 600, 700, 800]
_valid_core_clocks = list(range(200, 850, 50))

parser.add_argument(
    '--set-clock',
    type=_clock_freq,
    metavar='CLOCK',
    help=f'''\
set clock speed of device, value is frequency in MHz

this must be one of the following values : {','.join(str(x) for x in _valid_clocks)}''',
)

parser.add_argument(
    '--set-core-clock',
    metavar='CORE_CLOCK',
    default=[],
    help='''\
set the clock frequency of an individual core or multiple cores

CORE_CLOCK is a list of core indexes and a clock frequency, or just a frequency,
for example:

  %(prog)s --set-core-clock 0-1:800,2-3:400
  %(prog)s --set-core-clock 600

the first will configure cores 0 and 1 to use a clock frequency of 800MHz, and
cores 2 and 3 to use 400MHz.  The second will configure all cores to use a clock
frequency of 600MHz.
''',
)

parser.add_argument(
    '--set-mvm-limitation',
    metavar='CORE_MVM',
    default=[],
    help='''\
set the MVM limitation value for an individual core or multiple cores

CORE_MVM is a list of core indexex and given MVM limitation value, for example:

  %(prog)s --set-mvm-limitation 0:100,1-3:50
  %(prog)s --set-mvm-limitation 75

the first will configure core 0 to be unrestricted in use of the MVM, and cores
1, 2, and 3 to be limited to a maximum utilisation of 50 percent. The second
will configure all cores to be limited to a maximum utilisation of 75 percent.
''',
)

parser.add_argument(
    '--set-sw-throttling',
    metavar='T:H:L',
    help='''\
set software throttling controls. Metis firmware will throttle the operation of
the chip by limiting the MVM utilization during runtime when temperature crosses
a specific threshold. The mechanism works as follows: when the temperature
surpasses a threshold T (in Celsius degrees), the MVM utilization is limited to
L%%; when the temperature falls by H hysteresis degrees (Celsius) the MVM
utilization limit is lifted.  For example to set T=100, H=5, L=10, use:
    %(prog)s --set-sw-throttling 100:5:10

The current values are output by enabling verbose output:
    %(prog)s -v
''',
)

parser.add_argument('--set-hw-throttling', metavar='T:H', help=argparse.SUPPRESS)
# this option is for advanced use only, only use under Axelera AI's guidance
'''\
set hardware throttling controls. Metis hardware will throttle the operation of
the chip by limiting the MVM utilization during runtime when temperature crosses
a specific threshold. The mechanism works as follows: when the temperature
surpasses a threshold T (in Celsius degrees), the MVM utilization is limited to
1%%; when the temperature falls by H hysteresis degrees (Celsius) the MVM
utilization limit is lifted.  For example to set T=100, H=5, use:
    %(prog)s --set-hw-throttling 100:5

The current values are output by enabling verbose output:
    %(prog)s -v
'''

parser.add_argument('--set-freq-downscaling', metavar='T:H', help=argparse.SUPPRESS)
# this option is for advanced use only, only use under Axelera AI's guidance
'''\
set frequency downscaling controls. Metis hardware will throttle the operation of
the chip by limiting lowering the frequency during runtime when temperature crosses
a specific threshold. The mechanism works as follows: when the temperature
surpasses a threshold T (in Celsius degrees), the frequency is limited to
????TODO????%%; when the temperature falls by H hysteresis degrees (Celsius) the
frequency is returned to normal operation.  For example to set T=100, H=5, use:
    %(prog)s --set-freq-downscaling 100:5

The current values are output by enabling verbose output:
    %(prog)s -v
'''

parser.add_argument(
    '--set-pvt-warning-threshold',
    metavar='THRESHOLD',
    type=int,
    help='''\
set the threshold temperature at which Metis will emit a warning. This warning
can be seen using the axlogdevice command.
''',
)

parser.add_argument(
    '--set-power-limit',
    metavar='LIMIT',
    type=float,
    help='''\
set power limit in watts. If the device detects that it is exceeding this limit then
the power consumption is restricted by reducing AI core performance.
Example:
  %(prog)s --set-power-limit 22.3     # enable the limiter at 22.3W
  %(prog)s --set-power-limit 0        # disable the limiter
''',
)

parser.add_argument(
    '--devices',
    '-d',
    type=str,
    help='''\
select device/devices to configure. Identifiers can be zero-based index,
e.g. -d0,1 or by name, e.g. -dmetis-0:1:0.

Run axdevice without parameters to enumerate available devices.

By default all devices available will be used.
''',
)
_refresh_ops = parser.add_mutually_exclusive_group()
_refresh_ops.add_argument(
    '--reload-firmware', action='store_true', help='reload firmware for Axelera PCIE/M.2 devices'
)
_refresh_ops.add_argument(
    '--pcie-rescan',
    action='store_true',
    help='''\
remove all Axelera PCIE/M.2 devices as well as all bridges that the devices are
behind of as long as the bridges are not shared with other non-Axelera devices.
Then provoke a rescan.

ONLY removes bridges that Axelera devices are behind of IF all devices behind
the bridge are Axelera devices.  Consider using --force-pcie-remove-bridge if
this is not the case on your system, but proceed with caution.
''',
)
_refresh_ops.add_argument(
    '--pcie-scan', action='store_true', help='list all Axelera PCIE/M.2 devices'
)
_refresh_ops.add_argument(
    '--refresh', action='store_true', help='run --pcie-rescan and --reload-firmware'
)
_refresh_ops.add_argument('--reboot', action='store_true', help='reboot the device')

parser.add_argument('--synopsys', action='store_true', help=argparse.SUPPRESS)
parser.add_argument(
    '--force-pcie-remove-bridge',
    nargs='?',
    const='auto',
    metavar='BRIDGE',
    help='''\
when used in conjunction with --refresh or --pcie-rescan, remove PCIE bridges
with Axelera devices behind them even if the bridges are shared with other
non-Axelera devices.

For cases where the relevant PCIE bridges cannot be determined automatically,
the location of one bridge can be passed as an optional argument in BDF
notation, e.g., --force-pcie-remove-bridge '0000:02:00.0'.

WARNING: If the automatically determined or manually specified PCIE bridges are
shared with other devices, this will temporarily remove them, so please use
with care.
''',
)

parser.add_argument(
    '--verbose',
    '-v',
    action='count',
    default=0,
    help='increase verbosity, use multiple times for more output',
)

parser.add_argument(
    '--report',
    nargs='?',
    const='archive',
    choices=['archive', 'console'],
    metavar='MODE',
    help=argparse.SUPPRESS,
)


def _per_core(core_values: list[str | int], unit) -> str:
    '''Return a string representation of the per core values.

    >>> _per_core([50, 50, 50, 100], '%')
    '0-2:50%,3:100%'
    >>> _per_core([800, 800, 800, 800], 'MHz')
    '0-3:800MHz'
    '''
    bits = []
    for value, c_values in itertools.groupby(enumerate(core_values), key=lambda x: x[1]):
        cores = [core for core, _ in c_values]
        expr = f"{cores[0]}" if len(cores) == 1 else f"{cores[0]}-{cores[-1]}"
        bits.append(f"{expr}:{value}{unit}")

    return ','.join(bits)


def _format_throttling(val: str | None) -> str:
    '''Format the throttling configuration.

    >>> _format_throttling('200:5:12')
    '200°C, hysteresis 5°C, throttle rate:12%'
    >>> _format_throttling('200:5')
    '200°C, hysteresis 5°C'
    >>> _format_throttling('200')
    '200'
    >>> _format_throttling(None)
    'unavailable'
    '''
    if val is None:
        return "unavailable"

    parts = val.split(':', 2)
    if len(parts) == 3:
        t, h, throttle_rate = parts
        return f"{t}°C, hysteresis {h}°C, throttle rate:{throttle_rate}%"
    elif len(parts) == 2:
        t, h = parts
        return f"{t}°C, hysteresis {h}°C"
    return val


def _format_pvt_warning_threshold(cfg: dict[str, str]) -> str:
    '''Format the PVT warning threshold configuration.

    >>> _format_pvt_warning_threshold({'pvt_warning_threshold': '70'})
    '70°C'
    >>> _format_pvt_warning_threshold({})
    'unavailable'
    '''
    try:
        val = cfg['pvt_warning_threshold']
    except KeyError:
        return "unavailable"

    return f"{val}°C"


def _format_power(val: str | None) -> str:
    '''Format the power limit.

    >>> _format_power(None)
    'off'
    >>> _format_power('0')
    'off'
    >>> _format_power('0.0')
    'off'
    >>> _format_power('12.2')
    '12.2W'
    >>> _format_power('25.0')
    '25.0W'
    '''
    if val is None:
        return 'off'
    try:
        v = float(val)
    except ValueError:
        return 'off'
    return 'off' if v == 0 else f'{v}W'


def _format_ddr(ddr_size_bytes: int) -> str:
    '''Format the DDR size.

    >>> _format_ddr(0)
    '0'
    >>> _format_ddr(2 * 1024**3)
    '2GiB'
    >>> _format_ddr(1024**3 + 3)
    '1GiB (+ 0x3 bytes)'
    '''
    if ddr_size_bytes == 0:
        return "0"
    gib, bytes = ddr_size_bytes // (1024**3), ddr_size_bytes % (1024**3)
    extra = f" (+ 0x{bytes:x} bytes)" if bytes else ""
    return f"{gib}GiB{extra}"


_DISPLAY_NAMES = {
    ('n/a', 1): 'part of 4-metis-pcie',
    ('aisbc', 1): 'metis-compute-board',
    ('antelao', 1): 'metis-compute-board',
    ('matterhorn', 1): 'pcie',
    ('matterhorn', 2): 'pcie-r2',
    ('ortles', 1): 'm2',
    ('ortles', 2): 'std-temp m2-max',
}


def _device_display_name(d: DeviceInfo) -> str:
    type_rev = (d.board_controller_board_type.lower(), d.board_revision)
    return _DISPLAY_NAMES.get(type_rev, d.board_type.name)


def print_device_info(
    context: objects.Context,
    found_devices: list[DeviceInfo],
    show_extended_flash_info: bool,
    show_thermals: bool,
):
    for n, d in enumerate(found_devices):
        if d.board_type == BoardType.unknown:
            print(f"Device {n}: {d.name} board_type={d.board_type.name} (not responding)")
            continue
        max_cores = d.subdevice_count
        cfg = context.read_device_configuration(d)
        clock = f" clock={cfg.get('clock_profile', 0)}MHz("
        clock += _per_core(
            [cfg.get(f'clock_profile_core_{n}', '0') for n in range(max_cores)], 'MHz'
        )
        clock += ')'
        mvm = _per_core([cfg.get(f'mvm_utilisation_core_{n}', '0') for n in range(max_cores)], '%')
        mvm = f' mvm={mvm}'
        power = f' power={_format_power(cfg.get("power_limit"))}'

        flver = d.flashed_firmware_version
        bcver = d.board_controller_firmware_version
        # FIXME: Slight hack to avoid separate AxRuntime board type for Monviso.
        #        See SDK-7283.
        bcver_info = f" bcver={bcver}" if bcver != "N/A" else ""
        display = _device_display_name(d)
        print(
            f"Device {n}: {d.name} {_format_ddr(d.max_memory)} {display} flver={flver}{bcver_info}{clock}{mvm}{power}"
        )
        if show_extended_flash_info:
            print(f"  name={d.name}")
            print(f"  device_runtime_firmware={d.firmware_version}")
        if show_extended_flash_info and d.board_controller_board_type:
            # For verbose mode, also show the original board type
            print(f"  board_controller_board_type={d.board_controller_board_type}")
        if show_thermals:
            print(f"  sw_throttling: {_format_throttling(cfg.get('sw_throttling'))}")
            print(f"  hw_throttling: {_format_throttling(cfg.get('hw_throttling'))}")
            print(f"  freq_downscaling: {_format_throttling(cfg.get('freq_downscaling'))}")
            print(f"  pvt_warning_threshold: {_format_pvt_warning_threshold(cfg)}")


def _file_contents(file: Path) -> str | None:
    try:
        return file.read_text()
    except Exception:
        return None


class CommandResult(NamedTuple):
    returncode: int
    stdout: str
    stderr: str


def _run_command(
    command: str, cwd: str | None = None, timeout: int | None = None
) -> CommandResult | None:
    try:
        res = subprocess.run(
            command.split(' '), capture_output=True, text=True, cwd=cwd, timeout=timeout
        )
        return CommandResult(returncode=res.returncode, stdout=res.stdout, stderr=res.stderr)
    except subprocess.TimeoutExpired as e:
        return CommandResult(
            returncode=-1,
            stdout=(e.stdout.decode('ascii') if e.stdout else ""),
            stderr=(e.stderr.decode('ascii') if e.stderr else ""),
        )
    except Exception as e:
        LOG.debug(f"Running '{command}' failed: {e}")
        return None


class Report:
    indent_width: int = 2
    indent_level: int = 0
    report: str = ""

    def add(self, s: str, additional_indent: bool = True, preserve_whitespace=False):
        for i, line in enumerate(s.split("\n")):
            if additional_indent:
                indent = self.indent_level if i == 0 else self.indent_level + 1
            else:
                indent = self.indent_level

            line_content = line if preserve_whitespace else line.strip()
            self.report += (' ' * self.indent_width * indent) + line_content + "\n"

    def add_section(self, s: str, underline: bool = True):
        self.add(s, False)
        if underline:
            c = '=' if self.indent_level == 0 else '-'
            self.add((c * len(s.strip())), False)
        self.indent_level += 1

    def leave_section(self):
        self.report += "\n"
        self.indent_level -= 1

    def __str__(self) -> str:
        return self.report


def collect_issue_report_info() -> str:  # noqa: C901
    kernel_log = None
    report = Report()

    report.add_section(
        f"Information collected at {datetime.utcnow().strftime('%Y-%m-%d - %H:%M:%S')} (UTC)"
    )
    report.leave_section()

    report.add_section("Basic host system information:")
    uname = platform.uname()
    report.add(f"Hostname: {uname.node}")
    report.add(f"Operating System: {uname.system} {uname.release} {uname.version}")
    if platform.system() == 'Linux':
        if (res := _run_command('uptime')) and res.returncode == 0:
            report.add(f"Uptime: {res.stdout}")
        try:
            d = platform.freedesktop_os_release()
            report.add_section("Additional Linux information:", False)
            for k, v in d.items():
                report.add(f"{k}: {v}")
            report.leave_section()
        except OSError:
            pass
    elif platform.system() == 'Windows':
        win_ver = platform.win32_ver()
        report.add(' '.join(str(v) for v in win_ver if v))
    elif platform.system() == 'Darwin':
        mac_ver = platform.mac_ver()
        report.add(' '.join(str(v) for v in mac_ver if v))
    report.add(f"Host hardware architecture: {uname.machine} ({uname.processor})")
    try:
        import psutil

        report.add(f"RAM: {round(psutil.virtual_memory().total / (1024**3))} GiB")
    except ModuleNotFoundError:
        pass
    report.leave_section()

    report.add_section("Runtime environment:")
    for k, v in os.environ.items():
        report.add(f"{k}: {v}")
    report.leave_section()

    # Mainly useful for SDK installations
    if platform.system() == 'Linux':
        report.add_section("Axelera package information:")
        if (res := _run_command("dpkg -l axelera-*")) and res.returncode == 0:
            report.add(res.stdout, False)
        if (res := _run_command("dpkg -l metis-*")) and res.returncode == 0:
            report.add(res.stdout, False)
        if (res := _run_command("dpkg -l riscv-*")) and res.returncode == 0:
            report.add(res.stdout, False)
        report.leave_section()

    report.add_section("Axelera wheels:")
    if (res := _run_command("pip list")) and res.returncode == 0:
        axelera = '\n'.join([ln for ln in res.stdout.split("\n") if "axelera" in ln.lower()])
        report.add(axelera, False)
    report.leave_section()

    # Should be set in containers and containerless, but not for SDK installations
    if axe_chroot := os.getenv("AXE_CHROOT"):
        report.add_section("Software-platform git version:")
        cwd = Path(axe_chroot).parent.parent.parent
        if (res := _run_command('git rev-parse HEAD', cwd=cwd)) and res.returncode == 0:
            report.add(f"software-platform version {res.stdout}")
        if (res := _run_command('git status', cwd=cwd)) and res.returncode == 0:
            report.add_section("software-platform git status:", False)
            report.add(res.stdout, False)
            report.leave_section()
        report.leave_section()

    report.add_section("Host-side Metis-specific information:")
    if platform.system() == 'Linux':
        metis_path = Path('/sys/class/metis')
        if version := _file_contents(metis_path / 'version'):
            report.add(f"Metis driver version: {version}")
        else:
            report.add("Metis driver not loaded")

        have_passwordless_sudo = (res := _run_command('sudo -n true')) and res.returncode == 0
        if have_passwordless_sudo and (res := _run_command('sudo lspci -vvv -d 1f9d::')):
            report.add_section("PCI information (via sudo):")
            report.add(res.stdout, additional_indent=False, preserve_whitespace=True)
            report.leave_section()
        elif res := _run_command('lspci -vvv -d 1f9d::'):
            report.add_section("PCI information (without sudo):")
            report.add(res.stdout, additional_indent=False, preserve_whitespace=True)
            report.leave_section()

        if (
            have_passwordless_sudo
            and (res := _run_command('sudo dmesg -H'))
            and res.returncode == 0
        ):
            kernel_log = res.stdout

    if (res := _run_command('lsusb -v -d 0403:')) and res.returncode == 0:
        interesting = ['idVendor', 'idProduct', 'iManufacturer', 'iProduct', 'iSerial']

        report.add_section("Debug board information:")
        for line in res.stdout.split("\n"):
            for i in interesting:
                if i in line:
                    report.add(line)
        report.leave_section()
    report.leave_section()

    report.add_section("Metis device information:")
    with objects.Context() as c:
        found_devices = None
        try:
            found_devices = c.list_devices()
        except RuntimeError as e:
            report.add(f"Was not able to list devices: {e}")

        if not found_devices:
            report.add("Did not find any Metis devices")
            report.leave_section()
        else:
            report.add(
                f"Found {len(found_devices)} Metis device{'s' if len(found_devices) != 1 else ''}"
            )

            for device in found_devices:
                report.add_section(f"Device {device.name}")
                report.add(f"Firmware version: {device.firmware_version}")

                # Be very careful because the device might have rebooted
                if (
                    '-bl' in device.firmware_version
                    or '+bl' in device.firmware_version
                    or '-stage0' in device.firmware_version
                ):
                    # Bail out, cannot collect more device information
                    report.add("Device seems to have rebooted")
                    report.leave_section()
                    continue

                report.add(f"Board type: {device.board_type}")
                report.add(f"Board revision: {device.board_revision}")
                report.add(f"Board DDR: {_format_ddr(device.max_memory)}")

                config = c.read_device_configuration(device)

                report.add(f"Flashed firmware version: {device.flashed_firmware_version}")
                report.add(
                    f"Board controller firmware version: {device.board_controller_firmware_version}"
                )
                report.add(f"Board controller board type: {device.board_controller_board_type}")

                ddr_size = config.get('ddr_size')
                if ddr_size:
                    report.add(
                        f"DRAM size: {ddr_size} bytes ({round(int(ddr_size) / 1024**2)} MiB)"
                    )
                else:
                    report.add("DRAM size: could not query")

                report.add_section("Firmware configuration:")
                report.add(f"Clock profile: {config.get('clock_profile', 'unavailable')}")
                for aicore_id in range(0, 4):
                    mvm_util = config.get(f"mvm_utilisation_core_{aicore_id}", "unavailable")
                    report.add(f"MVM utilization for AI core {aicore_id}: {mvm_util}")
                    profile = config.get(f"clock_profile_core_{aicore_id}", "unavailable")
                    report.add(f"Clock profile AI core {aicore_id}: {profile}")
                report.add(f"SW throttling: {_format_throttling(config.get('sw_throttling'))}")
                report.add(f"HW throttling: {_format_throttling(config.get('hw_throttling'))}")
                report.add(
                    f"Frequency downscaling: {_format_throttling(config.get('freq_downscaling'))}"
                )
                report.add(f"PVT warning threshold: {_format_pvt_warning_threshold(config)}")
                report.leave_section()

                report.add_section("Device logs:")
                if res := _run_command(
                    f"axlogdevice --peek --device {device.name} --slog", timeout=3
                ):
                    report.add_section("SYS_CTRL log:")
                    report.add(res.stdout, False)
                    report.leave_section()
                else:
                    report.add("Retrieving SYS_CTRL log failed")

                if '-stage0' in device.firmware_version:
                    # AI core logs don't make sense to collect from a stage0 firmware
                    report.leave_section()
                    report.leave_section()
                    continue

                for aicore_id in range(0, 4):
                    if res := _run_command(
                        f"axlogdevice --peek --device {device.name} --alog {aicore_id}", timeout=3
                    ):
                        report.add_section(f"AI core {aicore_id} log:")
                        report.add(res.stdout, False)
                        report.leave_section()
                    else:
                        report.add(f"Retrieving AI core {aicore_id} log failed")
                report.leave_section()

                report.leave_section()  # Device finished

    return str(report), kernel_log


def report(args, extras):
    timestamp = datetime.utcnow().strftime('%Y-%m-%d_%H_%M_%S')

    report, kernel_log = collect_issue_report_info()
    if args.mode == 'archive':
        with tempfile.TemporaryDirectory() as tmpdirname:
            with (Path(tmpdirname) / f"report-{timestamp}.txt").open('w') as f:
                f.write(report)
            if kernel_log:
                with (Path(tmpdirname) / f"kernel-log-{timestamp}.txt").open('w') as f:
                    f.write(kernel_log)

            # Handle that the working directory may not be writable
            path = ""
            if not os.access('.', os.W_OK):
                path = tempfile.gettempdir() + "/"

            filename = shutil.make_archive(f"{path}report-{timestamp}", 'zip', tmpdirname)

            print(f"\n\nWrote report to {filename}")
            print("If you create a ticket, please attach this file.\n")
    else:
        print("\n\nReport:\n")
        print(report)
        if kernel_log:
            print("\n\nKernel log:\n")
            print(kernel_log)
        print("=" * 80)
        print(
            "If you create a ticket, please run `axdevice report` and attach the produced file.\n"
        )


def main(args, extras):  # noqa: C901 - complexity ok; the entire application by design
    '''handle and act on arguments.'''
    utils.configure_logging(args.verbose)

    if args.report:
        args.mode = args.report
        return report(args, extras)

    if extras:
        parser.error(f"unrecognized arguments: {' '.join(extras)}")

    if args.pcie_rescan or args.pcie_scan or args.refresh:
        _is_scan_include_synopsys = (
            args.synopsys or os.getenv("AXELERA_AXDEVICE_SCAN_FOR_SYNOPSYS", "0") == "1"
        )

        scanner = get_pci_scanner(
            scan_for_synopsys=_is_scan_include_synopsys,
            force_remove_bridge=args.force_pcie_remove_bridge,
        )

        scan_fn = scanner.scan if args.pcie_scan else scanner.rescan
        for loc, desc in scan_fn():
            print(f"{loc} : {desc}")

    with objects.Context() as c:
        found_devices = c.list_devices()
        devices = select_devices(found_devices, args.devices)
        max_cores = min(d.subdevice_count for d in devices)
        if not all(d.subdevice_count == max_cores for d in devices):
            LOG.warning("Selected devices have differing number of cores")

        configures = {}
        if args.set_clock:
            configures['clock_profile'] = args.set_clock
        if args.set_mvm_limitation:
            for core, value in _core_mvm_pairs(args.set_mvm_limitation, max_cores):
                configures[f'mvm_utilisation_core_{core}'] = value
        if args.set_core_clock:
            for core, value in _core_clock_pairs(args.set_core_clock, max_cores):
                configures[f'clock_profile_core_{core}'] = value
        if args.set_sw_throttling:
            configures['sw_throttling'] = args.set_sw_throttling
        if args.set_hw_throttling:
            configures['hw_throttling'] = args.set_hw_throttling
        if args.set_freq_downscaling:
            configures['freq_downscaling'] = args.set_freq_downscaling
        if args.set_pvt_warning_threshold:
            configures['pvt_warning_threshold'] = args.set_pvt_warning_threshold
        if args.set_power_limit is not None:
            configures['power_limit'] = str(args.set_power_limit)
        if args.reboot:
            configures['reboot'] = True

        if args.reload_firmware or args.refresh or args.reboot:
            configures["device_firmware"] = "force"
        elif configures:
            # this ensures we have fw loaded if setting any of the above options, which all
            # require non stage0 or bl fw.
            configures["device_firmware"] = "1"

        if configures:
            ready = [c.configure_device(d, **configures) for d in devices]
            if not all(ready):
                title = f"Configuring {', '.join(d.name for d in devices)}"
                bar_opts = {'spinner': 'dots', 'bar': None, 'receipt': False}
                with alive_progress.alive_bar(title=title, **bar_opts):
                    while not all(c.device_ready(d) for d in devices):
                        time.sleep(0.3)
            found_devices = c.list_devices()

        therm = (
            args.set_sw_throttling
            or args.set_hw_throttling
            or args.set_pvt_warning_threshold
            or args.set_freq_downscaling
        )
        print_device_info(c, found_devices, args.verbose > 0, args.verbose > 0 or therm)


def _axtool(subparsers, tool):
    '''create a subcommand that forwards arguments to another tool.'''

    def _tool(args, extras):
        args = [f'ax{tool}'] + extras
        return subprocess.run(args, shell=True).returncode

    sub = subparsers.add_parser(tool, help=f'Run ax{tool} tool with arguments', add_help=False)
    sub.set_defaults(func=_tool)


subparsers = parser.add_subparsers(help='Sub commands')
_axtool(subparsers, 'mem')
_axtool(subparsers, 'dma')
_axtool(subparsers, 'cmd')
_axtool(subparsers, 'trace')

reportp = subparsers.add_parser(
    'report', help='collect information for an issue report [archive (default) or console'
)
reportp.add_argument(
    'mode',
    nargs='?',
    default='archive',
    choices=['archive', 'console'],
    help='report mode [archive (default) or console]',
)
reportp.set_defaults(func=report)
parser.set_defaults(func=main)


def entrypoint_main() -> int:
    '''setuptools entry point for the script.'''
    args, extras = parser.parse_known_args()
    try:
        result = args.func(args, extras)
        return result if result is not None else 0
    except Exception as e:
        if args.verbose:
            raise
        print(f'ERROR: {e}', file=sys.stderr)
        return 1


if __name__ == '__main__':
    sys.exit(entrypoint_main())
