#!/usr/bin/env python3
#
# Copyright (c) 2025 Axelera AI. All rights reserved.
#
from __future__ import annotations

import argparse
import importlib.metadata
import pathlib
import re
import sys

parser = argparse.ArgumentParser(description='Get Axelera Runtime or Device Driver version')
parser.add_argument(
    '--driver', action='store_true', help='Get device driver version instead of runtime version'
)


def _with_rc(v, rc):
    return f'{v}-{rc}' if rc else v


def driver_version() -> str:
    '''Returns the version of the Axelera Metis device driver.'''
    p = pathlib.Path('/sys/class/metis/version')
    if not p.exists():
        raise RuntimeError("Device driver not loaded")

    return p.read_text().strip()


def version() -> str:
    '''Returns the version of the axelera-runtime package.'''
    try:
        v = importlib.metadata.version('axelera-runtime')
    except importlib.metadata.PackageNotFoundError as e:
        err = f"Failed to find python package axelera-runtime: {e}"
        raise RuntimeError(err)
    m = re.match(r'^(\d+\.\d+\.\d+)-?((rc|a)\d+)?', v)
    if not m:
        err = f"Failed to parse version ({v}) of python package axelera-runtime"
        raise RuntimeError(err)
    return _with_rc(m.group(1), m.group(2))


def entrypoint_main() -> int:
    """Entry point for axversion command."""
    args = parser.parse_args()
    getter = driver_version if args.driver else version
    try:
        print(getter())
        return 0
    except Exception as e:
        print(str(e))
        return 1


if __name__ == "__main__":
    sys.exit(entrypoint_main())
