# Copyright Axelera AI, 2025
"""
PCIe scan utilities for Axelera devices.

Supports Linux and Windows platforms.
"""
from __future__ import annotations

import ctypes
import logging
import os
import platform
import re
import subprocess
import time
from abc import ABC, abstractmethod
from pathlib import Path

_AXELERA_VENDOR_ID = '1f9d'
_SYNOPSYS_VENDOR_ID = '16c3'

LOG = logging.getLogger(__name__)


class PciScannerBase(ABC):
    def __init__(self, scan_for_synopsys=False, force_remove_bridge=None):
        self.scan_for_synopsys = scan_for_synopsys
        self.force_remove_bridge = force_remove_bridge

    @abstractmethod
    def scan(self) -> list[tuple[str, str]]:
        '''Scan the system for Axelera devices.
        Return list of (location, description) tuples.
        '''

    @abstractmethod
    def rescan(self) -> list[tuple[str, str]]:
        '''Rescan the system for Axelera devices, removing the PCIe bridge if necessary.
        Return list of (location, description) tuples.
        '''


class LinuxPciScanner(PciScannerBase):
    def _exec(self, cmd):
        '''run a command and return the output.'''
        out = subprocess.run(cmd, stdout=subprocess.PIPE, check=True, text=True, shell=True)
        LOG.debug(f"exec: {cmd} -> {out.stdout}")
        return out.stdout

    def _determine_bridge(self, loc: str) -> str | None:
        '''Returns the location of a PCIe bridge that a given device is behind of.

        Location of device and bridge given in BDF notation as strings.
        Returns None if bridge cannot be determined.
        '''

        bus = ':'.join(loc.split(':')[:2])
        bridge = self._exec(f"ls -ld /sys/bus/pci/devices/*/pci_bus/{bus} 2> /dev/null || true")
        m = re.match(r'.*/devices/(.*)/pci_bus/.*', bridge)
        return m.group(1) if m else None

    def _devices_behind_bridge(self, bridge: str) -> list[str]:
        '''Returns the locations of all devices behind a given bridge.

        Location of bridge and devices given in BDF notation as strings.
        '''

        bridge_dir = f"/sys/bus/pci/devices/{bridge}/"
        device_pattern = re.compile(
            r"^[0-9a-f]{4}:[0-9a-f]{2}:[0-9a-f]{2}\.[0-9a-f]$"
        )  # Like 0000:00:00.0
        return [
            entry
            for entry in os.listdir(bridge_dir)
            if os.path.isdir(os.path.join(bridge_dir, entry)) and device_pattern.match(entry)
        ]

    def scan(self) -> list[tuple[str, str]]:
        out = self._exec([f'lspci -D -nn -d {_AXELERA_VENDOR_ID}::'])
        if self.scan_for_synopsys:
            out += self._exec([f'lspci -D -nn -d {_SYNOPSYS_VENDOR_ID}::'])

        location = r'[0-9a-f]+:[0-9a-f]+:[0-9a-f]+\.[0-9a-f]'
        devices = re.findall(rf'({location}) [^:]+: ([^[]+)\[[0-9a-f]+:[0-9a-f]+\]', out)
        return [(loc, desc.strip()) for loc, desc in devices]

    def rescan(self) -> list[tuple[str, str]]:
        # check that no processes use Metis before proceeding with removing bridges,
        # otherwise it could disrupt running applications
        try:
            result = subprocess.run(
                "sudo lsof /dev/metis*",
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                shell=True,
                check=False,
            )
        except Exception as e:
            raise RuntimeError(f"Unexpected issue while checking if Metis is in use: {e}")

        processes = result.stdout.splitlines()
        if processes:
            msg = (
                "PCIe rescan rejected: one or more processes are using Metis. Please stop them and retry.\n"
                "Processes using Metis device(s):\n" + "\n".join(processes)
            )
            raise RuntimeError(msg)

        devices = self.scan()
        if not devices:
            if self.force_remove_bridge:
                if self.force_remove_bridge == 'auto':
                    LOG.info(
                        "Could not find any Axelera devices to remove bridge for, will only rescan."
                    )
            else:
                LOG.info("No Axelera devices found, will only rescan.")

        if self.force_remove_bridge and self.force_remove_bridge != 'auto':
            # adhere to user bridge removal request, independent of whether devices were found
            bridge = self.force_remove_bridge
            LOG.warning(f"Removing manually requested PCIE bridge {bridge}")
            self._exec(f"echo 1 | sudo tee /sys/bus/pci/devices/{bridge}/remove")

        all_device_locs = set([loc for loc, _ in devices])
        for loc, desc in devices:
            removed_bridge = False
            if bridge := self._determine_bridge(loc):
                # bridge is safe to remove if all devices behind the bridge are Axelera devices
                is_safe_to_remove = set(self._devices_behind_bridge(bridge)).issubset(
                    all_device_locs
                )
                if is_safe_to_remove or self.force_remove_bridge:
                    log = LOG.info if is_safe_to_remove else LOG.warning
                    log(f"Removing PCIE bridge {bridge}")
                    self._exec(f"echo 1 | sudo tee /sys/bus/pci/devices/{bridge}/remove")
                    removed_bridge = True
                else:
                    LOG.info(
                        f"Not removing PCIE bridge {bridge}: unsafe to remove and force option not given"
                    )

            if not removed_bridge:
                # if we couldn't find the bridge or couldn't safely remove it, just remove the device
                # and rescan later.
                LOG.info(f"Could not determine or safely remove bridge for {loc}")
                file = f"/sys/bus/pci/devices/{loc}/remove"
                if os.path.exists(file):
                    LOG.info(f"Removing {loc} : {desc}")
                    self._exec(f"echo 1 | sudo tee {file}")

        time.sleep(1)
        # kernel driver removal is intentionally done after PCIe bridge/device removal.
        # this is needed for Lenovo platforms.
        self._exec("sudo modprobe -r metis || true")
        LOG.info("PCIE rescan")
        time.sleep(1)
        self._exec("echo 1 | sudo tee /sys/bus/pci/rescan")
        # delete the metis_is_legacy file to force a re-evaluation of whether it is a legacy device
        # although the runtime does not use this file anymore, continue to remove it for one version
        # to avoid some confusion
        cache = Path(os.environ.get("XDG_CACHE_HOME", os.path.expanduser("~/.cache")))
        cache = cache / "axelera" / "metis_is_legacy"
        cache.unlink(missing_ok=True)
        return self.scan()


class WindowsPciScanner(PciScannerBase):
    def _is_admin(self) -> bool:
        """Check if running as administrator"""
        try:
            is_admin = ctypes.windll.shell32.IsUserAnAdmin()
            return is_admin
        except Exception:
            return False

    def _get_device_filter(self):
        axl_filter = f"$_.InstanceId -like '*{_AXELERA_VENDOR_ID}*'"
        syn_filter = f"$_.InstanceId -like '*{_SYNOPSYS_VENDOR_ID}*'"
        dev_filter = f"{axl_filter} -or {syn_filter}" if self.scan_for_synopsys else axl_filter
        return dev_filter

    def _exec(self, cmd) -> str:
        """Execute a command and return its output"""
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            creationflags=subprocess.CREATE_NO_WINDOW,
        )
        if result.returncode != 0:
            LOG.error(f"Command failed: {cmd}\nError: {result.stderr}")
            return ""
        return result.stdout

    def _exec_ps(self, cmd, needs_admin=False) -> str:
        """Execute a PowerShell command and return its output"""
        if self._is_admin() or not needs_admin:
            # Already running as admin, execute directly
            return self._exec(
                ["powershell.exe", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", cmd]
            )

        # Not running as admin, execute with admin privileges
        return self._exec_ps_as_admin(cmd)

    def _exec_ps_as_admin(self, cmd) -> str:
        """Execute a PowerShell command as administrator"""

        # Escape for Start-Process
        escaped_cmd = cmd.replace("'", "''").replace('"', '`"')

        elevation_cmd = f"""
        Start-Process powershell.exe -ArgumentList '-NoProfile -NonInteractive -WindowStyle Hidden -ExecutionPolicy Bypass -Command \"{escaped_cmd}\"' -Verb RunAs -WindowStyle Hidden -Wait
        """
        out = self._exec_ps(elevation_cmd, False)
        print(out)
        return out

    def scan(self) -> list[tuple[str, str]]:
        dev_filter = self._get_device_filter()
        cmd = f"""
        $devices = Get-PnpDevice | Where-Object {{ {dev_filter} }}
        if ($devices) {{
            foreach ($device in $devices) {{
                Write-Host "$($device.InstanceId) $($device.FriendlyName)"
            }}
        }}
        """

        out = self._exec_ps(cmd)
        devices = re.findall(r'(\S+)\s+(.*)', out)
        return [(loc, desc.strip()) for loc, desc in devices]

    def rescan(self) -> list[tuple[str, str]]:
        if self.force_remove_bridge:
            LOG.warning("Removing the bridge is not supported on Windows, ignoring the option.")

        devices = self.scan()
        if not devices:
            LOG.info("No Axelera devices found, will only rescan.")

        # Batch admin commands to avoid multiple UAC prompts
        cmd = []
        cmd.append("pnputil /scan-devices")

        if devices:
            dev_filter = self._get_device_filter()
            cmd.append(
                f"""
            $devices = Get-PnpDevice | Where-Object {{ {dev_filter} }}
            if ($devices) {{
                Disable-PnpDevice -InstanceId $devices.InstanceId -Confirm:$false;
                Start-Sleep -Seconds 2;
                Enable-PnpDevice -InstanceId $devices.InstanceId -Confirm:$false;
            }}
            """
            )

        LOG.info("PCIE rescan")
        self._exec_ps('\n'.join(cmd), True)
        return self.scan()


def get_pci_scanner(scan_for_synopsys=False, force_remove_bridge=None):
    """Factory function to get the appropriate PCIe scanner for the current OS.

    Args:
        scan_for_synopsys: Whether to include Synopsys devices in the scan
        force_remove_bridge: Whether to force remove the PCIe bridge

    Returns:
        Platform-specific PCIe scanner instance
    """
    system = platform.system()

    scanner_map = {
        'Linux': LinuxPciScanner,
        'Windows': WindowsPciScanner,
    }

    try:
        scanner = scanner_map[system]
    except KeyError:
        raise RuntimeError(f"PCIE scan and rescan are not supported on {system}") from None
    else:
        return scanner(
            scan_for_synopsys=scan_for_synopsys, force_remove_bridge=force_remove_bridge
        )
