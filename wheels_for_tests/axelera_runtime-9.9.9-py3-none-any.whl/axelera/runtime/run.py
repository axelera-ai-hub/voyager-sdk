#
# Copyright (c) 2025 Axelera AI. All rights reserved.
#
from __future__ import annotations

import argparse
import collections
import contextlib
import dataclasses
import itertools
import logging
import mmap
import queue
import sys
import threading
import time
import traceback
from pathlib import Path

import numpy as np

from .dma_buf_allocator import DmaBufAllocator
from .objects import TRACE, Context, TensorInfo, _getLogger, select_devices  # noqa
from .utils import AipuTracer, HostTracer, ThreadedTracerAdapter

LOG = _getLogger(__name__)

_WIN32 = sys.platform == 'win32'


parser = argparse.ArgumentParser(
    description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter
)


def _enable_disable(parser, name, description, default=True):
    g = parser.add_mutually_exclusive_group()
    enable_default = ' (default)' if default else ''
    disable_default = ' (default)' if not default else ''
    g.add_argument(
        f"--{name}",
        action='store_true',
        default=default,
        help=f"Enable {description} {enable_default}",
    )
    g.add_argument(
        f"--no-{name}",
        dest=name.replace('-', '_'),
        action='store_false',
        default=not default,
        help=f"Disable {description} {disable_default}",
    )


parser.add_argument("path", type=str, help="Path to model to test")
parser.add_argument("--seconds", type=int, default=10, help="Number of seconds to run for")
parser.add_argument("--aipu-cores", type=int, default=4, help="Number of AIPU cores to use")
parser.add_argument(
    "--throttle-fps",
    type=int,
    default=0,
    help="Maximum FPS to run at, sleep will be used to throttle system fps (default: no throttle)",
)
_enable_disable(parser, "double-buffer", "double buffering")
dmabuf_default = not _WIN32
_enable_disable(parser, "input-dmabuf", "use of input dmabufs", dmabuf_default)
_enable_disable(parser, "output-dmabuf", "use of output dmabufs", dmabuf_default)
parser.add_argument(
    '--explore-latency',
    action='store_true',
    help='''Run the model with different configurations to explore the effect of latency increasing options
on performance.  This includes enabling disabling double buffering and output dmabufs, and all
available batch sizes are used (run with axrunmodel modelname rather than a path to a model.json).''',
)
parser.add_argument(
    "-v",
    "--verbose",
    default=0,
    action="count",
    help="be more verbose; use repeatedly for more info",
)
chart = parser.add_mutually_exclusive_group()
for show in ['bar chart', 'histogram']:
    opt = f"--show-{show.replace(' ', '-')}"
    help = f"Show {show} of frame fps"
    chart.add_argument(opt, dest='show_chart', action='store_const', const=show, help=help)
chart.set_defaults(show_chart=False)

parser.add_argument(
    "-d",
    "--devices",
    type=str,
    default='',
    help="Select one or more devices to run on, by default run on all available devices",
)


def _validate_template(template: str) -> str:
    try:
        template % 0
    except Exception:
        raise argparse.ArgumentTypeError("must contain one %d or %02d pattern for expansion")
    else:
        return template


parser.add_argument(
    "--save-output-tensors",
    type=_validate_template,
    default=None,
    help="Save first frame output tensors to numpy files using format string (e.g., 'output%%02d.npy' -> output00.npy, output01.npy, ...)",
)
parser.add_argument(
    "--input-tensors",
    type=_validate_template,
    default=None,
    help="Load custom input tensors from numpy files using format string (e.g., 'input%%02d.npy' -> input00.npy, input01.npy, ...)",
)


def _preproc(info: TensorInfo, pad_value: int | None = None, input_file: Path | None = None):
    if input_file is not None:
        data = np.load(input_file)
        if data.shape != info.shape:
            raise ValueError(
                f"Input file {input_file} shape {data.shape} does not match expected shape {info.shape}"
            )
        if data.dtype != np.int8:
            raise ValueError(
                f"Input file {input_file} dtype {data.dtype} does not match expected dtype int8"
            )
        return data
    quantized = np.full(info.shape, info.zero_point).astype(np.int8)
    return quantized


def prepare_inputs(
    input_infos: list[TensorInfo], instances: list, input_tensor_template: str | None
):
    if input_tensor_template:
        input_tensor_paths = [Path(input_tensor_template % idx) for idx in range(len(input_infos))]
        for input_file in input_tensor_paths:
            if not input_file.exists():
                raise FileNotFoundError(f"Input tensor file not found: {input_file}")
        return [
            [
                _preproc(info, input_file=input_file)
                for info, input_file in zip(input_infos, input_tensor_paths, strict=True)
            ]
            for _ in instances
        ]
    else:
        return [[_preproc(info).copy() for info in input_infos] for _ in instances]


def save_output_tensors(outs: list, output_tensor_template: str, output_shapes: list):
    for idx, out in enumerate(outs):
        output_filename = output_tensor_template % idx
        if isinstance(out, int) and not _WIN32:
            out_array = DmaBufAllocator.as_numpy(out, output_shapes[idx], np.int8).copy()
        else:
            out_array = out.copy() if hasattr(out, 'copy') else out
        np.save(output_filename, out_array)
        LOG.info(f"Saved output tensor {idx} to {output_filename}")


class Worker:
    def __init__(self, instance):
        self.instance = instance
        self.inqueue = queue.Queue()
        self.outqueue = queue.Queue()
        self._t = threading.Thread(target=self._run)
        self._t.start()

    def join(self):
        self._t.join()

    def _run(self):
        while True:
            inputs_outputs = self.inqueue.get()
            if inputs_outputs is None:
                break
            try:
                self.instance.run(*inputs_outputs)
            except Exception as e:
                self.outqueue.put(e)
                break
            else:
                self.outqueue.put(inputs_outputs[1])


class Reader:
    def __init__(self):
        self._q = queue.Queue()
        self._stop = False
        self._t = threading.Thread(target=self._run)
        self._t.start()

    def interrupt(self):
        self._stop = True
        self._q.put(None)

    def join(self):
        self._t.join()

    def read(self, outs_shapes):
        if self._stop:
            return
        self._q.put(outs_shapes)

    def _run(self):
        if (outs_shapes := self._q.get()) is None:
            return
        outs, shapes = outs_shapes
        if isinstance(outs[0], int) and not _WIN32:
            gold = [
                DmaBufAllocator.as_numpy(o, s, np.int8) for o, s in zip(outs, shapes, strict=True)
            ]
        else:
            gold = [o.copy() for o in outs]
        while not self._stop and (outs_shapes := self._q.get()) is not None:
            for out, shape, exp in zip(outs, shapes, gold, strict=True):
                if isinstance(out, int):
                    nbytes = np.prod(shape) * 1
                    dtype = np.int8
                    with mmap.mmap(out, nbytes, mmap.MAP_SHARED, mmap.PROT_READ) as mapped:
                        mapped_array = np.frombuffer(mapped, dtype=dtype).reshape(shape)
                        np.testing.assert_equal(mapped_array, exp)
                        del mapped_array
                else:
                    np.testing.assert_equal(out, exp)


@dataclasses.dataclass
class Result:
    dev: float
    host: float
    system: float
    latency: float
    frames: int
    temp: float


class Statistics:
    def __init__(self, max_samples: int = 2000, dtype=np.float32):
        self.sample_count = 0
        self._max_samples = max_samples
        self._dtype = dtype
        self._samples = np.zeros((self._max_samples,), self._dtype)

    @staticmethod
    def _npproperty(npfunc, default=0):
        def getter(self) -> float:
            if self.sample_count == 0:
                return default
            return float(npfunc(self._samples[0 : min(self.sample_count, self._max_samples)]))

        return property(getter)

    min = _npproperty(np.min, default=float('inf'))
    max = _npproperty(np.max, default=float('-inf'))
    mean = _npproperty(np.mean, default=0.0)
    median = _npproperty(np.median, default=0.0)
    std = _npproperty(np.std, default=0.0)

    def update(self, value):
        self._samples[self.sample_count % self._max_samples] = self._dtype(value)
        self.sample_count += 1


def run_model(
    model_path: Path,
    aipu_cores: int,
    double_buffer: bool,
    input_dmabuf: bool,
    output_dmabuf: bool,
    seconds: int,
    show_chart: str,
    device_selector: str = '',
    throttle: int = 0,
    input_tensor_template: str | None = None,
    output_tensor_template: str | None = None,
) -> Result:
    latency = Statistics()
    with contextlib.ExitStack() as stack:
        ctx = stack.enter_context(Context())
        model = ctx.load_model(str(model_path))
        devices = ctx.list_devices()
        devices = select_devices(devices, device_selector)

        input_infos, output_infos = model.inputs(), model.outputs()
        output_shapes = [i.shape for i in output_infos]
        batch_size = input_infos[0].shape[0]

        num_instances = aipu_cores // batch_size
        if aipu_cores % batch_size:
            LOG.info(
                f"Number of AIPU cores ({aipu_cores}) is not a "
                f"multiple of batch size ({batch_size})"
            )
        cores_per_device = num_instances * batch_size
        executing_cores = num_instances * batch_size * len(devices)
        aipu_tracer = stack.enter_context(AipuTracer(ctx, devices, cores_per_device, show_chart))
        host_tracer = stack.enter_context(
            ThreadedTracerAdapter(HostTracer(executing_cores, show_chart), period=1.0)
        )

        connections = []
        for device in devices:
            ctx.configure_device(device, device_firmware='1')
            connections += [
                ctx.device_connect(device, batch_size, device_firmware_check=0)
                for _ in range(num_instances)
            ]
        LOG.info(
            f"Creating {len(connections)} model instances each with batch size of"
            f" {batch_size} on {len(devices)} device(s)"
        )
        instances = [
            stack.enter_context(
                c.load_model_instance(
                    model,
                    double_buffer=double_buffer,
                    input_dmabuf=input_dmabuf,
                    output_dmabuf=output_dmabuf,
                    num_sub_devices=batch_size,
                    aipu_cores=batch_size,
                )
            )
            for c in connections
        ]

        inputs = prepare_inputs(input_infos, instances, input_tensor_template)
        outputs = [[np.zeros(t.shape, np.int8) for t in output_infos] for _ in instances]
        workers = [Worker(instance) for instance in instances]
        throttle = throttle if throttle is None else throttle / batch_size

        if input_dmabuf or output_dmabuf:
            dma_allocator = DmaBufAllocator()

            def alloc(data):
                return stack.enter_context(dma_allocator.create(data))

            if input_dmabuf:
                inputs = [[alloc(i) for i in slot] for slot in inputs]

            if output_dmabuf:
                outputs = [[alloc(o) for o in slot] for slot in outputs]

        reader = Reader()

        try:
            if len(workers) == 1 and not double_buffer and not output_dmabuf:
                prefill = 0
            else:
                prefill = (1 + int(output_dmabuf)) * len(workers)
            drop = int(double_buffer) * len(workers) * 2
            LOG.info(f"Starting with {prefill=}, {drop=}, {batch_size=}, and {len(workers)=}")
            start = time.time()
            end_at = start + seconds
            frame_starts = collections.deque()
            for in_frameno in itertools.count():
                out_frameno = in_frameno - prefill
                next_available = in_frameno % len(workers)
                frame_starts.append(time.time())
                workers[next_available].inqueue.put(
                    [inputs[next_available], outputs[next_available]]
                )
                if out_frameno >= 0:
                    next_ready = out_frameno % len(workers)
                    outs = workers[next_ready].outqueue.get()
                    if isinstance(outs, Exception):
                        raise outs

                now = time.time()
                if out_frameno >= drop:
                    latency.update(now - frame_starts.popleft())
                    reader.read((outs, output_shapes))

                    if output_tensor_template:
                        save_output_tensors(outs, output_tensor_template, output_shapes)
                        output_tensor_template = ''
                if now > end_at:
                    break
                if throttle and (ahead_by := (in_frameno / throttle - (now - start))) > 0.001:
                    time.sleep(ahead_by)

        finally:
            stop = time.time()
            LOG.info("Stopping inference after %.2f seconds", stop - start)
            for worker in workers:
                worker.inqueue.put(None)
            reader.interrupt()
            for worker in workers:
                worker.join()
            reader.join()
            joined = time.time()
            LOG.info("Joined all threads after %.2f seconds", joined - stop)
    LOG.info("Closed all contexts after %.2f seconds", time.time() - joined)

    system = batch_size * out_frameno / (stop - start)
    latency_factor = 0.5 + float(batch_size) / 2
    return Result(
        aipu_tracer.value,
        host_tracer.value,
        system,
        latency.median * latency_factor,
        out_frameno * batch_size,
        aipu_tracer.core_temp,
    )


def _os_specific_args_checks(args: argparse.Namespace):
    if _WIN32 and (args.input_dmabuf or args.output_dmabuf):
        raise RuntimeError("DMABUF not supported on Windows")


def main(args: argparse.Namespace):
    levels = {0: logging.WARNING, 1: logging.INFO, 2: logging.DEBUG}
    desired = levels.get(args.verbose, TRACE)
    logging.basicConfig(level=desired)

    model_path = Path(args.path)
    if model_path.is_dir():
        model_path /= "model.json"
    if not model_path.exists():
        # try the default model path
        model_paths = []
        if maybe := '/' not in args.path:
            for n in range(1, 5):
                default = Path(f'build/{args.path}/{args.path}/{n}/model.json')
                if default.exists():
                    model_paths.append((default, f',batch-{n}'))
        if not model_paths:
            nor = f', nor does build/{args.path}/{args.path}/*/model.json exist' if maybe else ''
            raise RuntimeError(f"Model path {model_path} does not exist{nor}")
    else:
        model_paths = [(model_path, '')]
    _os_specific_args_checks(args)

    if args.explore_latency:
        configs = [
            (',sglbuf,odmabuf=0', args.aipu_cores, False, args.input_dmabuf, False),
            (',sglbuf,odmabuf=1', args.aipu_cores, False, args.input_dmabuf, True),
            (',dblbuf,odmabuf=0', args.aipu_cores, True, args.input_dmabuf, False),
            (',dblbuf,odmabuf=1', args.aipu_cores, True, args.input_dmabuf, True),
        ]
    else:
        configs = [
            ('', args.aipu_cores, args.double_buffer, args.input_dmabuf, args.output_dmabuf)
        ]

    errors = 0
    for model_path, batchname in model_paths:
        for cfgname, ncores, dblbuf, indma, outdma in configs:
            runname = f'{args.path}{batchname}{cfgname},'
            try:
                print(runname, end='', flush=True)
                r = run_model(
                    model_path,
                    ncores,
                    dblbuf,
                    indma,
                    outdma,
                    args.seconds,
                    args.show_chart,
                    args.devices,
                    args.throttle_fps,
                    args.input_tensors,
                    args.save_output_tensors,
                )
            except Exception as e:
                if model_path.parent.exists():
                    with open(model_path.parent / "errorlog.txt", "w") as f:
                        traceback.print_exc(file=f)
                if args.verbose:
                    raise
                print(f'FAIL: {e}')
                errors += 1
            else:
                if LOG.isEnabledFor(logging.INFO):
                    # if we spammed the log reprint the runname:
                    print(runname, end='')
                lat = r.latency * 1000
                print(
                    f'dev:{r.dev:.1f} host:{r.host:.1f} system:{r.system:.1f} latency:{lat:.1f}ms frames:{r.frames} temp:{r.temp}C'
                )
    return max(errors, 1)


def entrypoint_main():
    args = parser.parse_args()
    try:
        main(args)
        return 0
    except RuntimeError as e:
        if args.verbose:
            raise
        return f'ERROR: {e}'


if __name__ == '__main__':
    entrypoint_main()
