# Copyright Axelera AI, 2026
"""
Collect, configure, and display device logs and traces.

If no arguments are given the script will start collecting sysctrl and AI core logs
and wait for a Ctrl-C to exit.
"""
from __future__ import annotations

import argparse
import contextlib
import io
import logging
import signal
import sys
import threading
import typing

from . import utils
from .objects import Context, select_devices

stop_event = threading.Event()

LOG = logging.getLogger(__name__)


parser = argparse.ArgumentParser(
    prog="axlogdevice", formatter_class=argparse.RawDescriptionHelpFormatter, description=__doc__
)
parser.add_argument(
    "-d",
    "--device",
    help='''\
select device/devices to collect logs. Identifiers can be zero-based index,
e.g. -d0,1 or by name, e.g. -dmetis-0:1:0.

By default all devices available will be used.''',
)
parser.add_argument("--file", help='save logs to file instead of stdout.')
parser.add_argument(
    "--max-file-size",
    type=int,
    default=200,
    help='''\
when --file is given, exit when file size exceeds this value (in MiB).''',
)
parser.add_argument("--slog", action="store_true", help="show sysctrl log")
parser.add_argument(
    "--slog-level",
    help='''\
L[:M]   set sysctrl log level to L
  L can be err, wrn, dbg, inf, none.
  Module name M can be the name of any registered Zephyr log source.

If module name is omitted, log level setting applies to all log sources.''',
)
parser.add_argument(
    "--alog",
    help='''\
show AI core log for specified cores.

Cores can be specified as a comma-separated list of core indices and ranges, e.g.
0,2-3 to select cores 0, 2 and 3.''',
)
parser.add_argument(
    "--alog-level",
    help='''\
Cores:L[:M] set log level of AI cores to L.
  L can be err, wrn, dbg, inf, none.
  M can be megakernel, runtime.  If not specified, log level is set for both
Cores can be specified as a comma-separated list of core indices and ranges, e.g.
0,2-3 to select cores 0, 2 and 3.''',
)
parser.add_argument("--clear-buffer", action="store_true")
parser.add_argument("--peek", action="store_true")

parser.add_argument(
    '--verbose',
    '-v',
    action='count',
    default=0,
    help='increase verbosity, use multiple times for more output',
)
# Suppress all trace related options until we have cleaned up the workflow and visualisation.
parser.add_argument("--strace", action="store_true", help=argparse.SUPPRESS)
parser.add_argument("--atrace", type=int, default=None, help=argparse.SUPPRESS)
parser.add_argument("--atrace-target", default=None, help=argparse.SUPPRESS)
# only really useful for internal devs to debug the logging system itself
parser.add_argument("--dump", action="store_true", help=argparse.SUPPRESS)


def on_signal(signum, frame):
    stop_event.set()


class Emitter:
    def __init__(self, out: io.IOBase, max_file_size: int | None, show_source: bool = False):
        self.out = out
        self.max_file_size = max_file_size
        self.show_source = show_source
        self._current_size = 0
        self._isatty = out.isatty()

    def __call__(self, level: int, src: str, buffer: bytes | str, device: str = '') -> None:
        del level  # unused
        if isinstance(buffer, str) and self.show_source:
            if buf := buffer.rstrip('\n'):
                self.out.write(f"{device}{src}: ")
                self.out.write(buf.replace('\n', '\n' + f"{device}{src}: "))
                self.out.write('\n')
        else:
            self.out.write(buffer)
        if self._isatty:
            self.out.flush()
        if self.max_file_size is not None:
            self._current_size += len(buffer)
            if self._current_size >= self.max_file_size:
                LOG.debug("Reached max file size, stopping further writes")
                stop_event.set()

    def device(self, device: str) -> typing.Callable[[int, str, bytes | str], None]:
        '''Return a callable that prefixes device name to source.'''
        return lambda level, src, buffer: self(level, src, buffer, device=device + '/')


def main(args) -> None:  # noqa: C901
    utils.configure_logging(args.verbose)
    stop_event.clear()
    if args.clear_buffer and args.peek:
        LOG.warning("Specifying both --clear-buffer and --peek does not make sense.")

    if not (
        args.slog
        or args.strace
        or args.alog
        or args.atrace is not None
        or args.dump
        or args.slog_level
        or args.alog_level
    ):
        args.slog = True
        args.alog = '0-3'
        LOG.info("No log sources specified, defaulting to --slog --alog 0-3")

    with contextlib.ExitStack() as stack:
        ctx = stack.enter_context(Context())

        clear_requested = args.clear_buffer
        devices = ctx.list_devices()
        if not devices:
            raise RuntimeError("No devices found")
        devices = select_devices(devices, args.device or '')

        max_cores = min(d.subdevice_count for d in devices)
        if not all(d.subdevice_count == max_cores for d in devices):
            LOG.warning("Selected devices have differing number of cores")

        out = open(args.file, "wb") if args.file else sys.stdout

        if args.dump:
            emit = Emitter(out, args.max_file_size << 20)
            for device in devices:
                sources = ctx.device_list_log_text_sources(device)
                for src in sources:
                    s = ctx.device_get_log_stats(device, src)
                    emit(0, src, f" {device.name}/{src} ".center(80, "=") + "\n")
                    emit(0, src, s)
            return

        if args.slog_level:  # there does not seem to be a use case for --strace-level
            for device in devices:
                for cfg in args.slog_level.split(","):
                    ctx.device_set_log_level(device, "sysctrl", cfg)

        for level, suffix in [(args.alog_level, ""), (args.atrace_target, "_trace")]:
            if level:
                for device in devices:
                    _log_cfg = str  # TODO validate inf etc?
                    for n, scfg in utils.core_value_pairs(level, _log_cfg, max_cores):
                        ctx.device_set_log_level(device, f"aicore{n}{suffix}", scfg)

        sources = []
        if args.slog:
            sources.append("sysctrl")
        if args.alog:
            sources.extend(f"aicore{core}" for core in utils.core_specifier(args.alog, max_cores))
        if args.strace or args.atrace is not None:
            cmd = "strace" if args.strace else "atrace"
            if sources or (args.strace and args.atrace is not None):
                raise RuntimeError(f"Cannot combine --{cmd} with other log sources")
            sources.append("sysctrl_trace" if args.strace else f"aicore{args.atrace}_trace")
            if args.strace:
                # enable/disable strace around logging session
                for d in devices:
                    ctx.device_set_log_level(d, 'sysctrl_trace', "enable")
                    stack.callback(lambda: ctx.device_set_log_level(d, 'sysctrl_trace', "disable"))
            args.clear_buffer = True

        if sources:
            emit = Emitter(out, args.max_file_size << 20, len(sources) > 1 or len(devices) > 1)
            if args.clear_buffer:
                for d in devices:
                    for src in sources:
                        ctx.device_clear_log(d, src)
            if args.peek:
                for d in devices:
                    for src in sources:
                        emit.device(d.name)(0, src, ctx.device_peek_log(d, src))
            elif not clear_requested:
                signal.signal(signal.SIGINT, on_signal)
                signal.signal(signal.SIGTERM, on_signal)
                for d in devices:
                    ctx.device_start_logger(d, sources, emit.device(d.name))
                stop_event.wait()
                for d in devices:
                    ctx.device_stop_logger(d)


def entrypoint_main():
    try:
        args = parser.parse_args()
        main(args)
        return 0
    except RuntimeError as e:
        if args.verbose:
            raise
        return f'ERROR: {e}'


if __name__ == '__main__':
    entrypoint_main()
