# Copyright Axelera AI, 2024
# This is not currently generated but it ought to be.
from __future__ import annotations

import ctypes as _c
import os
import sys
import typing
from typing import List


def _split_env_var(env_var: str) -> List[str]:

    val = os.environ.get(env_var, "")
    return [p.strip() for p in val.split(os.pathsep) if p.strip()]


def _search_library(lib_name: str) -> str:
    """
    Search for the library `lib_name` in all available locations.
    !WARNING! This function is implemented for Linux only at the moment

    Args:
        lib_name: str. The full name of the library to load. Example: `libaxruntime.so`
    """
    # The order here matters!
    # It is priority based, with the first location having the higher priority
    search_locations = []
    base_dir = os.path.dirname(os.path.realpath(os.path.expanduser(__file__)))
    if env_dir := os.environ.get("AXELERA_RUNTIME_DIR"):
        search_locations.append(env_dir)
    search_locations.append(os.path.join(base_dir, "..", "lib"))
    search_locations.extend(_split_env_var("LD_LIBRARY_PATH"))
    search_locations.extend(_split_env_var("PATH"))
    for loc in search_locations:
        lib_path = os.path.join(loc, lib_name)
        if os.path.isfile(lib_path):
            return lib_path
    if os.environ.get(
        "IAX_AXELERA_RUNTIME_SKIP_SO", False
    ):  # workaround for axelera-llm on Windows
        return lib_name
    error_string = f"{lib_name} could not be found.\n"
    error_string += "Searched the following locations:\n" + "\n".join(search_locations)
    raise ImportError(error_string)


if sys.platform == "linux":
    LIBRARY_PATH = _search_library("libaxruntime.so")
elif sys.platform == "win32":
    _rtdir = os.environ.get("AXELERA_RUNTIME_DIR")
    _root = f"{_rtdir}\\lib\\" if _rtdir and os.path.isdir(_rtdir) else ""
    LIBRARY_PATH = f"{_root}libaxruntime.dll"
elif sys.platform == "darwin":
    LIBRARY_PATH = "libaxruntime.dylib"
else:
    raise OSError(f"Unsupported OS {sys.platform}")

MAX_TENSOR_DIMS = 8


class Result(_c.c_int):
    SUCCESS = 0
    EXECUTION_ERROR = 1
    VALUE_ERROR = 2
    INVALID_ARGUMENT = 3
    CONNECTION_ERROR = 4
    DEVICE_IN_USE = 5
    INCOMPATIBLE_DEVICE = 6
    INVALID_CONFIGURATION = 7
    NOT_IMPLEMENTED = 8
    INTERNAL_ERROR = 9
    PENDING = 10
    UNKNOWN_ERROR = 11


class LogLevel(_c.c_int):
    TRACE = 0
    LOG = 1
    DEBUG = 2
    INFO = 3
    FIXME = 4
    WARNING = 5
    ERROR = 6


class TensorDataType(_c.c_int):
    AXR_UNSIGNED = 0
    AXR_SIGNED = 1
    AXR_FLOAT = 2


class BoardType(_c.c_int):
    ALPHA_PCIE = 0
    ALPHA_M2 = 1
    OMEGA_PCIE = 2
    OMEGA_M2 = 3
    OMEGA_DEVBOARD = 4
    OMEGA_SBC = 5


class Argument(_c.Structure):
    _fields_ = [
        ("ptr", _c.c_void_p),
        ("fd", _c.c_int),
        ("offset", _c.c_size_t),
        ("size", _c.c_size_t),
    ]


class TensorInfo(_c.Structure):
    _fields_ = [
        ("dims", _c.c_size_t * MAX_TENSOR_DIMS),
        ("ndims", _c.c_size_t),
        ("bits", _c.c_size_t),
        ("type", _c.c_size_t),
        ("name", _c.c_char * 256),
        ("padding", (_c.c_size_t * 2) * MAX_TENSOR_DIMS),
        ("scale", _c.c_double),
        ("zero_point", _c.c_int),
    ]


class DeviceInfo(_c.Structure):
    _fields_ = [
        ("name", _c.c_char * 256),
        ("subdevice_count", _c.c_size_t),
        ("max_memory", _c.c_size_t),
        ("in_use", _c.c_int),
        ("in_use_by", _c.c_char * 256),
        ("board_type", _c.c_int),
        ("firmware_version", _c.c_char * 256),
        ("board_revision", _c.c_int),
        ("flashed_firmware_version", _c.c_char * 256),
        ("board_controller_firmware_version", _c.c_char * 256),
        ("board_controller_board_type", _c.c_char * 256),
    ]


class Object(_c.Structure):
    pass


class Model(_c.Structure):
    pass


class Connection(_c.Structure):
    pass


class Context(_c.Structure):
    pass


class ModelInstance(_c.Structure):
    pass


class Properties(_c.Structure):
    pass


if typing.TYPE_CHECKING:
    pObject = _c._Pointer[Object]
else:
    pObject = _c.POINTER(Object)


class _MissingFn:
    def __init__(self, name, msg):
        self.name = name
        self.argtypes = []
        self.restype = None
        self._msg = msg

    def __call__(self, *args, **kwargs):
        raise OSError(f"{LIBRARY_PATH}: {self.name}: {self._msg}")


class _Dll:
    def __init__(self, lib=None, failure_to_load=""):
        self._lib = lib
        self._failure_to_load = failure_to_load

    def __getattr__(self, name):
        if self._lib is None:
            return _MissingFn(name, self._failure_to_load)
        try:
            return getattr(self._lib, name)
        except AttributeError as e:
            return _MissingFn(name, str(e))


try:
    if sys.platform == "win32":
        from ctypes import GetLastError, WinError, windll

        # On windows we need to load the library with Windows API first
        # before loading it with CDLL
        kernel32 = windll.kernel32

        # Set error mode to prevent Windows from showing error dialogs
        SEM_FAILCRITICALERRORS = 0x0001
        old_error_mode = kernel32.SetErrorMode(SEM_FAILCRITICALERRORS)

        try:
            # Loading DLL using the previously set name in LIBRARY_PATH
            # This works both for libraries in AXELERA_RUNTIME_DIR
            # as well as for cases where libaxeleraruntime.dll is added
            # without an absolute path because Windows API will search
            # PATH
            handle = kernel32.LoadLibraryW(LIBRARY_PATH)
            if not handle:
                error = GetLastError()
                print(f"Failed to load {LIBRARY_PATH}")
                print(f"Windows error code: {error}")
                print(f"Error message: {WinError(error)}")
                raise OSError(error, f"Failed to load {LIBRARY_PATH}: {WinError(error)}")

        except OSError as e:
            print(f"Error loading {LIBRARY_PATH}: {e}")
            print("Current PATH directories:")
            for path in os.environ["PATH"].split(os.pathsep):
                print(f"  {path}")
            raise
        finally:
            # Restore original error mode
            kernel32.SetErrorMode(old_error_mode)

    _lib = _Dll(_c.CDLL(LIBRARY_PATH))
except OSError as e:
    _lib = _Dll(failure_to_load=str(e))

destroy = _lib.axr_destroy
destroy.argtypes = [pObject]
destroy.restype = None

get_context = _lib.axr_get_context
get_context.argtypes = [pObject]
get_context.restype = _c.POINTER(Context)

error_string = _lib.axr_error_string
error_string.argtypes = [Result]
error_string.restype = _c.c_char_p

last_error = _lib.axr_last_error
last_error.argtypes = [pObject]
last_error.restype = Result

last_error_string = _lib.axr_last_error_string
last_error_string.argtypes = [pObject]
last_error_string.restype = _c.c_char_p

create_context = _lib.axr_create_context
create_context.argtypes = []
create_context.restype = _c.POINTER(Context)

logger_fn = _c.CFUNCTYPE(None, _c.c_void_p, LogLevel, _c.c_char_p)
set_logger = _lib.axr_set_logger
set_logger.argtypes = [_c.POINTER(Context), LogLevel, logger_fn, _c.c_void_p]
set_logger.restype = None

list_devices = _lib.axr_list_devices
list_devices.argtypes = [_c.POINTER(Context), _c.POINTER(_c.POINTER(DeviceInfo))]
list_devices.restype = _c.c_size_t

device_ready = _lib.axr_device_ready
device_ready.argtypes = [_c.POINTER(Context), _c.POINTER(DeviceInfo)]
device_ready.restype = Result

configure_device = _lib.axr_configure_device
configure_device.argtypes = [
    _c.POINTER(Context),
    _c.POINTER(DeviceInfo),
    _c.POINTER(Properties),
]
configure_device.restype = Result

read_device_configuration = _lib.axr_read_device_configuration
read_device_configuration.argtypes = [_c.POINTER(Context), _c.POINTER(DeviceInfo)]
read_device_configuration.restype = _c.POINTER(Properties)

device_connect = _lib.axr_device_connect
device_connect.argtypes = [
    _c.POINTER(Context),
    _c.POINTER(DeviceInfo),
    _c.c_size_t,
    _c.POINTER(Properties),
]
device_connect.restype = _c.POINTER(Connection)


device_set_log_level = _lib.axr_device_set_log_level
device_set_log_level.argtypes = [
    _c.POINTER(Context),
    _c.POINTER(DeviceInfo),
    _c.c_char_p,
    _c.c_char_p,
]
device_set_log_level.restype = Result

device_peek_log = _lib.axr_device_peek_log
device_peek_log.argtypes = [_c.POINTER(Context), _c.POINTER(DeviceInfo), _c.c_char_p]
device_peek_log.restype = _c.c_char_p

device_get_log_stats = _lib.axr_device_get_log_stats
device_get_log_stats.argtypes = [
    _c.POINTER(Context),
    _c.POINTER(DeviceInfo),
    _c.c_char_p,
]
device_get_log_stats.restype = _c.c_char_p

device_clear_log = _lib.axr_device_clear_log
device_clear_log.argtypes = [_c.POINTER(Context), _c.POINTER(DeviceInfo), _c.c_char_p]
device_clear_log.restype = Result

device_logger_fn = _c.CFUNCTYPE(None, _c.c_void_p, LogLevel, _c.c_char_p, _c.c_char_p, _c.c_size_t)

device_start_logger = _lib.axr_device_start_logger
device_start_logger.argtypes = [
    _c.POINTER(Context),
    _c.POINTER(DeviceInfo),
    _c.c_char_p,
    device_logger_fn,
    _c.c_void_p,
    _c.c_bool,
]
device_start_logger.restype = Result

device_stop_logger = _lib.axr_device_stop_logger
device_stop_logger.argtypes = [_c.POINTER(Context), _c.POINTER(DeviceInfo)]
device_stop_logger.restype = None

device_list_log_text_sources = _lib.axr_device_list_log_text_sources
device_list_log_text_sources.argtypes = [_c.POINTER(Context), _c.POINTER(DeviceInfo)]
device_list_log_text_sources.restype = _c.c_char_p

device_list_log_data_sources = _lib.axr_device_list_log_data_sources
device_list_log_data_sources.argtypes = [_c.POINTER(Context), _c.POINTER(DeviceInfo)]
device_list_log_data_sources.restype = _c.c_char_p

create_properties = _lib.axr_create_properties
create_properties.argtypes = [_c.POINTER(Context), _c.c_char_p]
create_properties.restype = _c.POINTER(Properties)

list_properties = _lib.axr_list_properties
list_properties.argtypes = [_c.POINTER(Properties)]
list_properties.restype = _c.c_char_p

get_property = _lib.axr_get_property
get_property.argtypes = [_c.POINTER(Properties), _c.c_char_p]
get_property.restype = _c.c_char_p

set_property = _lib.axr_set_property
set_property.argtypes = [_c.POINTER(Properties), _c.c_char_p, _c.c_char_p]
set_property.restype = None

del_property = _lib.axr_del_property
del_property.argtypes = [_c.POINTER(Properties), _c.c_char_p]
del_property.restype = None

load_model = _lib.axr_load_model
load_model.argtypes = [_c.POINTER(Context), _c.c_char_p]
load_model.restype = _c.POINTER(Model)

num_model_inputs = _lib.axr_num_model_inputs
num_model_inputs.argtypes = [_c.POINTER(Model)]
num_model_inputs.restype = _c.c_size_t

get_model_input = _lib.axr_get_model_input
get_model_input.argtypes = [_c.POINTER(Model), _c.c_size_t]
get_model_input.restype = TensorInfo

num_model_outputs = _lib.axr_num_model_outputs
num_model_outputs.argtypes = [_c.POINTER(Model)]
num_model_outputs.restype = _c.c_size_t

get_model_output = _lib.axr_get_model_output
get_model_output.argtypes = [_c.POINTER(Model), _c.c_size_t]
get_model_output.restype = TensorInfo

get_model_properties = _lib.axr_get_model_properties
get_model_properties.argtypes = [_c.POINTER(Model)]
get_model_properties.restype = _c.POINTER(Properties)

load_model_instance = _lib.axr_load_model_instance
load_model_instance.argtypes = [
    _c.POINTER(Connection),
    _c.POINTER(Model),
    _c.POINTER(Properties),
]
load_model_instance.restype = _c.POINTER(ModelInstance)

run_model_instance = _lib.axr_run_model_instance
run_model_instance.argtypes = [
    _c.POINTER(ModelInstance),
    _c.POINTER(Argument),
    _c.c_size_t,
    _c.POINTER(Argument),
    _c.c_size_t,
]
run_model_instance.restype = Result

run_graph_model_instance = _lib.axr_run_graph_model_instance
run_graph_model_instance.argtypes = [
    _c.POINTER(ModelInstance),
    _c.c_char_p,
    _c.POINTER(Argument),
    _c.c_size_t,
    _c.POINTER(Argument),
    _c.c_size_t,
]
run_graph_model_instance.restype = Result
