# Copyright Axelera AI, 2024
import warnings as _warnings

from .dma_buf_allocator import DmaBufAllocator  # noqa
from .objects import *  # noqa
from .tvm_compat import axelera_load_model, graph_exec_load_model  # noqa
from .version import driver_version, version  # noqa

try:
    from axelera.runtime2 import _install
except ImportError:
    _warnings.warn(
        "axelera.runtime2 is not available so the new runtime API will not be available",
        ImportWarning,
    )
else:
    _install(globals())
