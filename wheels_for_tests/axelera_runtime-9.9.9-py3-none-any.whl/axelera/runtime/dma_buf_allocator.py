# Copyright Axelera AI, 2024
from __future__ import annotations

import contextlib
import ctypes
import ctypes.util
import mmap
import os
from typing import Generator

import numpy as np

_DMA_HEAP_IOC_MAGIC = ord("H")
_IOC_NRBITS = 8
_IOC_TYPEBITS = 8
_IOC_SIZEBITS = 14
_IOC_DIRBITS = 2
_IOC_NRSHIFT = 0
_IOC_TYPESHIFT = _IOC_NRSHIFT + _IOC_NRBITS
_IOC_SIZESHIFT = _IOC_TYPESHIFT + _IOC_TYPEBITS
_IOC_DIRSHIFT = _IOC_SIZESHIFT + _IOC_SIZEBITS

_IOC_NONE = 0
_IOC_WRITE = 1
_IOC_READ = 2


def _IOC(direction, type, nr, size):
    return (
        ((direction) << _IOC_DIRSHIFT)
        | ((type) << _IOC_TYPESHIFT)
        | ((nr) << _IOC_NRSHIFT)
        | ((size) << _IOC_SIZESHIFT)
    )


def _IOWR(type, number, size):
    return _IOC(_IOC_WRITE | _IOC_READ, type, number, size)


class _DmaHeapAllocation(ctypes.Structure):
    _fields_ = [
        ("len", ctypes.c_uint64),
        ("fd", ctypes.c_int),
        ("fd_flags", ctypes.c_uint32),
        ("heap_flags", ctypes.c_uint64),
    ]


_DMA_HEAP_IOCTL_ALLOC = _IOWR(_DMA_HEAP_IOC_MAGIC, 0x0, ctypes.sizeof(_DmaHeapAllocation))


def _array_size(shape: tuple[int, ...], dtype: np.dtype | type):
    # dtype comes in two forms. If it is a type, then we need to instantiate it
    # to get the itemsize. If it is an instance of a dtype, we can get the itemsize
    itemsize = dtype().itemsize if isinstance(dtype, type) else dtype.itemsize
    return np.prod(shape) * itemsize


class DmaBufAllocator:
    '''A simple allocator for dmabufs using the dma_heap driver.

    Using dmabufs as inputs and outputs for the accelerator is a common pattern
    to reduce host side copying. This class provides a simple interface to allocate
    dmabufs and map them into numpy arrays.

    Example:
    ```
    allocator = DmaBufAllocator()
    with allocator.create(shape=(10, 10), dtype=np.float32) as fd:
        allocator.assign(fd, np.random.rand(10, 10).astype(np.float32))
        result = allocator.as_numpy(fd, shape=(10, 10), dtype=np.float32)
    ```

    The returned fd can be used as an argument to the `ModelInstance.run.

    To ensure that the dmabuf is released when the scope ends, use the `create`
    method as a context manager, as shown in the example above.

    Alternatively all buffers created by the allocator will be released when the
    allocator is garbage collected.

    '''

    def __init__(self):
        self._device_name = "/dev/dma_heap/system"
        self._device_fd = -1
        self._page_size = os.sysconf("SC_PAGE_SIZE")
        self._ioctl = None
        self._available = set()
        self._in_use = set()

    def _init(self):
        # lazy init
        if self._device_fd == -1:
            self._device_fd = os.open(self._device_name, os.O_RDWR | os.O_CLOEXEC)
            libc = ctypes.CDLL(ctypes.util.find_library("c"), use_errno=True)
            self._ioctl = libc.ioctl

    def __del__(self):
        if self._device_fd != -1:
            for fd in self._in_use | self._available:
                os.close(fd)
            os.close(self._device_fd)

    def _align_to_page_size(self, size):
        return (((size - 1) // self._page_size) + 1) * self._page_size

    def allocate(self, shape: tuple[int, ...], dtype: np.dtype) -> int:
        '''Create a dmabuf for the given shape and dtype.

        Does not initialise the buffer. Use `assign` to copy data into the buffer.

        The returned file descriptor should be passed to `release` when not
        required.

        Alternatively use `create` as a context manager to ensure the buffer is
        released when the scope ends.
        '''
        self._init()
        try:
            fd = self._available.pop()
        except KeyError:
            fd = -1
        if fd == -1:  # new scope so we don't get chained exceptions
            unaligned_size = _array_size(shape, dtype)
            aligned_size = self._align_to_page_size(unaligned_size)
            alloc = _DmaHeapAllocation(aligned_size, 0, os.O_RDWR | os.O_CLOEXEC, 0)
            ret = self._ioctl(self._device_fd, _DMA_HEAP_IOCTL_ALLOC, ctypes.byref(alloc))
            if ret < 0 or alloc.fd < 0:
                e = os.strerror(ctypes.get_errno())
                raise RuntimeError(f"Failed to alloc dmabuf for {aligned_size} bytes : {e}")
            fd = alloc.fd
        self._in_use.add(fd)
        return fd

    def release(self, fd: int) -> None:
        '''Return the dmabuf file descriptor to the pool of available dmabufs.'''
        self._in_use.discard(fd)
        os.close(fd)

    @contextlib.contextmanager
    def create(
        self,
        data: np.ndarray | None = None,
        *,
        like: np.ndarray | None = None,
        shape: tuple[int, ...] | None = None,
        dtype: np.dtype | None = None,
    ) -> Generator[int, None, None]:
        """Managed context for creating a dmabuf and releasing at end of scope.

        There are three ways of specifying the dmabuf to create:

        ```
        # 1. Provide a numpy array `data` to copy into the dmabuf.
        with allocator.create(data=np.random.rand(10, 10).astype(np.float32)) as fd:
            pass

        # 2. Provide a numpy array `like` to create a dmabuf with the same shape and
        #  dtype, the buffer will not be initialised.
        myarray = np.random.rand(10, 10).astype(np.float32)
        with allocator.create(like=myarray) as fd:
            pass

        # 3. Explicitly provide shape and dtype:
        with allocator.create(shape=(10, 10), dtype=np.float32) as fd:
            pass

        ```
        """
        if like is not None and dtype is not None:
            raise ValueError("like and dtype should not be provided together")
        if (like is not None or data is not None) and (shape is not None or dtype is not None):
            raise ValueError("shape and dtype should not be provided if like or data is provided")
        if like is not None:
            shape, dtype = like.shape, like.dtype
        elif data is not None:
            shape, dtype = data.shape, data.dtype
        if shape is None or dtype is None:
            raise ValueError("shape and dtype must be provided if like or data are not provided")
        fd = self.allocate(shape, dtype)
        try:
            if data is not None:
                self.assign(fd, data)
            yield fd
        finally:
            self.release(fd)

    @classmethod
    def assign(cls, fd: int, data: np.ndarray) -> None:
        '''Copy the numpy array into the dmabuf.'''
        with mmap.mmap(fd, data.nbytes) as mapped:
            mapped_array = np.frombuffer(mapped, dtype=data.dtype).reshape(data.shape)
            try:
                mapped_array[:] = data
            finally:
                del mapped_array

    @classmethod
    def as_numpy(cls, fd: int, shape: tuple[int, ...], dtype: np.dtype) -> np.ndarray:
        '''Get the contexts of the dmabuf as a numpy array.'''
        nbytes = _array_size(shape, dtype)
        with mmap.mmap(fd, nbytes, flags=mmap.PROT_READ) as mapped:
            mapped_array = np.frombuffer(mapped, dtype=dtype).reshape(shape)
            try:
                cpy = np.copy(mapped_array)
            finally:
                del mapped_array
        return cpy
