#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "LibAxlDev::axldev" for configuration "RelWithDebInfo"
set_property(TARGET LibAxlDev::axldev APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(LibAxlDev::axldev PROPERTIES
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libaxldev.so"
  IMPORTED_SONAME_RELWITHDEBINFO "libaxldev.so"
  )

list(APPEND _cmake_import_check_targets LibAxlDev::axldev )
list(APPEND _cmake_import_check_files_for_LibAxlDev::axldev "${_IMPORT_PREFIX}/lib/libaxldev.so" )

# Import target "LibAxlDev::axldev_static" for configuration "RelWithDebInfo"
set_property(TARGET LibAxlDev::axldev_static APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(LibAxlDev::axldev_static PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELWITHDEBINFO "C;CXX"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libaxldev.a"
  )

list(APPEND _cmake_import_check_targets LibAxlDev::axldev_static )
list(APPEND _cmake_import_check_files_for_LibAxlDev::axldev_static "${_IMPORT_PREFIX}/lib/libaxldev.a" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
