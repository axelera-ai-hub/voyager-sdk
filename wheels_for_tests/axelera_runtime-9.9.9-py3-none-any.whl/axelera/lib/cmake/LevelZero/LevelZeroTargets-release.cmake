#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "LevelZero::ze_validation_layer" for configuration "Release"
set_property(TARGET LevelZero::ze_validation_layer APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(LevelZero::ze_validation_layer PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libze_validation_layer.so.1.15.0"
  IMPORTED_SONAME_RELEASE "libze_validation_layer.so.1"
  )

list(APPEND _cmake_import_check_targets LevelZero::ze_validation_layer )
list(APPEND _cmake_import_check_files_for_LevelZero::ze_validation_layer "${_IMPORT_PREFIX}/lib/libze_validation_layer.so.1.15.0" )

# Import target "LevelZero::ze_tracing_layer" for configuration "Release"
set_property(TARGET LevelZero::ze_tracing_layer APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(LevelZero::ze_tracing_layer PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libze_tracing_layer.so.1.15.0"
  IMPORTED_SONAME_RELEASE "libze_tracing_layer.so.1"
  )

list(APPEND _cmake_import_check_targets LevelZero::ze_tracing_layer )
list(APPEND _cmake_import_check_files_for_LevelZero::ze_tracing_layer "${_IMPORT_PREFIX}/lib/libze_tracing_layer.so.1.15.0" )

# Import target "LevelZero::axeDriver" for configuration "Release"
set_property(TARGET LevelZero::axeDriver APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(LevelZero::axeDriver PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libaxeDriver.so.1.15.0"
  IMPORTED_SONAME_RELEASE "libaxeDriver.so.1"
  )

list(APPEND _cmake_import_check_targets LevelZero::axeDriver )
list(APPEND _cmake_import_check_files_for_LevelZero::axeDriver "${_IMPORT_PREFIX}/lib/libaxeDriver.so.1.15.0" )

# Import target "LevelZero::ze_loader" for configuration "Release"
set_property(TARGET LevelZero::ze_loader APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(LevelZero::ze_loader PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libze_loader.a"
  )

list(APPEND _cmake_import_check_targets LevelZero::ze_loader )
list(APPEND _cmake_import_check_files_for_LevelZero::ze_loader "${_IMPORT_PREFIX}/lib/libze_loader.a" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
