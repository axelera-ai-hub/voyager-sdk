#!/bin/bash
# Copyright (c) 2023 Axelera AI. All rights reserved.
#
#!/bin/bash
# shellcheck disable=SC2129
# shellcheck disable=SC2086
# shellcheck disable=SC2181
# shellcheck disable=SC2181
# shellcheck disable=SC2010
# shellcheck disable=SC2006
#source /etc/profile


if [ -z "$DEVICE" ]; then
	DEVICE=$(axcmd --device-list | grep "Device 0:" | sed 's/.*Device 0: //')
	if [ -z "$DEVICE" ]; then
		echo "No Axelera device found"
		exit 1
	fi
fi

HW_GEN=$(axcmd --hwgen 0 | sed 's/.*Hardware generation at index 0: //')
if [ "$HW_GEN" = "europa" ]; then
	echo "Running tests on Europa hardware"
	P2P_BASE=0x7200000
	BASE=0x8100000
	axldev_dma_size=524288
	# DDR_BEFORE_GAP_MEM is not applicable for Europa, plus the tests involving DDR are currently skipped
elif [ "$HW_GEN" = "omega" ]; then
	echo "Running tests on Omega hardware"
	P2P_BASE=0x8100000
	BASE=0x8100000
	axldev_dma_size=8388608
	DDR_BEFORE_GAP_MEM=0xFF800000 # 8MB before DDR gap
else
	echo "Unsupported hardware generation: $HW_GEN"
	exit 1
fi

if [ -z "$LAST_CHANNEL" ]; then
	last_channel=3
else
	last_channel=$LAST_CHANNEL
fi

# unit test for axdma command to verify dmabuf/pcie dma driver/qemu
# t_start/t_stop number of test to start/stop
# if parameter is passed is used to start single test

mkdir -p /tmp

if [ -z "$AXE_CHROOT" ]; then
	AXE_CHROOT=/tmp
fi
log_file=$AXE_CHROOT/test-axldev-dma.log


log_clean()
{
	echo > "$log_file"
}

log ()
{
	echo "$1"
	echo "$1" >> "$log_file"
}
log_clean

if [  -n "$1" ]; then
	t_only=$1
	last_channel=0
else
	t_only=-2
fi
loop=0

test_verify_help()
{
	log "-----------------------------"
	log "TEST $loop: verify help command"
	cmd='axdma -P -h'
	echo "$cmd"
	$cmd
	RC=$?
	echo "-----------------------------"
	if [ $RC -eq 0 ]; then
		log "Result : PASSED"
	else
		log "Result : FAILED"
	fi
}

test_host_to_device()
{
	channel=$1
	log "-----------------------------"
	log "TEST $loop: H2D transfer ch $channel "
	base=$BASE
	hmax=0x10000
	max=$(printf "%d" $hmax)
	dd if=/dev/urandom of=/tmp/dump.out bs="$max"  count=1
	cmd="axdma -P -B -d $DEVICE -f /tmp/dump.out  -b $base -m 1 -C $channel"
	echo "$cmd"
	$cmd
	RC=$?
	echo "-----------------------------"
	if [ $RC -eq 0 ]; then
		log "Result : PASSED"
	else
		log "Result : FAILED"
	fi
}

test_device_to_host()
{
	channel=$1
	log "-----------------------------"
	log "TEST $loop: D2H Transfer ch $channel"
	[ -e /tmp/dump.in ] && rm /tmp/dump.in
	base=$BASE
	size=0x10000
	cmd="axdma -P -B -d $DEVICE -f /tmp/dump.in -s $size  -b $base  -m 2 -C $channel"
	echo "$cmd"
	$cmd
	RC=$?
	echo "-----------------------------"
	if [ $RC -eq 0 ]; then
		log "Result : PASSED"
	else
		log "Result : FAILED"
	fi
}



test_cmp_h2d_d2h_page()
{
	channel=$1
	log "-----------------------------"
	log "TEST $loop: DMA H2D and D2H compare single page ch $channel"
	base=$BASE
	[ -e /tmp/dump.out ] && rm /tmp/dump.out
	[ -e /tmp/dump.in ] && rm /tmp/dump.in
	dd if=/dev/urandom of=/tmp/dump.out bs=4096  count=1
	cmd1="axdma -P -B -d $DEVICE -f /tmp/dump.out  -b $base  -m 1 -C $channel"
	cmd2="axdma -P -B -d $DEVICE -f /tmp/dump.in -s 0x1000  -b $base  -m 2 -C $channel"
	echo "$cmd1"
	echo "$cmd2"
	$cmd1
	$cmd2
	diff /tmp/dump.out /tmp/dump.in
	RC=$?
	echo "-----------------------------"
	if [ $RC -eq 0 ]; then
		log "Result : PASSED"
	else
		log "Result : FAILED"
		hexdump -C -n 32 /tmp/dump.out
		hexdump -C -n 32 /tmp/dump.in
	fi
}

test_device_to_host_size_fail()
{
	log "-----------------------------"
	log "TEST $loop: D2H Fail over size ch $channel"
	base=$BASE
	size=0xd0000
	cmd="axdma -P -B -d $DEVICE -f /tmp/dump.in -s $size  -b $base  -m 2 -C $channel"
	echo "$cmd"
	$cmd
	RC=$?
	echo "-----------------------------"
	if [ $RC -eq 0 ]; then
		log "Result : FAILED"
	else
		log "Result : PASSED"
	fi
}

test_host_to_device_end_axi()
{
	log "-----------------------------"
	log "TEST $loop: H2D transfer end of axi (DDR) ch $channel"
	[ -e dump.out ] && rm dump.out
	base=$BASE
	hmax=0x100000
	max=$(printf "%d" $hmax)
	dd if=/dev/urandom of=/tmp/dump.out bs="$max"  count=1
	cmd="axdma -P -d $DEVICE -f /tmp/dump.out  -b $base  -m 1 -C $channel"
	echo "$cmd"
	$cmd
	RC=$?
	echo "-----------------------------"
	if [ $RC -eq 0 ]; then
		log "Result : PASSED"
	else
		log "Result : FAILED"
	fi
}

test_host_to_device_size_bigger_cma()
{
	log "-----------------------------"
	log "TEST $loop: H2D transfer chunk bigger then CMA ch $channel"
	[ -e /tmp/dump.out ] && rm /tmp/dump.out
	base=$BASE
	hmax=0x800000
	max=$(printf "%d" $hmax)
	dd if=/dev/urandom of=/tmp/dump.out bs="$max"  count=1
	cmd="axdma -P -d $DEVICE -f /tmp/dump.out  -b $base  -m 1 -C $channel"
	echo "$cmd"
	$cmd
	RC=$?
	echo "-----------------------------"
	if [ $RC -eq 0 ]; then
		log "Result : PASSED"
	else
		log "Result : FAILED"
	fi
}

test_device_to_host_size_bigger_cma()
{
	log "-----------------------------"
	log "TEST $loop: D2H transfer chunk bigger then CMA ch $channel"
	[ -e /tmp/dump.in ] && rm /tmp/dump.in
	base=$BASE
	hmax=0x800000
	max=$(printf "%d" $hmax)
	cmd="axdma -P -d $DEVICE -f /tmp/dump.out  -b $base -s $hmax -m 2 -C $channel"
	echo "$cmd"
	$cmd
	RC=$?
	echo "-----------------------------"
	if [ $RC -eq 0 ]; then
		log "Result : PASSED"
	else
		log "Result : FAILED"
	fi
}

test_cmp_h2d_d2h_full()
{
	log "-----------------------------"
	log "TEST $loop: DMA H2D and D2H compare ch $channel"
	base=$BASE
	hmax=0x100000
	max=$(printf "%d" $hmax)
	[ -e /tmp/dump.out ] && rm /tmp/dump.out
	[ -e /tmp/dump.in ] && rm /tmp/dump.in
	dd if=/dev/urandom of=/tmp/dump.out bs="$max"  count=1
	cmd1="axdma -P -B -d $DEVICE -f /tmp/dump.out  -b $base  -m 1 -C $channel"
	cmd2="axdma -P -B -d $DEVICE -f /tmp/dump.in -s $hmax  -b $base  -m 2 -C $channel"
	echo "$cmd1"
	echo "$cmd2"
	$cmd1
	$cmd2
	diff /tmp/dump.out /tmp/dump.in
	RC=$?
	echo "-----------------------------"
	if [ $RC -eq 0 ]; then
		log "Result : PASSED"
	else
		log "Result : FAILED"
		hexdump -C -n 32 /tmp/dump.out
		hexdump -C -n 32 /tmp/dump.in
	fi
}

test_multi_ch_cmp_h2d_d2h_full()
{
	log "-----------------------------"
	hmax=0x100000
    base_ch0=$BASE
    base_ch1=$(printf "0x%x" $(($base_ch0+$hmax)))
    base_ch2=$(printf "0x%x" $(($base_ch1+$hmax)))
    base_ch3=$(printf "0x%x" $(($base_ch2+$hmax)))
	max=$(printf "%d" $hmax)
	for channel in $(seq 0 3)
	do
		[ -e /tmp/dump_ch$channel.out ] && rm /tmp/dump_ch$channel.out
		[ -e /tmp/dump_ch$channel.in ] && rm /tmp/dump_ch$channel.in
		dd if=/dev/urandom of=/tmp/dump_ch$channel.out bs="$max"  count=1
	done
	cmd_wr_ch0="axdma -P -B -d $DEVICE -f /tmp/dump_ch0.out  -b $base_ch0  -m 1 -C 0"
	cmd_rd_ch0="axdma -P -B -d $DEVICE -f /tmp/dump_ch0.in -s $hmax  -b $base_ch0  -m 2 -C 0"
	cmd_wr_ch1="axdma -P -B -d $DEVICE -f /tmp/dump_ch1.out  -b $base_ch1  -m 1 -C 1"
	cmd_rd_ch1="axdma -P -B -d $DEVICE -f /tmp/dump_ch1.in -s $hmax  -b $base_ch1  -m 2 -C 1"
	cmd_wr_ch2="axdma -P -B -d $DEVICE -f /tmp/dump_ch2.out  -b $base_ch2  -m 1 -C 2"
	cmd_rd_ch2="axdma -P -B -d $DEVICE -f /tmp/dump_ch2.in -s $hmax  -b $base_ch2  -m 2 -C 2"
	cmd_wr_ch3="axdma -P -B -d $DEVICE -f /tmp/dump_ch3.out  -b $base_ch3  -m 1 -C 3"
	cmd_rd_ch3="axdma -P -B -d $DEVICE -f /tmp/dump_ch3.in -s $hmax  -b $base_ch3  -m 2 -C 3"
	cmd=`$cmd_wr_ch0;$cmd_rd_ch0 & $cmd_wr_ch2;$cmd_rd_ch2`
	echo $cmd
	log "-----------------------------"
	log "TEST DMA H2D and D2H compare ch 0,2"
	for channel in 0 2
	do
		diff /tmp/dump_ch$channel.out /tmp/dump_ch$channel.in
		RC=$?
		if [ $RC -eq 0 ]; then
			log "CH$channel Result : PASSED"
		else
			log "CH$channel Result : FAILED"
			hexdump -C -n 32 /tmp/dump_ch$channel.out
			hexdump -C -n 32 /tmp/dump_ch$channel.in
		fi
	done
	log "-----------------------------"
	log "TEST DMA H2D and D2H compare ch 1,3"
	cmd=`$cmd_wr_ch1;$cmd_rd_ch1 & $cmd_wr_ch3;$cmd_rd_ch3`
	echo $cmd
	for channel in 1 3
	do
		diff /tmp/dump_ch$channel.out /tmp/dump_ch$channel.in
		RC=$?
		if [ $RC -eq 0 ]; then
			log "CH$channel Result : PASSED"
		else
			log "CH$channel Result : FAILED"
			hexdump -C -n 32 /tmp/dump_ch$channel.out
			hexdump -C -n 32 /tmp/dump_ch$channel.in
		fi
	done

	log "-----------------------------"
	log "TEST DMA H2D and D2H compare ch 0,1,2,3"
	cmd=`$cmd_wr_ch0;$cmd_rd_ch0 & $cmd_wr_ch1;$cmd_rd_ch1 & $cmd_wr_ch2;$cmd_rd_ch2 & $cmd_wr_ch3;$cmd_rd_ch3`
	for channel in $(seq 0 3)
	do
		diff /tmp/dump_ch$channel.out /tmp/dump_ch$channel.in
		RC=$?
		if [ $RC -eq 0 ]; then
			log "CH$channel Result : PASSED"
		else
			log "CH$channel Result : FAILED"
			hexdump -C -n 32 /tmp/dump_ch$channel.out
			hexdump -C -n 32 /tmp/dump_ch$channel.in
		fi
	done
}

test_host_to_device_single()
{
	log "-----------------------------"
	log "TEST $loop: H2D single transfer  ch $channel"
	base=$BASE
	val=0x12345678
	cmd="axdma -P -B -d $DEVICE -b $base  -m 1 -v $val -C $channel"
	echo "$cmd"
	$cmd
	RC=$?
	echo "-----------------------------"
	if [ $RC -eq 0 ]; then
		log "Result : PASSED"
	else
		log "Result : FAILED"
	fi
}

test_device_to_host_single()
{
	log "-----------------------------"
	log "TEST $loop: D2H single transfer  ch $channel"
	base=$BASE
	val=0x0
	cmd="axdma -P -B -d $DEVICE  -b $base  -m 2 -v $val -C $channel"
	echo "$cmd"
	$cmd
	RC=$?
	echo "-----------------------------"
	if [ $RC -eq 0 ]; then
		log "Result : PASSED"
	else
		log "Result : FAILED"
	fi
}

test_dmabuf_kernel_leak()
{
	log "-----------------------------"
	log "TEST $loop: dmabufg kernel leak"
	if [ ! -e /sys/kernel/debug/dma_buf/bufinfo ]; then
		log "Result : SKIPPED"
		return
	fi
	sudo grep -q "Total 0 objects, 0 bytes" /sys/kernel/debug/dma_buf/bufinfo
	RC=$?
	echo "-----------------------------"
	if [ $RC -eq 0 ]; then
		log "Result : PASSED"
	else
		log "Result : FAILED"
	fi
}

test_cmp_h2d_d2h_cross_ddr()
{
	channel=$1
	log "-----------------------------"
	log "TEST $loop: DMA H2D and D2H compare cross DDR ch $channel"
	# This test is not yet available on Europa
	if [ "$HW_GEN" = "europa" ]; then
		log "Result : SKIPPED on Europa"
		return
	fi
	# This test is not available on boards with less than 2GB of DRAM
	size_2gb=2147483648
	ddr_cmd=$(axcmd --get-ddr-size --device $DEVICE)
	ddr_val=$(echo $ddr_cmd | grep -oP '\(\K[0-9]+')
	if [[ -z "$ddr_val" || ! "$ddr_val" =~ ^[0-9]+$ ]]; then
		echo "Error: Could not extract a valid DDR size. Command output may be invalid."
		log "Result : FAILED"
		return
	fi
	if [[ "$ddr_val" -le "$size_2gb" ]]; then
		log "Result : SKIPPED for boards with less than 2GB of DRAM"
		return
	fi
	[ -e /tmp/dump.out ] && rm /tmp/dump.out
	[ -e /tmp/dump.in ] && rm /tmp/dump.in
	# 16MB cross DDR (8MB on each DDR bank)
	base=$DDR_BEFORE_GAP_MEM
	hsize=0x1000000
	size=$(printf "%d" $hsize)
	dd if=/dev/urandom of=/tmp/dump.out bs="$size"  count=1
	cmd1="axdma -P -B -d $DEVICE -f /tmp/dump.out -b $base -m 1 -C $channel"
	cmd2="axdma -P -B -d $DEVICE -f /tmp/dump.in -s "$hsize" -b $base -m 2 -C $channel"
	echo "$cmd1"
	echo "$cmd2"
	$cmd1
	$cmd2
	diff /tmp/dump.out /tmp/dump.in
	RC=$?
	echo "-----------------------------"
	if [ $RC -eq 0 ]; then
		log "Result : PASSED"
	else
		log "Result : FAILED"
		hexdump -C -n 32 /tmp/dump.out
		hexdump -C -n 32 /tmp/dump.in
	fi
}

test_cmp_h2d_d2h_cross_ddr_async_wait()
{
	channel=$1
	log "-----------------------------"
	log "TEST $loop: DMA H2D and D2H compare cross DDR ch $channel"
	# This test is not yet available on Europa
	if [ "$HW_GEN" = "europa" ]; then
		log "Result : SKIPPED on Europa"
		return
	fi
	# This test is not available on boards with less than 2GB of DRAM
	size_2gb=2147483648
	ddr_cmd=$(axcmd --get-ddr-size --device $DEVICE)
	ddr_val=$(echo $ddr_cmd | grep -oP '\(\K[0-9]+')
	if [[ -z "$ddr_val" || ! "$ddr_val" =~ ^[0-9]+$ ]]; then
		echo "Error: Could not extract a valid DDR size. Command output may be invalid."
		log "Result : FAILED"
		return
	fi
	if [[ "$ddr_val" -le "$size_2gb" ]]; then
		log "Result : SKIPPED for boards with less than 2GB of DRAM"
		return
	fi
	[ -e /tmp/dump.out ] && rm /tmp/dump.out
	[ -e /tmp/dump.in ] && rm /tmp/dump.in
	# 16MB cross DDR (8MB on each DDR bank)
	base=$DDR_BEFORE_GAP_MEM
	hsize=0x1000000
	size=$(printf "%d" $hsize)
	dd if=/dev/urandom of=/tmp/dump.out bs="$size"  count=1
	cmd1="axdma -P -B -d $DEVICE -f /tmp/dump.out -b $base -m 1 -C $channel -A 1"
	cmd2="axdma -P -B -d $DEVICE -f /tmp/dump.in -s "$hsize" -b $base -m 2 -C $channel -A 1"
	echo "$cmd1"
	echo "$cmd2"
	$cmd1
	$cmd2
	diff /tmp/dump.out /tmp/dump.in
	RC=$?
	echo "-----------------------------"
	if [ $RC -eq 0 ]; then
		log "Result : PASSED"
	else
		log "Result : FAILED"
		hexdump -C -n 32 /tmp/dump.out
		hexdump -C -n 32 /tmp/dump.in
	fi
}

test_cmp_h2d_d2h_cross_ddr_async_poll()
{
	channel=$1
	log "-----------------------------"
	log "TEST $loop: DMA H2D and D2H compare cross DDR ch $channel"
	# This test is not yet available on Europa
	if [ "$HW_GEN" = "europa" ]; then
		log "Result : SKIPPED on Europa"
		return
	fi
	# This test is not available on boards with less than 2GB of DRAM
	size_2gb=2147483648
	ddr_cmd=$(axcmd --get-ddr-size --device $DEVICE)
	ddr_val=$(echo $ddr_cmd | grep -oP '\(\K[0-9]+')
	if [[ -z "$ddr_val" || ! "$ddr_val" =~ ^[0-9]+$ ]]; then
		echo "Error: Could not extract a valid DDR size. Command output may be invalid."
		log "Result : FAILED"
		return
	fi
	if [[ "$ddr_val" -le "$size_2gb" ]]; then
		log "Result : SKIPPED for boards with less than 2GB of DRAM"
		return
	fi
	[ -e /tmp/dump.out ] && rm /tmp/dump.out
	[ -e /tmp/dump.in ] && rm /tmp/dump.in
	# 16MB cross DDR (8MB on each DDR bank)
	base=$DDR_BEFORE_GAP_MEM
	hsize=0x1000000
	size=$(printf "%d" $hsize)
	dd if=/dev/urandom of=/tmp/dump.out bs="$size"  count=1
	cmd1="axdma -P -B -d $DEVICE -f /tmp/dump.out -b $base -m 1 -C $channel -A 2"
	cmd2="axdma -P -B -d $DEVICE -f /tmp/dump.in -s "$hsize" -b $base -m 2 -C $channel -A 2"
	echo "$cmd1"
	echo "$cmd2"
	$cmd1
	$cmd2
	diff /tmp/dump.out /tmp/dump.in
	RC=$?
	echo "-----------------------------"
	if [ $RC -eq 0 ]; then
		log "Result : PASSED"
	else
		log "Result : FAILED"
		hexdump -C -n 32 /tmp/dump.out
		hexdump -C -n 32 /tmp/dump.in
	fi
}

test_host_to_device_offset()
{
	channel=$1
	log "-----------------------------"
	log "TEST $loop: H2D transfer with offset ch $channel"
	base=$BASE
	hmax=0x10000
	max=$(printf "%d" $hmax)
	dd if=/dev/urandom of=/tmp/dump.out bs="$max" count=1
	cmd="axdma -P -B -d $DEVICE -f /tmp/dump.out  -b $base -m 1 -C $channel --offset 0x1250"
	echo "$cmd"
	$cmd > /dev/null
	rc=$?
	if [ $rc -eq 0 ]; then
		log "Result : PASSED"
	else
		log "Result : FAILED ($rc)"
	fi
	echo "-----------------------------"
}

test_device_to_host_offset()
{
	channel=$1
	log "-----------------------------"
	log "TEST $loop: D2H Transfer with offset ch $channel"
	[ -e /tmp/dump.in ] && rm /tmp/dump.in
	base=$BASE
	size=0x10000
	cmd="axdma -P -B -d $DEVICE -f /tmp/dump.in -s $size  -b $base  -m 2 -C $channel --offset 0x1250"
	echo "$cmd"
	$cmd
	RC=$?
	echo "-----------------------------"
	if [ $RC -eq 0 ]; then
		log "Result : PASSED"
	else
		log "Result : FAILED"
	fi
}

test_cmp_h2d_d2h_offset()
{
	channel=$1
	log "-----------------------------"
	log "TEST $loop: DMA H2D and D2H compare with offset ch $channel"
	base=$BASE
	offset=0x1250
	hmax=0x10000
	max=$(printf "%d" $hmax)
	[ -e /tmp/dump.out ] && rm /tmp/dump.out
	[ -e /tmp/dump.in ] && rm /tmp/dump.in
	dd if=/dev/urandom of=/tmp/dump.out bs="$max" count=1
	cmd1="axdma -P -B -d $DEVICE -f /tmp/dump.out -b $base -m 1 -C $channel --offset $offset"
	cmd2="axdma -P -B -d $DEVICE -f /tmp/dump.in -s $hmax -b $base -m 2 -C $channel --offset $offset"
	echo "$cmd1"
	$cmd1 > /dev/null
	RC1=$?
	echo "$cmd2"
	$cmd2 > /dev/null
	RC2=$?
	# Compare only the offsetted part
	dd if=/tmp/dump.out of=/tmp/dump.out.skip bs=1 skip=$((0x1250)) 2>/dev/null
	dd if=/tmp/dump.in of=/tmp/dump.in.skip bs=1 count=$((max - 0x1250)) 2>/dev/null
	diff /tmp/dump.out.skip /tmp/dump.in.skip
	RC=$?
	echo "-----------------------------"
	if [ $RC1 -eq 0 ] && [ $RC2 -eq 0 ] && [ $RC -eq 0 ]; then
		log "Result : PASSED"
	else
		log "Result : FAILED"
		hexdump -C -n 32 /tmp/dump.out.skip
		hexdump -C -n 32 /tmp/dump.in.skip
	fi
}

test_multi_transfer_h2d_poll()
{
	channel=$1
	log "-----------------------------"
	log "TEST $loop: DMA H2D multi transfer with poll ch $channel"
	base=$BASE
	hmax=0x10000
	max=$(printf "%d" $hmax)
	[ -e /tmp/dump.out ] && rm /tmp/dump.out
	dd if=/dev/urandom of=/tmp/dump.out bs=$max count=1 > /dev/null 2>&1
	cmd="axdma -P -B -d $DEVICE -f /tmp/dump.out -b $base -m 1 -C $channel -A 2 --multi-poll 4"
	echo "$cmd"
	$cmd > /dev/null
	rc=$?
	if [ $rc -eq 0 ]; then
		log "Result : PASSED"
	else
		log "Result : FAILED ($rc)"
	fi
	echo "-----------------------------"
}

test_multi_transfer_d2h_poll()
{
	channel=$1
	log "-----------------------------"
	log "TEST $loop: DMA D2H multi transfer with poll ch $channel"
	base=$BASE
	hmax=0x10000
	[ -e /tmp/dump.in ] && rm /tmp/dump.in
	cmd="axdma -P -B -d $DEVICE -f /tmp/dump.in -s $hmax -b $base -m 2 -C $channel -A 2 --multi-poll 4"
	echo "$cmd"
	$cmd > /dev/null
	rc=$?
	if [ $rc -eq 0 ]; then
		log "Result : PASSED"
	else
		log "Result : FAILED ($rc)"
	fi
	echo "-----------------------------"
}

test_p2p_dma_transfer_read()
{
	log "======================================================"
	log "TEST $loop: ${FUNCNAME[0]}"
	axldev_dma_size_hex=$(printf "0x%x" $axldev_dma_size)
	axldev_dma_in=/tmp/axldev_dma.in
	axldev_dma_out=/tmp/axldev_dma.out
	[ -e $axldev_dma_in ] && rm $axldev_dma_in
	[ -e $axldev_dma_out ] && rm $axldev_dma_out
	dd if=/dev/urandom of=$axldev_dma_out bs=$axldev_dma_size count=1 > /dev/null 2>&1

	axcmd --device-list | grep "Device 1"
	if [ $? -ne 0 ]; then
		log "No Device 1 found, skipping test"
		log "======================================================"
		return
	fi

	log "Write to Device 0"
	cmd="axdma -P -B -d 0 -f $axldev_dma_out -b $P2P_BASE -m 1 -C 1"
	echo "$cmd"
	$cmd > /dev/null
	rc=$?
	if [ $rc -eq 0 ]; then
		log "Result : PASSED"
	else
		log "Result : FAILED ($rc)"
	fi

	log "P2P Read from Device 0 to Device 1"
	cmd="axdma -P -B --p2p-dma 0:1 -m 2 -C 1 -s $axldev_dma_size_hex -b $P2P_BASE"
	echo "$cmd"
	$cmd > /dev/null
	rc=$?
	if [ $rc -eq 0 ]; then
		log "Result : PASSED"
	else
		log "Result : FAILED ($rc)"
	fi

	log "Read from Device 1"
	cmd="axdma -P -B -d 1 -f $axldev_dma_in -b $P2P_BASE -m 2 -C 1 -s $axldev_dma_size_hex"
	echo "$cmd"
	$cmd > /dev/null
	rc=$?
	if [ $rc -eq 0 ]; then
		log "Result : PASSED"
	else
		log "Result : FAILED ($rc)"
	fi
	cmd="diff $axldev_dma_out $axldev_dma_in"
	echo "$cmd"
	$cmd > /dev/null
	rc=$?
	if [ $rc -eq 0 ]; then
		log "Result : PASSED"
	else
		log "Result : FAILED ($rc)"
	fi
	log "======================================================"
}

test_p2p_dma_transfer_write()
{
	log "======================================================"
	log "TEST $loop: ${FUNCNAME[0]}"
	axldev_dma_size_hex=$(printf "0x%x" $axldev_dma_size)
	axldev_dma_in=/tmp/axldev_dma.in
	axldev_dma_out=/tmp/axldev_dma.out
	[ -e $axldev_dma_in ] && rm $axldev_dma_in
	[ -e $axldev_dma_out ] && rm $axldev_dma_out
	dd if=/dev/urandom of=$axldev_dma_out bs=$axldev_dma_size count=1 > /dev/null 2>&1

	axcmd --device-list | grep "Device 1"
	if [ $? -ne 0 ]; then
		log "No Device 1 found, skipping test"
		log "======================================================"
		return
	fi

	log "Write to Device 1"
	cmd="axdma -P -B -d 1 -f $axldev_dma_out -b $P2P_BASE -m 1 -C 1"
	echo "$cmd"
	$cmd > /dev/null
	rc=$?
	if [ $rc -eq 0 ]; then
		log "Result : PASSED"
	else
		log "Result : FAILED ($rc)"
	fi

	log "P2P Write from Device 1 to Device 0"
	cmd="axdma --p2p-dma 1:0 -m 1 -C 1 -s $axldev_dma_size_hex -b $P2P_BASE"
	echo "$cmd"
	$cmd > /dev/null
	rc=$?
	if [ $rc -eq 0 ]; then
		log "Result : PASSED"
	else
		log "Result : FAILED ($rc)"
	fi

	log "Read from Device 0"
	cmd="axdma -P -B -d 0 -f $axldev_dma_in -b $P2P_BASE -m 2 -C 1 -s $axldev_dma_size_hex"
	echo "$cmd"
	$cmd > /dev/null
	rc=$?
	if [ $rc -eq 0 ]; then
		log "Result : PASSED"
	else
		log "Result : FAILED ($rc)"
	fi
	cmd="diff $axldev_dma_out $axldev_dma_in"
	echo "$cmd"
	$cmd > /dev/null
	rc=$?
	if [ $rc -eq 0 ]; then
		log "Result : PASSED"
	else
		log "Result : FAILED ($rc)"
	fi
	log "======================================================"
}

test_p2p_dev_dma_transfer_write()
{
	log "======================================================"
	log "TEST $loop: ${FUNCNAME[0]}"
	axldev_dma_size_hex=$(printf "0x%x" $axldev_dma_size)
	axldev_dma_in=/tmp/axldev_dma.in
	axldev_dma_out=/tmp/axldev_dma.out
	[ -e $axldev_dma_in ] && rm $axldev_dma_in
	[ -e $axldev_dma_out ] && rm $axldev_dma_out
	dd if=/dev/urandom of=$axldev_dma_out bs=$axldev_dma_size count=1 > /dev/null 2>&1

	axcmd --get-dev-mode | grep "SILICON"
	if [ $? -ne 0 ]; then
		log "Device mode is not SILICON, skipping test"
		log "======================================================"
		return
	fi

	axcmd --device-list | grep "Device 1"
	if [ $? -ne 0 ]; then
		log "No Device 1 found, skipping test"
		log "======================================================"
		return
	fi

	log "Write to Device 0"
	cmd="axdma -P -B -d 0 -f $axldev_dma_out -b $P2P_BASE -m 1 -C 0"
	echo "$cmd"
	$cmd > /dev/null
	rc=$?
	if [ $rc -eq 0 ]; then
		log "Result : PASSED"
	else
		log "Result : FAILED ($rc)"
	fi

	log "P2P Write from Device 0 to Device 1"
	cmd="axdma --p2p-dev-dma-utest -m 2 -C 1 -s $axldev_dma_size_hex -b $P2P_BASE"
	echo "$cmd"
	$cmd > /dev/null
	rc=$?
	if [ $rc -eq 0 ]; then
		log "Result : PASSED"
	else
		log "Result : FAILED ($rc)"
	fi

	log "Read from Device 1"
	cmd="axdma -P -B -d 1 -f $axldev_dma_in -b $P2P_BASE -m 2 -C 0 -s $axldev_dma_size_hex"
	echo "$cmd"
	$cmd > /dev/null
	rc=$?
	if [ $rc -eq 0 ]; then
		log "Result : PASSED"
	else
		log "Result : FAILED ($rc)"
	fi
	cmd="diff $axldev_dma_out $axldev_dma_in"
	echo "$cmd"
	$cmd > /dev/null
	rc=$?
	if [ $rc -eq 0 ]; then
		log "Result : PASSED"
	else
		log "Result : FAILED ($rc)"
	fi
	log "======================================================"
}

test_p2p_dev_dma_transfer_read()
{
	log "======================================================"
	log "TEST $loop: ${FUNCNAME[0]}"
	axldev_dma_size_hex=$(printf "0x%x" $axldev_dma_size)
	axldev_dma_in=/tmp/axldev_dma.in
	axldev_dma_out=/tmp/axldev_dma.out
	[ -e $axldev_dma_in ] && rm $axldev_dma_in
	[ -e $axldev_dma_out ] && rm $axldev_dma_out
	dd if=/dev/urandom of=$axldev_dma_out bs=$axldev_dma_size count=1 > /dev/null 2>&1

	axcmd --get-dev-mode | grep "SILICON"
	if [ $? -ne 0 ]; then
		log "Device mode is not SILICON, skipping test"
		log "======================================================"
		return
	fi

	axcmd --device-list | grep "Device 1"
	if [ $? -ne 0 ]; then
		log "No Device 1 found, skipping test"
		log "======================================================"
		return
	fi

	log "Write to Device 1"
	cmd="axdma -P -B -d 1 -f $axldev_dma_out -b $P2P_BASE -m 1 -C 0"
	echo "$cmd"
	$cmd > /dev/null
	rc=$?
	if [ $rc -eq 0 ]; then
		log "Result : PASSED"
	else
		log "Result : FAILED ($rc)"
	fi

	log "P2P Read from Device 1 to Device 0"
	cmd="axdma --p2p-dev-dma-utest -m 1 -C 1 -s $axldev_dma_size_hex -b $P2P_BASE"
	echo "$cmd"
	$cmd > /dev/null
	rc=$?
	if [ $rc -eq 0 ]; then
		log "Result : PASSED"
	else
		log "Result : FAILED ($rc)"
	fi

	log "Read from Device 0"
	cmd="axdma -P -B -d 0 -f $axldev_dma_in -b $P2P_BASE -m 2 -C 0 -s $axldev_dma_size_hex"
	echo "$cmd"
	$cmd > /dev/null
	rc=$?
	if [ $rc -eq 0 ]; then
		log "Result : PASSED"
	else
		log "Result : FAILED ($rc)"
	fi
	cmd="diff $axldev_dma_out $axldev_dma_in"
	echo "$cmd"
	$cmd > /dev/null
	rc=$?
	if [ $rc -eq 0 ]; then
		log "Result : PASSED"
	else
		log "Result : FAILED ($rc)"
	fi
	log "======================================================"
}


TEST_CMD=(
test_verify_help					    # 0
test_host_to_device					    # 1
test_device_to_host					    # 2
test_cmp_h2d_d2h_page				    # 3
test_cmp_h2d_d2h_full				    # 4
test_host_to_device_single			    # 5
test_device_to_host_single			    # 6
test_host_to_device_size_bigger_cma	    # 7
test_device_to_host_size_bigger_cma	    # 8
test_dmabuf_kernel_leak				    # 9
test_cmp_h2d_d2h_cross_ddr              # 10
test_cmp_h2d_d2h_cross_ddr_async_wait   # 11
test_cmp_h2d_d2h_cross_ddr_async_poll   # 12
test_host_to_device_offset				# 13
test_device_to_host_offset				# 14
test_cmp_h2d_d2h_offset					# 15
test_multi_transfer_h2d_poll			# 16
test_multi_transfer_d2h_poll			# 17
test_p2p_dma_transfer_read				# 18
test_p2p_dma_transfer_write				# 19
test_p2p_dev_dma_transfer_write			# 20
test_p2p_dev_dma_transfer_read			# 21
)

if [ $t_only -eq -1 ]; then
	for test_cmd in "${TEST_CMD[@]}"
	do
		echo "TEST $loop $test_cmd"
		loop=$((loop+1))
	done
	exit 0
fi

test_dma()
{
	for channel in $(seq 0 $last_channel)
	do
		if [ $t_only -ge 0 ]; then
			loop=$t_only
			${TEST_CMD[$t_only]} "$channel"
			continue
		fi
		loop=0
		for test_cmd in "${TEST_CMD[@]}"
		do
			loop=$((loop+1))
			$test_cmd "$channel"
		done
		if [ $t_only -eq -2 ] && [ -z "$WIN_HOST" ]; then
			test_dma_with_msi
			test_dma_with_poll
		fi
	done
}

test_dma_with_msi()
{
	log "####################################"
	log "MSI : enable"
	export LIBAXLDEV_WAIT_KERNEL_MODE=M

	log "####################################"
	log "default dmabuf : allocator system"
	export LIBAXLDEV_DMABUF=/dev/dma_heap/system
	test_multi_ch_cmp_h2d_d2h_full

	log "####################################"
	log "dmabuf allocator : reserved"
	export LIBAXLDEV_DMABUF=/dev/dma_heap/reserved
	test_multi_ch_cmp_h2d_d2h_full

	log "####################################"
	log "dmabuf allocator : dmabuf_triton_exporter"
	export LIBAXLDEV_DMABUF=/dev/dmabuf_triton_exporter
	test_multi_ch_cmp_h2d_d2h_full

	log "####################################"
	log "dmabuf allocator : udmabuf"
	export LIBAXLDEV_DMABUF=/dev/udmabuf
	test_multi_ch_cmp_h2d_d2h_full
}

test_dma_with_poll()
{
	log "####################################"
	log "MSI : enable"
	export LIBAXLDEV_WAIT_KERNEL_MODE=P

	log "####################################"
	log "default dmabuf : allocator system"
	export LIBAXLDEV_DMABUF=/dev/dma_heap/system
	test_multi_ch_cmp_h2d_d2h_full

	log "####################################"
	log "dmabuf allocator : reserved"
	export LIBAXLDEV_DMABUF=/dev/dma_heap/reserved
	test_multi_ch_cmp_h2d_d2h_full

	log "####################################"
	log "dmabuf allocator : dmabuf_triton_exporter"
	export LIBAXLDEV_DMABUF=/dev/dmabuf_triton_exporter
	test_multi_ch_cmp_h2d_d2h_full

	log "####################################"
	log "dmabuf allocator : udmabuf"
	export LIBAXLDEV_DMABUF=/dev/udmabuf
	test_multi_ch_cmp_h2d_d2h_full
}

test_dma
cat $log_file

grep -q FAILED "$log_file"
RC=$?
if [ $RC -eq 0 ];then
	echo "At least one test failed"
	exit 1
fi
exit 0
