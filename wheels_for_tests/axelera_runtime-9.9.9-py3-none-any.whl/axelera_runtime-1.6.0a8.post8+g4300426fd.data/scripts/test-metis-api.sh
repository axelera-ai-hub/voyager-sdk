#!/bin/bash
# Copyright (c) 2024 Axelera AI. All rights reserved.

#. /etc/profile

TEST_METIS_API=test-metis-api.log
if [ -z "$AXE_CHROOT" ]; then
	log_file=/tmp/$TEST_METIS_API
else
	log_file=$AXE_CHROOT/$TEST_METIS_API
fi

if [ -z "$DEVICE" ]; then
	# If not given explicitly, try to auto-detect.
	DEVICE=$(axcmd --device-list | grep "Device 0:" | sed 's/.*Device 0: //')
	if [ -z "$DEVICE" ]; then
		echo "No triton device found"
		exit 1
	fi
fi

log_clean()
{
	echo > "$log_file"
}
log ()
{
	echo "$1"
	echo "$1" >> "$log_file"
}

if [  -n "$1" ]; then
	t_only=$1
else
	t_only=0
fi

test_metis_dmabuf_xfer_write()
{
	log "======================================================"
	log "TEST $loop: ${FUNCNAME[0]}"
	metis_api_size=1059876
	metis_api_out=/tmp/metis_api.out
	[ -e $metis_api_out ] && rm $metis_api_out
	dd if=/dev/urandom of=$metis_api_out bs=$metis_api_size count=1 > /dev/null 2>&1
	cmd="metis_dma --device $DEVICE --file $metis_api_out --write --channel 0"
	echo "$cmd"
	$cmd > /dev/null
	rc=$?
	if [ $rc -eq 0 ]; then
		log "Result : PASSED"
	else
		log "Result : FAILED ($rc)"
	fi
	log "======================================================"
}

test_metis_dmabuf_xfer_write_async()
{
	log "======================================================"
	log "TEST $loop: ${FUNCNAME[0]}"
	metis_api_size=1059876
	metis_api_out=/tmp/metis_api.out
	[ -e $metis_api_out ] && rm $metis_api_out
	dd if=/dev/urandom of=$metis_api_out bs=$metis_api_size count=1 > /dev/null 2>&1
	cmd="metis_dma --device $DEVICE --file $metis_api_out --write --channel 0 --async"
	echo "$cmd"
	$cmd > /dev/null
	rc=$?
	if [ $rc -eq 0 ]; then
		log "Result : PASSED"
	else
		log "Result : FAILED ($rc)"
	fi
	log "======================================================"
}

test_metis_dmabuf_xfer_write_async_wait()
{
	log "======================================================"
	log "TEST $loop: ${FUNCNAME[0]}"
	metis_api_size=1059876
	metis_api_out=/tmp/metis_api.out
	[ -e $metis_api_out ] && rm $metis_api_out
	dd if=/dev/urandom of=$metis_api_out bs=$metis_api_size count=1 > /dev/null 2>&1
	cmd="metis_dma --device $DEVICE --file $metis_api_out --write --channel 0 --async --wait"
	echo "$cmd"
	$cmd > /dev/null
	rc=$?
	if [ $rc -eq 0 ]; then
		log "Result : PASSED"
	else
		log "Result : FAILED ($rc)"
	fi
	log "======================================================"
}

test_metis_dmabuf_xfer_write_offset()
{
	log "======================================================"
	log "TEST $loop: ${FUNCNAME[0]}"
	metis_api_size=1059876
	metis_api_out=/tmp/metis_api.out
	[ -e $metis_api_out ] && rm $metis_api_out
	dd if=/dev/urandom of=$metis_api_out bs=$metis_api_size count=1 > /dev/null 2>&1
	cmd="metis_dma --device $DEVICE --file $metis_api_out --write --channel 0 --offset 0x1250"
	echo "$cmd"
	$cmd > /dev/null
	rc=$?
	if [ $rc -eq 0 ]; then
		log "Result : PASSED"
	else
		log "Result : FAILED ($rc)"
	fi
	log "======================================================"
}

test_metis_dmabuf_xfer_read_async_wait()
{
	log "======================================================"
	log "TEST $loop: ${FUNCNAME[0]}"
	metis_api_size=1059876
	metis_api_in=/tmp/metis_api.in
	[ -e $metis_api_in ] && rm $metis_api_in
	cmd="metis_dma --device $DEVICE --file $metis_api_in --read --channel 0 --size $metis_api_size --async --wait"
	echo "$cmd"
	$cmd > /dev/null
	rc=$?
	if [ $rc -eq 0 ]; then
		log "Result : PASSED"
	else
		log "Result : FAILED ($rc)"
	fi
	log "======================================================"
}

test_metis_dmabuf_xfer_read_async()
{
	log "======================================================"
	log "TEST $loop: ${FUNCNAME[0]}"
	metis_api_size=1059876
	metis_api_in=/tmp/metis_api.in
	[ -e $metis_api_in ] && rm $metis_api_in
	cmd="metis_dma --device $DEVICE --file $metis_api_in --read --channel 0 --size $metis_api_size --async"
	echo "$cmd"
	$cmd > /dev/null
	rc=$?
	if [ $rc -eq 0 ]; then
		log "Result : PASSED"
	else
		log "Result : FAILED ($rc)"
	fi
	log "======================================================"
}

test_metis_dmabuf_xfer_read()
{
	log "======================================================"
	log "TEST $loop: ${FUNCNAME[0]}"
	metis_api_size=1059876
	metis_api_in=/tmp/metis_api.in
	[ -e $metis_api_in ] && rm $metis_api_in
	cmd="metis_dma --device $DEVICE --file $metis_api_in --read --channel 0 --size $metis_api_size"
	echo "$cmd"
	$cmd > /dev/null
	rc=$?
	if [ $rc -eq 0 ]; then
		log "Result : PASSED"
	else
		log "Result : FAILED ($rc)"
	fi
	log "======================================================"
}

test_metis_dmabuf_xfer_read_offset()
{
	log "======================================================"
	log "TEST $loop: ${FUNCNAME[0]}"
	metis_api_size=1055188
	metis_api_in=/tmp/metis_api.in
	[ -e $metis_api_in ] && rm $metis_api_in
	cmd="metis_dma --device $DEVICE --file $metis_api_in --read --channel 0 --size $metis_api_size --offset 0x1250"
	echo "$cmd"
	$cmd > /dev/null
	rc=$?
	if [ $rc -eq 0 ]; then
		log "Result : PASSED"
	else
		log "Result : FAILED ($rc)"
	fi
	log "======================================================"
}

test_metis_dmabuf_xfer_read_write_cmp_async_wait()
{
	log "======================================================"
	log "TEST $loop: ${FUNCNAME[0]}"
	metis_api_size=1059876
	metis_api_in=/tmp/metis_api.in
	metis_api_out=/tmp/metis_api.out
	[ -e $metis_api_in ] && rm $metis_api_in
	[ -e $metis_api_out ] && rm $metis_api_out
	dd if=/dev/urandom of=$metis_api_out bs=$metis_api_size count=1 > /dev/null 2>&1
	cmd="metis_dma --device $DEVICE --file $metis_api_out --write --channel 0 --async --wait"
	echo "$cmd"
	$cmd > /dev/null
	rc=$?
	if [ $rc -eq 0 ]; then
		log "Result : PASSED"
	else
		log "Result : FAILED ($rc)"
	fi
	cmd="metis_dma --device $DEVICE --file $metis_api_in --read --channel 0 --size $metis_api_size --async --wait"
	echo "$cmd"
	$cmd
	rc=$?
	if [ $rc -eq 0 ]; then
		log "Result : PASSED"
	else
		log "Result : FAILED ($rc)"
	fi
	cmd="diff $metis_api_out $metis_api_in"
	echo "$cmd"
	$cmd > /dev/null
	rc=$?
	if [ $rc -eq 0 ]; then
		log "Result : PASSED"
	else
		log "Result : FAILED ($rc)"
	fi
	log "======================================================"
}
test_metis_dmabuf_xfer_read_write_cmp_async()
{
	log "======================================================"
	log "TEST $loop: ${FUNCNAME[0]}"
	metis_api_size=1059876
	metis_api_in=/tmp/metis_api.in
	metis_api_out=/tmp/metis_api.out
	[ -e $metis_api_in ] && rm $metis_api_in
	[ -e $metis_api_out ] && rm $metis_api_out
	dd if=/dev/urandom of=$metis_api_out bs=$metis_api_size count=1 > /dev/null 2>&1
	cmd="metis_dma --device $DEVICE --file $metis_api_out --write --channel 0 --async"
	echo "$cmd"
	$cmd > /dev/null
	rc=$?
	if [ $rc -eq 0 ]; then
		log "Result : PASSED"
	else
		log "Result : FAILED ($rc)"
	fi
	cmd="metis_dma --device $DEVICE --file $metis_api_in --read --channel 0 --size $metis_api_size"
	echo "$cmd"
	$cmd
	rc=$?
	if [ $rc -eq 0 ]; then
		log "Result : PASSED"
	else
		log "Result : FAILED ($rc)"
	fi
	cmd="diff $metis_api_out $metis_api_in"
	echo "$cmd"
	$cmd > /dev/null
	rc=$?
	if [ $rc -eq 0 ]; then
		log "Result : PASSED"
	else
		log "Result : FAILED ($rc)"
	fi
	log "======================================================"
}
test_metis_dmabuf_xfer_read_write_cmp()
{
	log "======================================================"
	log "TEST $loop: ${FUNCNAME[0]}"
	metis_api_size=1059876
	metis_api_in=/tmp/metis_api.in
	metis_api_out=/tmp/metis_api.out
	[ -e $metis_api_in ] && rm $metis_api_in
	[ -e $metis_api_out ] && rm $metis_api_out
	dd if=/dev/urandom of=$metis_api_out bs=$metis_api_size count=1 > /dev/null 2>&1
	cmd="metis_dma --device $DEVICE --file $metis_api_out --write --channel 0"
	echo "$cmd"
	$cmd > /dev/null
	rc=$?
	if [ $rc -eq 0 ]; then
		log "Result : PASSED"
	else
		log "Result : FAILED ($rc)"
	fi
	cmd="metis_dma --device $DEVICE --file $metis_api_in --read --channel 0 --size $metis_api_size"
	echo "$cmd"
	$cmd
	rc=$?
	if [ $rc -eq 0 ]; then
		log "Result : PASSED"
	else
		log "Result : FAILED ($rc)"
	fi
	cmd="diff $metis_api_out $metis_api_in"
	echo "$cmd"
	$cmd > /dev/null
	rc=$?
	if [ $rc -eq 0 ]; then
		log "Result : PASSED"
	else
		log "Result : FAILED ($rc)"
	fi
	log "======================================================"
}
test_metis_dmabuf_xfer_read_write_offset_cmp()
{
	log "======================================================"
	log "TEST $loop: ${FUNCNAME[0]}"
	metis_api_offset=0x1250
	metis_api_offset_dec=$(($metis_api_offset))
	metis_api_size=1059876
	metis_api_size_in=$(($metis_api_size - $metis_api_offset))
	metis_api_in=/tmp/metis_api.in
	metis_api_out=/tmp/metis_api.out
	[ -e $metis_api_in ] && rm $metis_api_in
	[ -e $metis_api_out ] && rm $metis_api_out
	dd if=/dev/urandom of=$metis_api_out bs=$metis_api_size count=1 > /dev/null 2>&1
	cmd="metis_dma --device $DEVICE --file $metis_api_out --write --channel 0 --offset $metis_api_offset"
	echo "$cmd"
	$cmd > /dev/null
	rc=$?
	if [ $rc -eq 0 ]; then
		log "Result : PASSED"
	else
		log "Result : FAILED ($rc)"
	fi
	cmd="metis_dma --device $DEVICE --file $metis_api_in --read --channel 0 --size $metis_api_size_in --offset $metis_api_offset"
	echo "$cmd"
	$cmd
	rc=$?
	if [ $rc -eq 0 ]; then
		log "Result : PASSED"
	else
		log "Result : FAILED ($rc)"
	fi
	[ -e $metis_api_out.skip ] && rm $metis_api_out.skip
	dd if=$metis_api_out of=$metis_api_out.skip skip=$metis_api_offset_dec bs=1 > /dev/null 2>&1
	cmd="diff $metis_api_out.skip $metis_api_in"
	echo "$cmd"
	$cmd > /dev/null
	rc=$?
	if [ $rc -eq 0 ]; then
		log "Result : PASSED"
	else
		log "Result : FAILED ($rc)"
	fi
	log "======================================================"
}

test_metis_dmabuf_multi_xfer_read_async_poll()
{
	log "======================================================"
	log "TEST $loop: ${FUNCNAME[0]}"
	metis_api_size=4194304
	metis_api_in=/tmp/metis_api.in
	[ -e $metis_api_in ] && rm $metis_api_in
	cmd="metis_dma --device $DEVICE --file $metis_api_in --read --channel 0 --size $metis_api_size --async --multi-poll 4"
	echo "$cmd"
	$cmd > /dev/null
	rc=$?
	if [ $rc -eq 0 ]; then
		log "Result : PASSED"
	else
		log "Result : FAILED ($rc)"
	fi
	log "======================================================"
}

test_metis_dmabuf_multi_xfer_write_async_poll()
{
	log "======================================================"
	log "TEST $loop: ${FUNCNAME[0]}"
	metis_api_size=4194304
	metis_api_out=/tmp/metis_api.out
	[ -e $metis_api_out ] && rm $metis_api_out
	dd if=/dev/urandom of=$metis_api_out bs=$metis_api_size count=1 > /dev/null 2>&1
	cmd="metis_dma --device $DEVICE --file $metis_api_out --write --channel 0 --async --multi-poll 4"
	echo "$cmd"
	$cmd > /dev/null
	rc=$?
	if [ $rc -eq 0 ]; then
		log "Result : PASSED"
	else
		log "Result : FAILED ($rc)"
	fi
	log "======================================================"
}

test_metis_host_xfer_write()
{
	log "======================================================"
	log "TEST $loop: ${FUNCNAME[0]}"
	metis_api_size=8192
	metis_api_out=/tmp/metis_api.out
	[ -e $metis_api_out ] && rm $metis_api_out
	dd if=/dev/urandom of=$metis_api_out bs=$metis_api_size count=1 > /dev/null 2>&1
	cmd="metis_dma --device $DEVICE --file $metis_api_out --write --host-alloc"
	echo "$cmd"
	$cmd > /dev/null
	rc=$?
	if [ $rc -eq 0 ]; then
		log "Result : PASSED"
	else
		log "Result : FAILED ($rc)"
	fi
	[ -e $metis_api_out ] && rm $metis_api_out
	log "======================================================"
}

test_metis_host_xfer_read()
{
	log "======================================================"
	log "TEST $loop: ${FUNCNAME[0]}"
	metis_api_size=8192
	metis_api_in=/tmp/metis_api.in
	[ -e $metis_api_in ] && rm $metis_api_in
	dd if=/dev/urandom of=$metis_api_in bs=$metis_api_size count=1 > /dev/null 2>&1
	cmd="metis_dma --device $DEVICE --file $metis_api_in --read --host-alloc --size $metis_api_size"
	echo "$cmd"
	$cmd > /dev/null
	rc=$?
	if [ $rc -eq 0 ]; then
		log "Result : PASSED"
	else
		log "Result : FAILED ($rc)"
	fi
	log "======================================================"
}

test_metis_host_xfer_read_write_cmp()
{
	log "======================================================"
	log "TEST $loop: ${FUNCNAME[0]}"
	metis_api_size=1059876
	metis_api_in=/tmp/metis_api.in
	metis_api_out=/tmp/metis_api.out
	[ -e $metis_api_in ] && rm $metis_api_in
	[ -e $metis_api_out ] && rm $metis_api_out
	dd if=/dev/urandom of=$metis_api_out bs=$metis_api_size count=1 > /dev/null 2>&1
	cmd="metis_dma --device $DEVICE --file $metis_api_out --write --host-alloc"
	echo "$cmd"
	$cmd > /dev/null
	rc=$?
	if [ $rc -eq 0 ]; then
		log "Result : PASSED"
	else
		log "Result : FAILED ($rc)"
	fi
	cmd="metis_dma --device $DEVICE --file $metis_api_in --read --host-alloc --size $metis_api_size"
	echo "$cmd"
	$cmd > /dev/null
	rc=$?
	if [ $rc -eq 0 ]; then
		log "Result : PASSED"
	else
		log "Result : FAILED ($rc)"
	fi
	cmd="diff $metis_api_out $metis_api_in"
	echo "$cmd"
	$cmd > /dev/null
	rc=$?
	if [ $rc -eq 0 ]; then
		log "Result : PASSED"
	else
		log "Result : FAILED ($rc)"
	fi
	log "======================================================"
}

test_metis_p2p_dma_transfer_read()
{
	log "======================================================"
	log "TEST $loop: ${FUNCNAME[0]}"
	metis_api_size=8388608
	metis_api_in=/tmp/metis_api.in
	metis_api_out=/tmp/metis_api.out
	[ -e $metis_api_in ] && rm $metis_api_in
	[ -e $metis_api_out ] && rm $metis_api_out
	dd if=/dev/urandom of=$metis_api_out bs=$metis_api_size count=1 > /dev/null 2>&1

	axcmd --device-list|grep  "Device 1"
	if [ $? -ne 0 ]; then
		log "No Device 1 found, skipping test"
		log "======================================================"
		return
	fi

	log "Write to Device 0"
	cmd="metis_dma --device 0 --file $metis_api_out --write --channel 1"
	echo "$cmd"
	$cmd > /dev/null
	rc=$?
	if [ $rc -eq 0 ]; then
		log "Result : PASSED"
	else
		log "Result : FAILED ($rc)"
	fi

	log "P2p Write from Device 0 to Device 1"
	cmd="metis_dma --device 0 --p2p-dma 0:1  --channel 1 --size $metis_api_size --read"
	echo "$cmd"
	$cmd > /dev/null
	rc=$?
	if [ $rc -eq 0 ]; then
		log "Result : PASSED"
	else
		log "Result : FAILED ($rc)"
	fi

	log "Read from Device 1"
	cmd="metis_dma --device 1 --file $metis_api_in --read --read --channel 1 --size $metis_api_size"
	echo "$cmd"
	$cmd > /dev/null
	rc=$?
	if [ $rc -eq 0 ]; then
		log "Result : PASSED"
	else
		log "Result : FAILED ($rc)"
	fi
	cmd="diff $metis_api_out $metis_api_in"
	echo "$cmd"
	$cmd > /dev/null
	rc=$?
	if [ $rc -eq 0 ]; then
		log "Result : PASSED"
	else
		log "Result : FAILED ($rc)"
	fi
	log "======================================================"
}

test_metis_p2p_dma_transfer_write()
{
	log "======================================================"
	log "TEST $loop: ${FUNCNAME[0]}"
	metis_api_size=8388608
	metis_api_in=/tmp/metis_api.in
	metis_api_out=/tmp/metis_api.out
	[ -e $metis_api_in ] && rm $metis_api_in
	[ -e $metis_api_out ] && rm $metis_api_out
	dd if=/dev/urandom of=$metis_api_out bs=$metis_api_size count=1 > /dev/null 2>&1

	axcmd --device-list|grep  "Device 1"
	if [ $? -ne 0 ]; then
		log "No Device 1 found, skipping test"
		log "======================================================"
		return
	fi

	log "Write to Device 1"
	cmd="metis_dma --device 1 --file $metis_api_out --write --channel 1"
	echo "$cmd"
	$cmd > /dev/null
	rc=$?
	if [ $rc -eq 0 ]; then
		log "Result : PASSED"
	else
		log "Result : FAILED ($rc)"
	fi

	log "P2p Read from Device 1 to Device 0"
	cmd="metis_dma --p2p-dma 1:0  --channel 1 --size $metis_api_size --write"
	echo "$cmd"
	$cmd > /dev/null
	rc=$?
	if [ $rc -eq 0 ]; then
		log "Result : PASSED"
	else
		log "Result : FAILED ($rc)"
	fi

	log "Read from Device 1"
	cmd="metis_dma --device 0 --file $metis_api_in --read --read --channel 1 --size $metis_api_size"
	echo "$cmd"
	$cmd > /dev/null
	rc=$?
	if [ $rc -eq 0 ]; then
		log "Result : PASSED"
	else
		log "Result : FAILED ($rc)"
	fi
	cmd="diff $metis_api_out $metis_api_in"
	echo "$cmd"
	$cmd > /dev/null
	rc=$?
	if [ $rc -eq 0 ]; then
		log "Result : PASSED"
	else
		log "Result : FAILED ($rc)"
	fi
	log "======================================================"
}

test_metis_p2p_dev_dma_transfer_write()
{
	log "======================================================"
	log "TEST $loop: ${FUNCNAME[0]}"
	metis_api_size=8388608
	metis_api_in=/tmp/metis_api.in
	metis_api_out=/tmp/metis_api.out
	[ -e $metis_api_in ] && rm $metis_api_in
	[ -e $metis_api_out ] && rm $metis_api_out
	dd if=/dev/urandom of=$metis_api_out bs=$metis_api_size count=1 > /dev/null 2>&1

	axcmd --device-list|grep  "Device 1"
	if [ $? -ne 0 ]; then
		log "No Device 1 found, skipping test"
		log "======================================================"
		return
	fi

	log "Write to Device 0"
	cmd="metis_dma --device 0 --file $metis_api_out --write --channel 0"
	echo "$cmd"
	$cmd > /dev/null
	rc=$?
	if [ $rc -eq 0 ]; then
		log "Result : PASSED"
	else
		log "Result : FAILED ($rc)"
	fi

	log "P2p Write from Device 0 to Device 1"
	cmd="metis_dma --p2p-dev-dma-utest  --channel 1 --size $metis_api_size --read"
	echo "$cmd"
	$cmd > /dev/null
	rc=$?
	if [ $rc -eq 0 ]; then
		log "Result : PASSED"
	else
		log "Result : FAILED ($rc)"
	fi

	log "Read from Device 1"
	cmd="metis_dma --device 1 --file $metis_api_in --read --read --channel 0 --size $metis_api_size"
	echo "$cmd"
	$cmd > /dev/null
	rc=$?
	if [ $rc -eq 0 ]; then
		log "Result : PASSED"
	else
		log "Result : FAILED ($rc)"
	fi
	cmd="diff $metis_api_out $metis_api_in"
	echo "$cmd"
	$cmd > /dev/null
	rc=$?
	if [ $rc -eq 0 ]; then
		log "Result : PASSED"
	else
		log "Result : FAILED ($rc)"
	fi
	log "======================================================"
}
test_metis_p2p_dev_dma_transfer_read()
{
	log "======================================================"
	log "TEST $loop: ${FUNCNAME[0]}"
	metis_api_size=8388608
	metis_api_in=/tmp/metis_api.in
	metis_api_out=/tmp/metis_api.out
	[ -e $metis_api_in ] && rm $metis_api_in
	[ -e $metis_api_out ] && rm $metis_api_out
	dd if=/dev/urandom of=$metis_api_out bs=$metis_api_size count=1 > /dev/null 2>&1

	axcmd --device-list|grep  "Device 1"
	if [ $? -ne 0 ]; then
		log "No Device 1 found, skipping test"
		log "======================================================"
		return
	fi

	log "Write to Device 1"
	cmd="metis_dma --device 1 --file $metis_api_out --write --channel 0"
	echo "$cmd"
	$cmd > /dev/null
	rc=$?
	if [ $rc -eq 0 ]; then
		log "Result : PASSED"
	else
		log "Result : FAILED ($rc)"
	fi

	log "P2p Read from Device 1 to Device 0"
	cmd="metis_dma --p2p-dev-dma-utest  --channel 1 --size $metis_api_size --write"
	echo "$cmd"
	$cmd > /dev/null
	rc=$?
	if [ $rc -eq 0 ]; then
		log "Result : PASSED"
	else
		log "Result : FAILED ($rc)"
	fi

	log "Read from Device 0"
	cmd="metis_dma --device 0 --file $metis_api_in --read --read --channel 0 --size $metis_api_size"
	echo "$cmd"
	$cmd > /dev/null
	rc=$?
	if [ $rc -eq 0 ]; then
		log "Result : PASSED"
	else
		log "Result : FAILED ($rc)"
	fi
	cmd="diff $metis_api_out $metis_api_in"
	echo "$cmd"
	$cmd > /dev/null
	rc=$?
	if [ $rc -eq 0 ]; then
		log "Result : PASSED"
	else
		log "Result : FAILED ($rc)"
	fi
	log "======================================================"
}

test_empty()
{
	log_clean
}

TEST_CMD=(
test_empty
test_metis_dmabuf_xfer_write
test_metis_dmabuf_xfer_read
test_metis_dmabuf_xfer_read_write_cmp
test_metis_dmabuf_xfer_write_async
test_metis_dmabuf_xfer_read_async
test_metis_dmabuf_xfer_read_write_cmp_async
test_metis_dmabuf_xfer_write_async_wait
test_metis_dmabuf_xfer_read_async_wait
test_metis_dmabuf_xfer_read_write_cmp_async_wait
test_metis_dmabuf_xfer_write_offset
test_metis_dmabuf_xfer_read_offset
test_metis_dmabuf_xfer_read_write_offset_cmp
test_metis_dmabuf_multi_xfer_read_async_poll
test_metis_dmabuf_multi_xfer_write_async_poll
test_metis_host_xfer_write
test_metis_host_xfer_read
test_metis_host_xfer_read_write_cmp
test_metis_p2p_dma_transfer_read
test_metis_p2p_dma_transfer_write
test_metis_p2p_dev_dma_transfer_write
test_metis_p2p_dev_dma_transfer_read
)

log_clean
loop=0
if [ $t_only -eq -1 ]; then
	for test_cmd in "${TEST_CMD[@]}"
	do
		echo "TEST $loop $test_cmd"
		loop=$((loop+1))
	done
	exit 0
fi

loop=0
if [ $t_only -gt 0 ]; then
	loop=$t_only
	 ${TEST_CMD[$t_only]}
else
	 for test_cmd in "${TEST_CMD[@]}"
	 do
		 $test_cmd
		 loop=$((loop+1))
	 done
fi

cat "$log_file"

grep -q FAILED "$log_file"
rc=$?
if [ $rc -eq 0 ];then
	echo "At least one test failed"
	exit 1
fi
exit 0
