#!/bin/bash
# Copyright (c) 2023 Axelera AI. All rights reserved.
#
# shellcheck disable=SC2129
# shellcheck disable=SC2086
# shellcheck disable=SC2181
# shellcheck disable=SC2001

if [ -z "$DEVICE" ]; then
	# If not given explicitly, try to auto-detect.
	DEVICE=$(axcmd --device-list | grep "Device 0:" | sed 's/.*Device 0: //')
	if [ -z "$DEVICE" ]; then
		echo "No Axelera device found"
		exit 1
	fi
fi

if [ -z "$AXE_CHROOT" ]; then
	log_file=/tmp/test-axldev.log
else
	log_file=$AXE_CHROOT/test-axldev.log
fi

# Querying first device is okay because we do not support mixed-generation
# setups (Alpha and Omega card in the same system), so all devices must have
# the same generation.
HW_GEN_OUTPUT=$(axcmd --hwgen 0)
if [ $? -ne 0 ]; then
	echo "Could not query hardware generation"
	exit 1
fi

# Output is like: Hardware generation at index 0: alpha
hw_gen=$(echo "$HW_GEN_OUTPUT"|sed -e 's/.*: \(.*\)/\1/')

# Check if the variable is within allowed set of values
case "$hw_gen" in
	"omega")
		echo "hw_gen=omega"
		HW_GEN_NAME=metis
		;;
	"europa")
		echo "hw_gen=europa"
		HW_GEN_NAME=europa
		;;
	*)
		echo "Invalid HW generation reported by device: $hw_gen"
		exit 1
		;;
esac
HW_GEN_CLASS=metis

echo "AXE_CHROOT=\"$AXE_CHROOT\""
echo "DEVICE_CHROOT=\"$DEVICE_CHROOT\""
echo "AXELERA_DEVICE_DIR=\"$AXELERA_DEVICE_DIR\""

DEVICE_DIR=""
if [ -n "$DEVICE_CHROOT" ]; then
	# Either inside device.firmware container or manually set.
	DEVICE_DIR="$DEVICE_CHROOT/$hw_gen"
elif [ -n "$AXE_CHROOT" ]; then
	# Either software-platform or manually set.
	DEVICE_DIR="$AXE_CHROOT/opt/axelera/device/$hw_gen"
elif [ -n "$AXELERA_DEVICE_DIR" ]; then
	# This is an SDK installation
	DEVICE_DIR="$AXELERA_DEVICE_DIR"
else
	echo "Neither DEVICE_CHROOT, nor AXE_CHROOT, nor AXELERA_DEVICE_DIR set."
	echo "Cannot locate device artifacts!"
	exit 1
fi

get_pci_address()
{
	local device_name="$1"
	local sysfs_path="/sys/class/metis/${device_name}"

	# Check if the device exists
	if [ ! -L "$sysfs_path" ]; then
		echo "Error: Device ${device_name} not found in /sys/class/metis/" >&2
		return 1
	fi

	# Read the symlink and extract PCI address (format: 0000:00:04.0)
	readlink "$sysfs_path" | grep -oE '[0-9a-f]{4}:[0-9a-f]{2}:[0-9a-f]{2}\.[0-9]'
}

PCIE_DEV_ID=$(get_pci_address $DEVICE)

# Usage example:
# pci_addr=$(get_pci_address "europa-0:0:4")
# echo "$pci_addr"  # Output: 0000:00:04.0
log_clean()
{
	echo > "$log_file"
}

log ()
{
	echo "$1"
	echo "$1" >> "$log_file"
}

if [  -n "$1" ]; then
	t_only=$1
else
	t_only=0
fi
loop=0

device_info()
{
	echo "======================================================" >> $log_file
	PCIE_DEVICE=$(echo "$DEVICE"|sed 's/triton-//')
	lspci -s $PCIE_DEVICE -vv 2> /dev/null >> $log_file
	echo "======================================================" >> $log_file
}

test_run_megakernel_dmabuf_fail()
{
	log "======================================================"
	log "TEST $loop: ${FUNCNAME[0]}"
	cmd="axdma -B -r -g -f $DEVICE_DIR/bin/aikernel_fail -d $DEVICE"
	echo "$cmd"
	$cmd
	if [ $? -eq 0 ]; then
		log "Result : FAILED"
	else
		log "Result : PASSED"
	fi
	log "======================================================"
}

test_run_megakernel_dmabuf()
{
	log "======================================================"
	log "TEST $loop: ${FUNCNAME[0]}"
	cmd="axdma -B -r -g -f $DEVICE_DIR/bin/aikernel_hello_world -d $DEVICE"
	echo "$cmd"
	$cmd
	if [ $? -eq 0 ]; then
		log "Result : PASSED"
	else
		log "Result : FAILED"
	fi
	log "======================================================"
}

test_run_megakernel_dmabuf_ddr()
{
	log "======================================================"
	log "TEST $loop: ${FUNCNAME[0]}"
	cmd="axdma -D -B -r -g -f $DEVICE_DIR/bin/aikernel_hello_world -d $DEVICE"
	echo "$cmd"
	$cmd
	if [ $? -eq 0 ]; then
		log "Result : PASSED"
	else
		log "Result : FAILED"
	fi
	log "======================================================"
}

test_run_megakernel_cma()
{
	log "======================================================"
	log "TEST $loop: ${FUNCNAME[0]}"
	cmd="axdma -r -g -f $DEVICE_DIR/bin/aikernel_hello_world -d $DEVICE"
	echo "$cmd"
	$cmd
	if [ $? -eq 0 ]; then
		log "Result : PASSED"
	else
		log "Result : FAILED"
	fi
	log "======================================================"
}

test_run_megakernel_wrong_dev()
{
	log "======================================================"
	log "TEST $loop: ${FUNCNAME[0]}"
	cmd="axdma -r -g -f $DEVICE_DIR/bin/aikernel_hello_world -d metis-9:9:4"
	echo "$cmd"
	# Suppress expected error messages to avoid confusion.
	$cmd 2> /dev/null
	if [ $? -eq 0 ]; then
		log "Result : FAILED"
	else
		log "Result : PASSED"
	fi
	log "======================================================"
}

test_run_megakernel_missing_kernel()
{
	log "======================================================"
	log "TEST $loop: ${FUNCNAME[0]}"
	cmd="axdma -r -m 1 -g -f foo -d $DEVICE"
	echo "$cmd"
	# Suppress expected error messages to avoid confusion.
	$cmd 2> /dev/null
	if [ $? -eq 0 ]; then
		log "Result : FAILED"
	else
		log "Result : PASSED"
	fi
	log "======================================================"
}

test_run_megakernel_dmabuf_full_ctx()
{
	log "======================================================"
	log "TEST $loop: ${FUNCNAME[0]}"
	cmd="axdma -T 4 -B -r -g -f $DEVICE_DIR/bin/aikernel_hello_world -d $DEVICE"
	echo "$cmd"
	$cmd
	if [ $? -eq 0 ]; then
		log "Result : PASSED"
	else
		log "Result : FAILED"
	fi
	log "======================================================"
}

test_run_megakernel_dmabuf_fail_ctx()
{
	log "======================================================"
	log "TEST $loop: ${FUNCNAME[0]}"
	cmd="axdma -T 5 -B -r -g -f $DEVICE_DIR/bin/aikernel_hello_world -d $DEVICE"
	echo "$cmd"
	# Suppress expected error messages to avoid confusion.
	$cmd 2> /dev/null
	if [ $? -eq 0 ]; then
		log "Result : FAILED"
	else
		log "Result : PASSED"
	fi
	log "======================================================"
}

test_async_kernel_and_dma_wait()
{
	log "======================================================"
	log "TEST $loop: ${FUNCNAME[0]}"
	cmd="axdma -B -r -g -f $DEVICE_DIR/bin/aikernel_hello_world -d $DEVICE -A 1"
	echo "$cmd"
	$cmd
	if [ $? -eq 0 ]; then
		log "Result : PASSED"
	else
		log "Result : FAILED"
	fi
	log "======================================================"
}

test_async_kernel_and_dma_get_sts()
{
	log "======================================================"
	log "TEST $loop: ${FUNCNAME[0]}"
	cmd="axdma -B -r -g -f $DEVICE_DIR/bin/aikernel_hello_world -d $DEVICE -A 2 -T 4"
	echo "$cmd"
	$cmd
	if [ $? -eq 0 ]; then
		log "Result : PASSED"
	else
		log "Result : FAILED"
	fi
	log "======================================================"
}

test_async_kernel_and_dma_get_sts_no_dmabuf_release()
{
	log "======================================================"
	log "TEST $loop: ${FUNCNAME[0]}"
	cmd="axdma -B -r -g -f $DEVICE_DIR/bin/aikernel_hello_world -d $DEVICE -A 2 -T 4 -F"
	echo "$cmd"
	$cmd
	if [ $? -eq 0 ]; then
		log "Command : SUCCESS"
	else
		log "Command : FAILED"
	fi
	sudo grep -q "Total 0 objects, 0 bytes" /sys/kernel/debug/dma_buf/bufinfo
	RC=$?
	echo "-----------------------------"
	case $RC in
		0)
			log "Result : PASSED"
			;;
		1)
			log "Result : FAILED"
			;;
		*)
			log "Result : SKIPPED"
			;;
	esac
	log "======================================================"
}

test_async_single_dma_h2d()
{
	log "======================================================"
	log "TEST $loop: ${FUNCNAME[0]}"
	[ -e /tmp/dump_async.in ] && rm /tmp/dump_async.in
	dd if=/dev/urandom of=/tmp/dump_async.in bs=1M count=2 > /dev/null 2>&1
	cmd="axdma -B -g -f /tmp/dump_async.in -d $DEVICE -m 1 -A 1 -T 4 -P"
	echo "$cmd"
	$cmd
	if [ $? -eq 0 ]; then
		log "Result : PASSED"
	else
		log "Result : FAILED"
	fi
	log "======================================================"
}

test_async_single_dma_d2h()
{
	log "======================================================"
	log "TEST $loop: ${FUNCNAME[0]}"
	[ -e /tmp/dump_async.out ] && rm /tmp/dump_async.out
	dd if=/dev/urandom of=/tmp/dump_async.out bs=1M count=2 > /dev/null 2>&1
	cmd="axdma -B  -g -f /tmp/dump_async.out -d $DEVICE -s 0x200000 -m 2 -A 1 -T 4 -P"
	echo "$cmd"
	$cmd > /dev/null
	if [ $? -eq 0 ]; then
		log "Result : PASSED"
	else
		log "Result : FAILED"
	fi
	log "======================================================"
}

test_async_combined_dma_h2d_d2h()
{
	log "======================================================"
	log "TEST $loop: ${FUNCNAME[0]}"

	# Host to Device transfer
	[ -e /tmp/dump_async.in ] && rm /tmp/dump_async.in
	dd if=/dev/urandom of=/tmp/dump_async.in bs=1M count=2 > /dev/null 2>&1
	cmd_h2d="axdma -B -g -f /tmp/dump_async.in -d $DEVICE -m 1 -A 1 -T 4 -P"
	echo "$cmd_h2d"
	$cmd_h2d

	if [ $? -ne 0 ]; then
		log "Host to Device Transfer : FAILED"
		log "======================================================"
		return
	fi

	# Device to Host transfer
	[ -e /tmp/dump_async.out ] && rm /tmp/dump_async.out
	cmd_d2h="axdma -B -g -f /tmp/dump_async.out -d $DEVICE -s 0x200000 -m 2 -A 1 -T 4 -P"
	echo "$cmd_d2h"
	$cmd_d2h

	if [ $? -ne 0 ]; then
		log "Device to Host Transfer : FAILED"
		log "======================================================"
		return
	fi

	# Compare the data
	if cmp -s /tmp/dump_async.in /tmp/dump_async.out; then
		log "Data Comparison : PASSED"
	else
		log "Data Comparison : FAILED"
	fi

	log "======================================================"
}


test_async_single_dma_h2d_lpddr()
{
	log "======================================================"
	log "TEST $loop: ${FUNCNAME[0]}"
	[ -e /tmp/dump_async.in ] && rm /tmp/dump_async.in
	dd if=/dev/urandom of=/tmp/dump_async.in bs=1M count=8 > /dev/null 2>&1
	cmd="axdma -D -B -g -f /tmp/dump_async.in -d $DEVICE -m 1 -A 1 -T 4 -P"
	echo "$cmd"
	$cmd
	if [ $? -eq 0 ]; then
		log "Result : PASSED"
	else
		log "Result : FAILED"
	fi
	log "======================================================"
}

test_async_single_dma_d2h_lpddr()
{
	log "======================================================"
	log "TEST $loop: ${FUNCNAME[0]}"
	[ -e /tmp/dump_async.out ] && rm /tmp/dump_async.out
	dd if=/dev/urandom of=/tmp/dump_async.out bs=1M count=8 > /dev/null 2>&1
	cmd="axdma -D -B -g -f /tmp/dump_async.out -d $DEVICE -s 0x800000 -m 2 -A 1 -T 4 -P"
	echo "$cmd"
	$cmd > /dev/null
	if [ $? -eq 0 ]; then
		log "Result : PASSED"
	else
		log "Result : FAILED"
	fi
	log "======================================================"
}

test_async_combined_dma_h2d_d2h_lpddr()
{
	log "======================================================"
	log "TEST $loop: ${FUNCNAME[0]}"

	# Host to Device transfer
	[ -e /tmp/dump_async.in ] && rm /tmp/dump_async.in
	dd if=/dev/urandom of=/tmp/dump_async.in bs=1M count=8 > /dev/null 2>&1
	cmd_h2d="axdma -D -B -g -f /tmp/dump_async.in -d $DEVICE -m 1 -A 1 -T 4 -P"
	echo "$cmd_h2d"
	$cmd_h2d

	if [ $? -ne 0 ]; then
		log "Host to Device Transfer : FAILED"
		log "======================================================"
		return
	fi

	# Device to Host transfer
	[ -e /tmp/dump_async.out ] && rm /tmp/dump_async.out
	cmd_d2h="axdma -D -B -g -f /tmp/dump_async.out -d $DEVICE -s 0x800000 -m 2 -A 1 -T 4 -P"
	echo "$cmd_d2h"
	$cmd_d2h

	if [ $? -ne 0 ]; then
		log "Device to Host Transfer : FAILED"
		log "======================================================"
		return
	fi

	# Compare the data
	if cmp -s /tmp/dump_async.in /tmp/dump_async.out; then
		log "Data Comparison : PASSED"
	else
		log "Data Comparison : FAILED"
	fi

	log "======================================================"
}

test_dma_stats() {
	# Get the stats using axcmd --get-dma-stats
	log "======================================================"
	log "TEST $loop: ${FUNCNAME[0]}"

	cmd="axcmd --get-dma-stats"
	echo "$cmd"
	$cmd
	if [ $? -eq 0 ]; then
		log "Result : PASSED"
	else
		log "Result : FAILED"
	fi
	log "======================================================"
}

test_ctx_deinit()
{
	log "======================================================"
	log "TEST $loop: ${FUNCNAME[0]}"

	cmd="axcmd --test-ctx"
	echo "$cmd"
	$cmd
	if [ $? -eq 0 ]; then
		log "Result : PASSED"
	else
		log "Result : FAILED"
	fi
	log "======================================================"
}

test_msi_wait_interrupted_SIGTERM()
{
	log "======================================================"
	log "TEST $loop: ${FUNCNAME[0]}"

	# Skip on emulation
	axcmd --get-dev-mode | grep "SILICON"
	if [ $? -ne 0 ]; then
		log "Result : SKIPPED (Device mode is not SILICON, skipping test)"
		log "======================================================"
		return
	fi

	# Skip on Windows - interruptible wait not supported
	if [[ "$OSTYPE" == "msys" ]] || [[ "$OSTYPE" == "win32" ]] || [[ "$OSTYPE" == "cygwin" ]]; then
		log "Result : SKIPPED (Windows platform - MSI interruptible wait not supported)"
		log "======================================================"
		return 0
	fi

	# Start kernel execution in background (the delay kernel runs for 5 seconds)
	cmd="axdma -B -r -g -f $DEVICE_DIR/bin/aikernel_delay -d $DEVICE"
	echo "$cmd"
	$cmd 2>&1 &
	AXDMA_PID=$!

	# Now wait to let it reach the MSI wait
	sleep 2

	# Check if process is still running
	if ps -p $AXDMA_PID > /dev/null 2>&1; then
		echo "Process $AXDMA_PID is still running, sending SIGINT"
		kill -SIGINT $AXDMA_PID
		sleep 0.5

		# Wait for process and capture exit code
		wait $AXDMA_PID
		RC=$?
	else
		echo "Process $AXDMA_PID already completed before signal"
		wait $AXDMA_PID
		RC=$?
	fi

	echo "Process exit code: $RC"

	# Check if process was interrupted (exit code forced to 2 (SIGINT) in axdma)
	if [ $RC -eq 2 ]; then
		log "Result : PASSED"
	else
		log "Result : FAILED"
	fi
	log "======================================================"
}

test_msi_wait_interrupted_SIGCHLD()
{
	log "======================================================"
	log "TEST $loop: ${FUNCNAME[0]}"

	# Skip on emulation
	axcmd --get-dev-mode | grep "SILICON"
	if [ $? -ne 0 ]; then
		log "Result : SKIPPED (Device mode is not SILICON, skipping test)"
		log "======================================================"
		return
	fi

	# Skip on Windows - interruptible wait not supported
	if [[ "$OSTYPE" == "msys" ]] || [[ "$OSTYPE" == "win32" ]] || [[ "$OSTYPE" == "cygwin" ]]; then
		log "Result : SKIPPED (Windows platform - MSI interruptible wait not supported)"
		log "======================================================"
		return 0
	fi

	# Start kernel execution in background (the delay kernel runs for 5 seconds)
	cmd="axdma -B -r -g -f $DEVICE_DIR/bin/aikernel_delay -d $DEVICE"
	echo "$cmd"
	$cmd 2>&1 &
	AXDMA_PID=$!

	# Now wait to let it reach the MSI wait
	sleep 2

	# Check if process is still running
	if ps -p $AXDMA_PID > /dev/null 2>&1; then
		echo "Process $AXDMA_PID is still running, sending SIGCHLD"
		kill -SIGCHLD $AXDMA_PID
		sleep 0.5

		# Wait for process and capture exit code
		wait $AXDMA_PID
		RC=$?
	else
		echo "Process $AXDMA_PID already completed before signal"
		wait $AXDMA_PID
		RC=$?
	fi

	echo "Process exit code: $RC"

	if [ $RC -eq 0 ]; then
		log "Result : PASSED"
	else
		log "Result : FAILED"
	fi
	log "======================================================"
}

test_async_dma_xfer_force_exit()
{
	log "======================================================"
	log "TEST $loop: ${FUNCNAME[0]}"
	[ -e /tmp/dump_async.in ] && rm /tmp/dump_async.in
	dd if=/dev/urandom of=/tmp/dump_async.in bs=1M count=100 > /dev/null 2>&1
	cmd="axdma -D -B -g -f /tmp/dump_async.in -d $DEVICE -m 1 -A 1 -T 4 -P --force-close"
	echo "$cmd"
	$cmd
	if [ $? -eq 0 ]; then
		log "Result : PASSED"
	else
		log "Result : FAILED"
	fi
	log "======================================================"
}

test_vmsi_run_megakernel_logs()
{
	log "======================================================"
	log "TEST $loop: ${FUNCNAME[0]}"

    if [ $HW_GEN_NAME == "europa" ]; then
		log "SKIPPED for Europa"
		return 0
	fi
	axtrace --alog-level 0:inf
	axtrace --clear-buffer --timeout 1 --alog 0 > /dev/null
	mount | grep debugfs
	if [ $? -ne 0 ]; then
		sudo mount -t debugfs debugfs /sys/kernel/debug
	fi
	echo 1 | sudo tee /sys/kernel/debug/$HW_GEN_CLASS/$HW_GEN_NAME-$PCIE_DEV_ID/vmsi
	axdma -B -r -f $DEVICE_DIR/bin/aikernel_logs -d $DEVICE
	RC=$?
	axtrace --alog-level 0:err
	if [ $RC -ne 0 ]; then
		log "Result : FAILED"
		return
	fi
	axtrace --clear-buffer --timeout 1 --alog 0 > /dev/null

	cmd=(sudo grep "VMSI20: 0" /sys/kernel/debug/$HW_GEN_CLASS/$HW_GEN_NAME-$PCIE_DEV_ID/vmsi)
	if "${cmd[@]}"; then
		log "Result : FAILED"
	else
		log "Result : PASSED"
	fi
	log "======================================================"
}

test_run_megakernel_logs_aicore()
{
	log "======================================================"
	log "TEST $loop: ${FUNCNAME[0]}"
    if [ $HW_GEN_NAME == "europa" ]; then
		log "SKIPPED for Europa"
		return 0
	fi
	mount | grep debugfs
	if [ $? -ne 0 ]; then
		sudo mount -t debugfs debugfs /sys/kernel/debug
	fi

	for i in {0,1,2,3}
	do
		axtrace --alog-level $i:inf
		axtrace --clear-buffer --timeout 1 --alog $i > /dev/null
	done
	echo 1 | sudo tee  /sys/kernel/debug/$HW_GEN_CLASS/$HW_GEN_NAME-$PCIE_DEV_ID/vmsi
	for i in {0,1,2,3}
	do
		axdma -B -r -f $DEVICE_DIR/bin/aikernel_logs -d $DEVICE --aicore $i
		RC=$?
		if [ $RC -ne 0 ]; then
			log "Result : FAILED"
			return
		fi
		axtrace --alog-level $i:err
		axtrace --clear-buffer --timeout 1 --alog $i > /dev/null
	done

	# Check the debugfs correspondent to MSI indices:
	# MSI_LOG_AI0 = 20, MSI_LOG_AI1 = 21, MSI_LOG_AI2 = 22, MSI_LOG_AI3 = 23
	for i in {20,21,22,23}
	do
		j=$((i-20))
		cmd=(sudo grep "VMSI$i: 0" /sys/kernel/debug/$HW_GEN_CLASS/$HW_GEN_NAME-$PCIE_DEV_ID/vmsi)
		if "${cmd[@]}"; then
			log "Result : AICORE$j FAILED"
		else
			log "Result : AICORE$j PASSED"
		fi
	done
	log "======================================================"
}

test_empty()
{
	log_clean
	KDVER=$(axcmd --kdver)
	log "$KDVER"
}

device_info

TEST_CMD=(
test_empty
test_run_megakernel_cma
test_run_megakernel_dmabuf
test_run_megakernel_wrong_dev
test_run_megakernel_missing_kernel
test_run_megakernel_dmabuf_full_ctx
test_run_megakernel_dmabuf_fail_ctx
test_async_kernel_and_dma_wait
test_async_kernel_and_dma_get_sts
test_run_megakernel_dmabuf_ddr
test_run_megakernel_dmabuf_fail
test_async_single_dma_h2d
test_async_single_dma_d2h
test_async_combined_dma_h2d_d2h
test_async_single_dma_h2d_lpddr
test_async_single_dma_d2h_lpddr
test_async_combined_dma_h2d_d2h_lpddr
test_dma_stats
test_ctx_deinit
test_msi_wait_interrupted_SIGTERM
test_msi_wait_interrupted_SIGCHLD
#test_async_kernel_and_dma_get_sts_no_dmabuf_release
test_async_dma_xfer_force_exit
test_vmsi_run_megakernel_logs
test_run_megakernel_logs_aicore
)

log_clean
loop=0
if [ $t_only -eq -1 ]; then
	for test_cmd in "${TEST_CMD[@]}"
	do
		echo "TEST $loop $test_cmd"
		loop=$((loop+1))
	done
	exit 0
fi

if [ $t_only -gt 0 ]; then
	loop=$t_only
	${TEST_CMD[$t_only]}
else
	for test_cmd in "${TEST_CMD[@]}"
	do
		$test_cmd
		loop=$((loop+1))
	done
fi

cat $log_file

grep -q FAILED $log_file
if [ $? -eq 0 ];then
	echo "At least one test failed"
	exit 1
fi
exit 0
