#
# Copyright (c) 2023 Axelera AI. All rights reserved.
#
#!/bin/bash
# shellcheck disable=SC2129
# shellcheck disable=SC2086
# shellcheck disable=SC2181
# shellcheck disable=SC2010
# shellcheck disable=SC2006

# Function to check if a kernel file exists
check_kernel_file() {
	if [ ! -f "$1" ]; then
		echo "Error: Kernel file $1 not found"
		exit 1
	fi
}

if [ -z "$DEVICE" ]; then
	# If not given explicitly, try to auto-detect.
	DEVICE=$(axcmd --device-list | grep "Device 0:" | sed 's/.*Device 0: //')
	if [ -z "$DEVICE" ]; then
		echo "No Axelera device found"
		exit 1
	fi
fi
LOG_FILE_NAME="test-axldev-multi-kernel.log"
if [ -z "$AXE_CHROOT" ]; then
	log_file=/tmp/$LOG_FILE_NAME
else
	log_file=$AXE_CHROOT/$LOG_FILE_NAME
fi

# Querying first device is okay because we do not support mixed-generation
# setups (Alpha and Omega card in the same system), so all devices must have
# the same generation.
HW_GEN_OUTPUT=$(axcmd --hwgen 0)
if [ $? -ne 0 ]; then
	echo "Could not query hardware generation"
	exit 1
fi

# Output is like: Hardware generation at index 0: alpha
hw_gen=$(echo "$HW_GEN_OUTPUT"|sed -e 's/.*: \(.*\)/\1/')

# Check if the variable is within allowed set of values
case "$hw_gen" in
	"omega")
		echo "hw_gen=omega"
		;;
	"europa")
		echo "hw_gen=europa"
		;;
	*)
		echo "Invalid HW generation reported by device: $hw_gen"
		exit 1
		;;
esac

echo "AXE_CHROOT=\"$AXE_CHROOT\""
echo "DEVICE_CHROOT=\"$DEVICE_CHROOT\""
echo "AXELERA_DEVICE_DIR=\"$AXELERA_DEVICE_DIR\""

DEVICE_DIR=""
if [ -n "$DEVICE_CHROOT" ]; then
	# Either inside device.firmware container or manually set.
	DEVICE_DIR="$DEVICE_CHROOT/$hw_gen"
elif [ -n "$AXE_CHROOT" ]; then
	# Either software-platform or manually set.
	DEVICE_DIR="$AXE_CHROOT/opt/axelera/device/$hw_gen"
elif [ -n "$AXELERA_DEVICE_DIR" ]; then
	# This is an SDK installation
	DEVICE_DIR="$AXELERA_DEVICE_DIR"
else
	echo "Neither DEVICE_CHROOT, nor AXE_CHROOT, nor AXELERA_DEVICE_DIR set."
	echo "Cannot locate device artifacts!"
	exit 1
fi

export HELLO=$DEVICE_DIR/bin/aikernel_hello_world

if [ $hw_gen = "omega" ]; then
	export SQUEEZENET=$DEVICE_DIR/bin/aikernel_squeezenet
else
	# FIXME: Placeholder datapath-using kernel.  Use real network, see SDK-8176.
	export SQUEEZENET=$DEVICE_DIR/bin/aikernel_test_conv_identity_silu
fi

log_clean()
{
	echo > "$log_file"
}

log ()
{
	echo "$1"
	echo "$1" >> "$log_file"
}

if [  -n "$1" ]; then
	t_only=$1
else
	t_only=0
fi
loop=0

test_run_multi_helloworld()
{
	log "======================================================"
	log "TEST $loop: multi_helloworld in scratchpad"
	cmd="axcmd --device $DEVICE --debug --kernel0 $HELLO --kernel1 $HELLO --kernel2 $HELLO --kernel3 $HELLO --run f"
	echo "$cmd"
	$cmd
	if [ $? -eq 0 ]; then
		log "Result : OK"
	else
		log "Result : KO"
	fi
	log "======================================================"
}

test_run_multi_helloworld_ddr()
{
	log "======================================================"
	log "TEST $loop: multi_helloworld in DDR"
	cmd="axcmd --ddrctx --device $DEVICE --debug --kernel0 $HELLO --kernel1 $HELLO --kernel2 $HELLO --kernel3 $HELLO --run f"
	echo "$cmd"
	$cmd
	if [ $? -eq 0 ]; then
		log "Result : OK"
	else
		log "Result : KO"
	fi
	log "======================================================"
}

test_run_multi_squeezenet()
{
	log "======================================================"
	log "TEST $loop: multi_squeezenet"

	if [ $hw_gen = "europa" ]; then
		log "WARNING: Using placeholder kernel, see SDK-8176."
	fi

	cmd="axcmd --device $DEVICE --debug --kernel0 $SQUEEZENET --kernel1 $SQUEEZENET --kernel2 $SQUEEZENET --kernel3 $SQUEEZENET --run f"
	echo "$cmd"
	$cmd
	if [ $? -eq 0 ]; then
		log "Result : OK"
	else
		log "Result : KO"
	fi
	log "======================================================"
}

test_ping_pong()
{
	log "======================================================"
	log "TEST $loop: ping_pong"
	cmd="axcmd --device $DEVICE --opcode 108"
	echo "$cmd"
	$cmd  >> "$log_file"
	if [ $? -eq 0 ]; then
		log "Result : OK"
	else
		log "Result : KO"
	fi
	log "======================================================"
}

test_zephyr_build()
{
	log "======================================================"
	log "TEST $loop: zephyr_build"
	cmd="axcmd --device $DEVICE --opcode 109"
	echo "$cmd"
	$cmd  >> "$log_file"
	if [ $? -eq 0 ]; then
		log "Result : OK"
	else
		log "Result : KO"
	fi
	log "======================================================"
}

test_run_multi_helloworld_fail()
{
	log "======================================================"
	log "TEST $loop: multi_helloworld_fail"
	cmd="axcmd  --multi-threads --device $DEVICE --debug --kernel0 $HELLO --kernel1 $HELLO --fail"
	echo "$cmd"
	$cmd
	if [ $? -gt 0 ]; then
		log "Result : OK"
	else
		log "Result : KO"
	fi
	log "======================================================"
}

test_run_multi_context_on_process()
{
	log "======================================================"
	log "TEST $loop: multi_context_on_process"
	cmd="axcmd  --multi-threads --device $DEVICE --debug --kernel0 $HELLO --kernel1 $HELLO "
	echo "$cmd"
	$cmd
	if [ $? -eq 0 ]; then
		log "Result : OK"
	else
		log "Result : KO"
	fi
	log "======================================================"
}

test_run_multi_context_on_process_poll()
{
	log "======================================================"
	log "TEST $loop: test_run_multi_context_on_process_poll"
	cmd="axcmd  --multi-threads --multi-kernel-poll --device $DEVICE --debug --kernel0 $HELLO --kernel1 $HELLO "
	echo "$cmd"
	$cmd
	if [ $? -eq 0 ]; then
		log "Result : OK"
	else
		log "Result : KO"
	fi
	log "======================================================"
}

test_empty()
{
	log_clean
}

TEST_CMD=(
test_empty
test_ping_pong
test_zephyr_build
test_run_multi_helloworld
test_run_multi_squeezenet
test_run_multi_context_on_process
test_run_multi_context_on_process_poll
test_run_multi_helloworld_fail
test_run_multi_helloworld_ddr
)

log_clean
loop=0
if [ $t_only -eq -1 ]; then
	for test_cmd in "${TEST_CMD[@]}"
	do
		echo "TEST $loop $test_cmd"
		loop=$((loop+1))
	done
	exit 0
fi

if [ $t_only -gt 0 ]; then
	loop=$t_only
	${TEST_CMD[$t_only]}
else
	loop=0
	for test_cmd in "${TEST_CMD[@]}"
	do
		$test_cmd
		loop=$((loop+1))
	done
fi

cat $log_file

grep -q KO $log_file
if [ $? -eq 0 ];then
	echo "At least one test failed"
	exit 1
fi
exit 0
